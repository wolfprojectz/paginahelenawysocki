import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { saves } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(saves).where(eq(saves.slot, 1)).limit(1);
    if (rows.length === 0) return NextResponse.json({ save: null });
    return NextResponse.json({
      save: { moon: rows[0].moon, summary: rows[0].summary, state: rows[0].state, updatedAt: rows[0].updatedAt },
    });
  } catch (e) {
    return NextResponse.json({ save: null, error: String(e) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { moon, summary, state } = body as { moon: number; summary: string; state: unknown };
    const existing = await db.select({ id: saves.id }).from(saves).where(eq(saves.slot, 1)).limit(1);
    if (existing.length > 0) {
      await db
        .update(saves)
        .set({ moon, summary, state, updatedAt: new Date() })
        .where(eq(saves.id, existing[0].id));
    } else {
      await db.insert(saves).values({ slot: 1, moon, summary, state });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

export async function DELETE() {
  try {
    await db.delete(saves).where(eq(saves.slot, 1));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
