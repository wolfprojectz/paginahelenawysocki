import { Cat, GameState, Memory, RelStats, SpeechStyle } from "./types";
import { mulberry, pick, seasonOf, PLAYER_ID } from "./data";

// ── helpers ─────────────────────────────────────────────────────────────────
export function relTier(r: RelStats): "beloved" | "friend" | "neutral" | "wary" | "hostile" {
  const warmth = (r.affection + r.friendship + r.trust) / 3 - r.fear * 0.5 - r.suspicion * 0.3;
  if (warmth >= 70) return "beloved";
  if (warmth >= 52) return "friend";
  if (warmth >= 33) return "neutral";
  if (warmth >= 18) return "wary";
  return "hostile";
}

// ── greetings by style and warmth ───────────────────────────────────────────
const GREET: Record<SpeechStyle, Record<string, string[]>> = {
  stern: {
    beloved: ["{L}. It steadies me to see you well.", "Ah, {L}. Walk with me a moment."],
    friend: ["{L}. Good. I wanted a word.", "You move quietly, {L}. That's a skill."],
    neutral: ["{L}.", "Speak, {L}. My duties are many."],
    wary: ["{L}. Make it quick.", "I am watching more than you know, {L}."],
    hostile: ["{L}. Choose your next words with care.", "You test my patience, {L}."],
  },
  warm: {
    beloved: ["{L}! My heart lifts every time I see you.", "There you are, {L}. Come, sit by me."],
    friend: ["{L}, it's good to see you.", "Hello, {L}. You look well today."],
    neutral: ["Oh — {L}. Hello.", "Greetings, {L}."],
    wary: ["{L}... did you need something?", "Ah. {L}. I was just leaving."],
    hostile: ["{L}. I have nothing to say to you.", "Please, {L}. Not now. Not ever."],
  },
  dry: {
    beloved: ["Well, if it isn't my favorite disaster, {L}.", "{L}. Don't touch the poppy seeds. Hello, by the way."],
    friend: ["{L}. You have that look. What did you break?", "Mm. {L}. Talk while I sort these."],
    neutral: ["{L}. Sick, injured, or bored?", "Yes, yes, {L}. What is it?"],
    wary: ["{L}. Whatever it is, the answer is 'ask MapleStar'.", "I'm busy, {L}. Herbs don't sort themselves."],
    hostile: ["{L}. Out of my den.", "I treat every cat. I don't have to like every cat, {L}."],
  },
  protective: {
    beloved: ["{L}. Stay where I can see you, hm? The forest's been strange.", "Good to see you safe, {L}."],
    friend: ["{L}. All quiet where you came from?", "Keep to the paths today, {L}. Trust me."],
    neutral: ["{L}. Anything to report?", "Eyes open out there, {L}."],
    wary: ["{L}. I'll be honest — I keep my guard up around you.", "What do you want, {L}?"],
    hostile: ["Stay away from those I protect, {L}.", "{L}. One wrong step. That's all it takes."],
  },
  blunt: {
    beloved: ["{L}. Hmph. You're... not the worst company.", "There you are. Don't make me say I was looking for you, {L}."],
    friend: ["{L}. Say what you came to say.", "You again, {L}. Fine."],
    neutral: ["What.", "{L}. I'm busy being useful. Try it sometime."],
    wary: ["Herbs and daydreams. That's all you are, {L}.", "Move along, {L}."],
    hostile: ["Get out of my sight, {L}.", "I don't waste breath on you, {L}."],
  },
  sleepy: {
    beloved: ["*yawn*... oh, {L}. You're worth waking up for. Barely.", "Mm. {L}. Sit. The sun's good here."],
    friend: ["*stretch*... {L}. What moon is it?", "Oh. Hey {L}. I was resting my eyes."],
    neutral: ["Mmph. {L}. Five more minutes.", "*yawn* ...you need something, {L}?"],
    wary: ["Even half-asleep I keep one eye on you, {L}.", "Zzz... huh? Oh. {L}. Great."],
    hostile: ["You're the one dream I'd call a nightmare, {L}.", "Go away. I'm sleeping at you, {L}."],
  },
  cheerful: {
    beloved: ["{L}!! Best part of my whole day, right here!", "HA! {L}! Race you to the fresh-kill pile!"],
    friend: ["Hey hey, {L}! Great day for it!", "{L}! You will NOT believe what I saw this morning."],
    neutral: ["Oh hi, {L}!", "{L}! Nice weather for... whatever you do!"],
    wary: ["Oh. Uh. Hi {L}. I was just... going. Somewhere. Fast.", "Heh. {L}. What's... up."],
    hostile: ["Wow. {L}. My day just got worse.", "Not you, {L}."],
  },
  wary: {
    beloved: ["{L}. You're one of maybe three cats I don't second-guess.", "Good. It's you, {L}. Listen —"],
    friend: ["{L}. Seen anything odd today? Be honest.", "Quietly, {L}. Ears are everywhere."],
    neutral: ["{L}. I notice you've been busy. I notice everything.", "Hm. {L}. Interesting timing."],
    wary: ["I have questions about you, {L}. They multiply.", "{L}. Where were you at dawn? Exactly?"],
    hostile: ["Every hair on my pelt distrusts you, {L}.", "{L}. I'm documenting everything you do."],
  },
  odd: {
    beloved: ["{L}! Look — LOOK at this twig. Perfect fork. Two-tail symmetry. For you? ...No. But you may look at it.", "{L}, my friend! The twigs whisper of good fortune!"],
    friend: ["Ah, {L}! I found an oak twig with THREE nodes today. Three!", "{L}! Do you know how many twigs a nest truly needs? Neither do I. More."],
    neutral: ["{L}. Have you seen any birch twigs? Asking for me.", "Hm? Oh, {L}. Mind the twig pile. It is sorted by bendiness."],
    wary: ["{L}. Someone moved my twigs. Was it you? The twigs will know.", "The twigs don't trust you, {L}. I stay neutral. Mostly."],
    hostile: ["You STEPPED on a collection twig once, {L}. The twigs remember. I remember.", "No twigs for you, {L}. Ever."],
  },
  quiet: {
    beloved: ["...You came to find me, {L}. I like that. I always know where you are, you know.", "{L}. Good. When you're near, everything is quieter in my head."],
    friend: ["...{L}. I was hoping you'd come by.", "Hey. {L}. Sit with me? Just for a while."],
    neutral: ["...{L}.", "Oh. {L}. I didn't hear you. That's rare."],
    wary: ["Why are you really here, {L}?", "...You've been talking about me. Haven't you, {L}."],
    hostile: ["You should be more careful, {L}. About whose side you choose.", "...{L}. Don't."],
  },
  gentle: {
    beloved: ["{L}, my dear. Have you eaten? You look thin.", "Come here, {L}. Let me look at you. Good. Still whole."],
    friend: ["Hello, {L}. It's a soft sort of day, isn't it?", "{L}, dear. Mind the kits — they bite ankles now."],
    neutral: ["Hello, {L}.", "Oh, {L}. Bless you, you startled me."],
    wary: ["{L}... be kind today, will you?", "Oh. {L}. The kits are sleeping, keep your voice down."],
    hostile: ["Stay away from the nursery, {L}.", "I've raised kits meaner than you, {L}. Careful."],
  },
  gruff: {
    beloved: ["{L}! Sit. I've a story you've heard twice and will hear again.", "Hmph. {L}. My favorite pest."],
    friend: ["{L}. Pull up some moss.", "Back in my day, {L}, apprentices bowed to elders. Anyway, hello."],
    neutral: ["Eh? Oh. {L}.", "{L}. Fetch an old cat some fresh-kill and I'll pretend to like you."],
    wary: ["I've outlived cats I trusted more than you, {L}.", "Hmph. {L}."],
    hostile: ["I've seen your sort before, {L}. It ended badly for everyone.", "Away with you, {L}."],
  },
  playful: {
    beloved: ["{L}!! Tag! You're it! Okay okay I'll stop. Hi!!", "{L}! I saved you the bounciest moss ball!"],
    friend: ["Hi {L}! Watch this pounce. WATCH IT.", "{L}! Bet you can't catch me!"],
    neutral: ["Oh! Hi {L}!", "Hi hi, {L}!"],
    wary: ["Um. Hi {L}. I have to go... be... somewhere else.", "Oh. {L}. Hi. I guess."],
    hostile: ["You're a bad cat, {L}, and my pounces are ready.", "Go AWAY, {L}."],
  },
  cold: {
    beloved: ["{L}. Few cats earn my attention twice. You have.", "So. {L}. We meet where borders blur."],
    friend: ["{L}. Speak. I am listening — for now.", "{L}. You walk far from home."],
    neutral: ["A HollyClan cat. {L}, isn't it. Curious.", "{L}. Mind the border. Scent-lines are promises."],
    wary: ["{L}. You smell of questions. Dangerous prey to hunt.", "Careful, little healer. {L}, was it?"],
    hostile: ["Cross my border again, {L}, and diplomacy ends.", "{L}. Leave. Now."],
  },
};

// ── weather / season comments ───────────────────────────────────────────────
const WEATHER_LINES: Record<string, string[]> = {
  clear: ["Sky's clear as river water today.", "Good sun. Prey will be moving.", "Not a cloud. StarClan's in a generous mood."],
  rain: ["This rain soaks to the bone.", "Rain again. The elders' joints will complain louder than they do.", "Prey hides in rain like this."],
  storm: ["That thunder isn't done with us yet.", "Storm like this once dropped an oak on the border. Stay in camp.", "The sky is furious about something."],
  wind: ["Wind's carrying every scent sideways. Can't trust your nose today.", "This wind could steal the whiskers off your face.", "Hear that wind? The forest is talking over itself."],
  fog: ["Fog this thick hides friend and foe alike.", "I don't like fog. Too many shapes in it.", "Careful near the river in this fog."],
  snow: ["Snow's deep enough to swallow a kit whole. Watch the little ones.", "Cold enough to freeze your breath to your whiskers.", "Leafbare shows no mercy this moon."],
};

// ── memory phrasing by tone ─────────────────────────────────────────────────
function memoryLine(m: Memory, state: GameState, r: () => number): string {
  const ago = state.moon - m.moon;
  const when = m.moon <= 0 ? "long before you were apprenticed" : ago <= 0 ? "just now" : ago === 1 ? "last moon" : `${ago} moons ago`;
  const openers: Record<string, string[]> = {
    good: [`I still think about ${when} — `, `You know what I remember fondly? ${when.charAt(0).toUpperCase() + when.slice(1)}, `, `Heh. ${when.charAt(0).toUpperCase() + when.slice(1)}, `],
    bad: [`I haven't forgotten ${when} — `, `Something still sits wrong with me. ${when.charAt(0).toUpperCase() + when.slice(1)}, `, `It was ${when}. `],
    neutral: [`It was ${when} that `, `${when.charAt(0).toUpperCase() + when.slice(1)}, `],
    secret: [`...There are things I don't speak of. `, `Some memories I keep buried. `],
    grief: [`I still grieve. ${when.charAt(0).toUpperCase() + when.slice(1)}, `, `The Clan feels smaller since ${when}. `],
  };
  if (m.tone === "secret") return pick(openers.secret, r) + "Forget I said anything.";
  return pick(openers[m.tone] ?? openers.neutral, r) + m.text;
}

// ── opinion of another cat ──────────────────────────────────────────────────
export function opinionLine(state: GameState, speaker: Cat, aboutId: string, seed: number): string {
  const r = mulberry(seed);
  const about = state.cats[aboutId];
  if (!about) return "...Who?";
  if (!about.alive) {
    const rl = speaker.rel[aboutId];
    if (rl && rl.affection > 60) return `${about.name}... I miss ${about.gender === "tom" ? "him" : "her"} every day. The camp is too quiet in the wrong places now.`;
    return `${about.name} walks with StarClan now. Speak of the dead gently, or not at all.`;
  }
  const rl = speaker.rel[aboutId] ?? null;
  if (!rl) return `I don't know ${about.name} well.`;
  const bits: string[] = [];
  if (rl.affection >= 75) bits.push(`${about.name} means a great deal to me`);
  else if (rl.affection >= 55) bits.push(`I'm fond of ${about.name}`);
  else if (rl.affection <= 25) bits.push(`${about.name} and I don't share tongues`);
  if (rl.trust >= 75) bits.push(`I'd trust ${about.gender === "tom" ? "him" : "her"} with my life`);
  else if (rl.trust <= 30) bits.push(`I wouldn't turn my back on ${about.gender === "tom" ? "him" : "her"}`);
  if (rl.suspicion >= 50) bits.push(`something about ${about.name} doesn't add up — the comings, the goings, the silences`);
  if (rl.fear >= 40) bits.push(`honestly? ${about.name} unsettles me lately`);
  if (rl.jealousy >= 50) bits.push(`and ${about.gender === "tom" ? "he" : "she"} takes up more space in other cats' hearts than I like`);
  if (rl.respect >= 75) bits.push(`no cat works harder for this Clan`);
  if (bits.length === 0) bits.push(`${about.name} is... ${pick(about.traits, r)}, I suppose. We all have our ways`);
  let line = bits.slice(0, 2).join(". ") + ".";
  line = line.charAt(0).toUpperCase() + line.slice(1);
  // personality coloring
  if (speaker.speech === "blunt") line += " That's all I'll say.";
  if (speaker.speech === "wary") line += " Why do you ask? Who's asking you to ask?";
  if (speaker.speech === "odd") line += ` ${about.name} once ${rl.respect > 50 ? "admired" : "ignored"} my twig collection, for what it's worth.`;
  return line;
}

// ── main generator ──────────────────────────────────────────────────────────
export function generateDialogue(state: GameState, speaker: Cat, seed: number): string {
  const r = mulberry(seed + state.moon * 977 + state.timeTicks * 31);
  const player = state.cats[PLAYER_ID];
  const rl = speaker.rel[PLAYER_ID] ?? null;
  const tier = rl ? relTier(rl) : "neutral";
  const parts: string[] = [];
  const listenerName = player.name;

  // 1. greeting
  const greetSet = GREET[speaker.speech] ?? GREET.warm;
  parts.push(pick(greetSet[tier] ?? greetSet.neutral, r).replace(/\{L\}/g, listenerName));

  // 2. topic pool — weighted by context
  const topics: (() => string | null)[] = [];

  // grief overrides
  const deadLoved = Object.values(state.cats).filter(
    (c) => !c.alive && c.deathMoon !== undefined && state.moon - (c.deathMoon ?? 0) <= 2 && (speaker.rel[c.id]?.affection ?? 0) > 55
  );
  if (deadLoved.length > 0 && r() < 0.7) {
    const d = pick(deadLoved, r);
    return (
      parts[0] +
      " " +
      pick(
        [
          `Forgive me if I'm quiet. ${d.name}'s nest is still empty and I keep looking at it.`,
          `I keep expecting to hear ${d.name} across the clearing. Grief is a slow rain, ${listenerName}.`,
          `Do you think StarClan lets them watch us? I hope ${d.name} sees we go on.`,
        ],
        r
      )
    );
  }

  // weather/season
  topics.push(() => {
    const lines = WEATHER_LINES[state.weather] ?? WEATHER_LINES.clear;
    let l = pick(lines, r);
    if (seasonOf(state.moon) === "Leafbare" && r() < 0.5) l += " Leafbare tests us all.";
    return l;
  });

  // current activity
  topics.push(() => {
    const act: Record<string, string[]> = {
      hunting: ["I'm just back from hunting. The prey runs thin near the border, mark me.", "Caught a vole earlier. Fat one. The pile's decent today."],
      patrolling: ["Border patrol earlier — NightClan scent was fresher than I'd like.", "We renewed the scent markers this morning. All quiet. Too quiet, maybe."],
      training: ["Training hollow was busy today. The young ones improve fast.", "My muscles ache from training. Good ache."],
      resting: ["I was just resting my paws. Even warriors need still moments.", "Quiet moment. Rare thing in a Clan."],
      eating: ["Have you eaten? The fresh-kill pile won't fill itself, but it won't empty itself either.", "Sharing tongues over fresh-kill — best part of the day."],
      "caring for kits": ["The kits nearly took my tail off in a play-ambush this morning. They're growing fierce.", "Kits everywhere today. Count your paws or they'll steal one."],
      "sorting herbs": ["I've been elbow-deep in herbs all day. The store must be ready before the cold.", "Herbs, herbs, herbs. My nose will smell of marigold until next moon."],
      talking: ["I've been catching up on Clan talk. There's always more said than spoken, you know.", "Word travels around camp faster than a rabbit."],
    };
    const lines = act[speaker.activity];
    return lines ? pick(lines, r) : null;
  });

  // gossip about another cat
  topics.push(() => {
    const others = Object.values(state.cats).filter((c) => c.alive && c.id !== speaker.id && c.id !== PLAYER_ID && c.role !== "outsider");
    if (others.length === 0) return null;
    const o = pick(others, r);
    const orl = speaker.rel[o.id];
    if (!orl) return null;
    if (orl.suspicion >= 50) return `Between us — keep an eye on ${o.name}. ${o.gender === "tom" ? "He's" : "She's"} not been ${o.gender === "tom" ? "himself" : "herself"}.`;
    if (orl.friendship >= 70) return `${o.name} and I shared prey at sunhigh. Cats like ${o.gender === "tom" ? "him" : "her"} hold a Clan together.`;
    if (orl.jealousy >= 55) return `Everyone fusses over ${o.name} lately. I don't see what's so special. ...Don't repeat that.`;
    if (orl.respect <= 25) return `If ${o.name} did a full day's work, the shock would kill the elders.`;
    return null;
  });

  // memory recall — weighted by weight
  topics.push(() => {
    const mems = speaker.memories.filter((m) => m.tone !== "secret" || (speaker.knowsSecret && tier === "beloved" && r() < 0.15));
    if (mems.length === 0) return null;
    const totalW = mems.reduce((s, m) => s + m.weight, 0);
    let roll = r() * totalW;
    let chosen = mems[0];
    for (const m of mems) {
      roll -= m.weight;
      if (roll <= 0) {
        chosen = m;
        break;
      }
    }
    return memoryLine(chosen, state, r);
  });

  // mentor & apprentice talk
  topics.push(() => {
    if ((speaker.role === "apprentice" || speaker.role === "medapprentice") && speaker.mentor && state.cats[speaker.mentor]?.alive) {
      const men = state.cats[speaker.mentor];
      const mrel = speaker.rel[men.id];
      const prog = speaker.trainingProgress ?? 0;
      if ((mrel?.respect ?? 0) > 70) return pick([`${men.name} is training me. ${men.gender === "tom" ? "He's" : "She's"} tough, but I'd walk into a badger set if ${men.gender === "tom" ? "he" : "she"} said I was ready.`, `${men.name} says I ${prog > 70 ? "could pass my assessment tomorrow" : "still telegraph every pounce"}. From ${men.gender === "tom" ? "him" : "her"}, either one is practically a song of praise.`], r);
      if ((mrel?.respect ?? 50) < 40) return pick([`Training with ${men.name} again tomorrow. Joy. ${men.gender === "tom" ? "He" : "She"} corrects my crouch by insulting my ancestors.`, `Don't tell anyone, but I wish the leader had picked me a different mentor than ${men.name}.`], r);
      const lesson = speaker.lessons && speaker.lessons.length > 0 ? speaker.lessons[speaker.lessons.length - 1] : null;
      if (lesson) return `${men.name} taught me ${lesson} recently. I'm ${prog > 60 ? "nearly ready for my warrior name — I can feel it" : "getting there, one bruise at a time"}.`;
      return null;
    }
    const app = Object.values(state.cats).find((a) => a.alive && (a.role === "apprentice" || a.role === "medapprentice") && a.mentor === speaker.id);
    if (app) {
      const arel = speaker.rel[app.id];
      const prog = app.trainingProgress ?? 0;
      if ((arel?.affection ?? 0) > 65) return pick([`My apprentice ${app.name} ${prog > 70 ? "is nearly ready. Don't tell " + (app.gender === "tom" ? "him" : "her") + " I said so — humility is the last lesson" : "learns faster than I ever did. It's infuriating and wonderful"}.`, `Training ${app.name} is the best duty I've ever pulled, and I include eating in that list.`], r);
      return pick([`${app.name}'s training ${prog > 60 ? "goes well enough. The Code is in " + (app.gender === "tom" ? "him" : "her") + " now; the patience will follow" : "tests us both. Mostly me"}.`, `An apprentice is a mirror with paws, ${listenerName}. ${app.name} shows me every bad habit I ever had.`], r);
    }
    return null;
  });

  // goals
  topics.push(() => {
    if (speaker.goals.length === 0 || r() < 0.4) return null;
    const g = pick(speaker.goals, r);
    return pick([`Lately one thing drives me: ${g}.`, `Ask me what I want? Simple. To ${g.charAt(0).toLowerCase() + g.slice(1)}.`, `Some cats drift. Not me. I mean to ${g.charAt(0).toLowerCase() + g.slice(1)}.`], r);
  });

  // recent clan history
  topics.push(() => {
    const recent = state.history.slice(-2).flatMap((h) => h.events);
    if (recent.length === 0) return null;
    const e = pick(recent, r);
    return pick([`The whole camp is still talking about it — ${e.toLowerCase()}`, `Strange moons, these. ${e}`, `You heard, of course. ${e}`], r);
  });

  // health
  if (speaker.sick) {
    topics.unshift(() => {
      const s = speaker.sick!;
      return pick(
        [
          `*cough* Don't fuss over me... though if there's ${s.herb === "catmint" ? "catmint" : "something for it"} in the store, I wouldn't refuse.`,
          `This ${s.name} has its claws in me deep, ${listenerName}. I'd be grateful for a medicine cat's eye.`,
        ],
        r
      );
    });
  }

  // story-flavored lines (gated by moon/flags — subtle, never explicit)
  const storyLine = storyFlavor(state, speaker, tier, r);
  if (storyLine && r() < 0.65) {
    parts.push(storyLine);
  } else {
    // pick 1-2 topics
    const shuffled = topics.sort(() => r() - 0.5);
    let added = 0;
    for (const t of shuffled) {
      const line = t();
      if (line) {
        parts.push(line);
        added++;
      }
      if (added >= (r() < 0.35 ? 2 : 1)) break;
    }
    if (added === 0) parts.push(pick(["The Clan keeps us busy, doesn't it.", "May StarClan light your path today."], r));
  }
  return parts.join(" ");
}

// ── story-stage flavor lines: clues woven into casual talk ─────────────────
function storyFlavor(state: GameState, speaker: Cat, tier: string, r: () => number): string | null {
  const m = state.moon;
  const f = state.flags;
  const silent = state.cats.silentpaw;
  const silentName = silent?.name ?? "Silentpaw";
  const lines: string[] = [];

  if (speaker.id === "silentpaw") {
    if (silent && !silent.alive) return null;
    if (m <= 6) {
      lines.push(
        "I counted heartbeats last night until I fell asleep. Yours is the only den I can't see from mine. I don't like that.",
        "When we were kits you shared your fresh-kill with me. Nobody else waited. I keep a list of cats who wait. It's short.",
        "Juniperfang keeps you so busy. Herbs, herbs. But you'd tell me if anything changed, wouldn't you? You'd tell me first."
      );
    } else if (m <= 8) {
      // the moons right after his warrior name: obsession at full burn
      lines.push(
        "I'm a warrior now. Silentshadow. A shadow belongs to someone, you know. Shadows don't leave. Shadows CAN'T leave. That's the best part of being one.",
        "You were with Hollyspark at sunhigh. Forty heartbeats, maybe fifty. I wasn't counting. ...I was counting. I'm always counting. It's how I love things.",
        "I reorganized my nest so it faces the medicine den. Nightsong asked why. I said 'drafts'. It wasn't drafts, Mistyblaze.",
        "Last night you got up twice. Once for water, once to check the herb store. You hum when you sort leaves in the dark. Did you know that? You hum.",
        "I told Windhawk that warriors and medicine cats can't be what we are. She asked what we are. I didn't have a word. There ISN'T a word. That's what makes it ours.",
        "Sometimes I dream the whole camp is empty except you and me. It's my favorite dream. I've started going to sleep early to get more of it.",
        "I marked the days since our naming ceremony on a root behind the den. Today is day nineteen. You looked at me four times on day nineteen. The average is three.",
        "If you ever got a thorn in your pad on the far side of the territory, I'd know. Don't ask me how I'd know. I'd just already be walking."
      );
    } else if (m <= 9) {
      lines.push(
        "I'm a warrior now. Silentshadow. A shadow belongs to someone, you know. Shadows don't leave.",
        "You were with Hollyspark at sunhigh. Forty heartbeats, maybe fifty. I wasn't counting. ...I was counting.",
        "Sometimes I dream the whole camp is empty except you and me. It's my favorite dream. Is that strange? Don't answer.",
        "Nightsong watches me oddly lately. Like he's waiting for me to become something. I don't know what."
      );
    } else if (m <= 14) {
      lines.push(
        "Everything changed when we got our names. Except us. I make sure of that part every day. You've noticed. You must have noticed.",
        "Who were you talking to before me? I only ask because I care. I only ever ask because I care.",
        "Windhawk asks too many questions about Nightsong. About before. Some dens are better left dark."
      );
    } else if (!f.silent_knows) {
      lines.push(
        "Brightstream looks at me strangely. Like grief wearing a smile. What would SHE have to grieve about me?",
        "I checked the border stones near NightClan. My paws fit the old prints there almost perfectly. Odd. Odd odd odd.",
        "If a cat lied to you your whole life, what would you owe them? Asking for no one. Asking for me."
      );
    } else if (f.told_him_yourself) {
      lines.push(
        "You told me yourself. Do you know what that made you, in the arithmetic? The only number that stayed positive.",
        "I keep turning the truth over like a river stone. Blackstar. Brightstream. It's heavy. It's lighter because it came from your mouth and not out of a wound.",
        "Windhawk talks to me about it now. Actual talking. I'm... practicing not counting her words. It's harder than it sounds.",
        "Some nights the burning still comes. On those nights I walk to the river bend where you told me, and I sit where you sat. It helps. Don't ask me why."
      );
    } else {
      lines.push(
        "Everything I was is a story other cats agreed to tell. Everything except you. You never lied to me. ...You never lied to me, right?",
        "Blood tells, they say. Mine told me last night and I'm still listening.",
        "Stay close to me these next moons, whatever happens. Whatever I do. Especially whatever I do."
      );
    }
    return pick(lines, r);
  }

  if (speaker.id === "nightsong") {
    if (m >= 4 && m <= 12)
      lines.push(
        "You've kept the promise all these moons. I don't forget that, Mistypaw. A secret is a weight — you carry your share without complaint.",
        `${silentName} trains hard. Sometimes too hard. Like he's trying to prove something to a cat who isn't even watching. ...Forget I said that last part.`
      );
    if (m >= 13)
      lines.push(
        `Watch ${silentName} for me, will you? Not because I fear him. Because I fear FOR him. There's a difference — I hope.`,
        "If ever a night comes when I ask you to fetch Brightstream and say nothing else — do it fast. Promise me."
      );
    if (f.silent_knows) lines.push("Whatever happens to me, the truth was mine to guard and I'd guard it again. Remember that when they speak of me.", "It's said now. All of it, at the ravine, in my own voice. I thought the truth would feel like setting something down. It feels like standing very still while the forest decides.");
    return lines.length > 0 && r() < 0.8 ? pick(lines, r) : null;
  }

  if (speaker.id === "brightstream") {
    if (m >= 4 && m <= 12)
      lines.push(
        "You were so small that night, half-asleep in the nursery. I've never thanked you for your silence. Thank you, Mistypaw.",
        `Do you think a lie can be a kindness, if it keeps a family whole? ...Don't answer. Deputies aren't allowed doubts out loud.`
      );
    if (m >= 13)
      lines.push(
        `${silentName} has his father's stillness. It used to comfort me. Lately it frightens me and I hate myself for it.`,
        "Windhawk runs like the moor was poured into her. Some things blood remembers, no matter what we name them."
      );
    if (m >= 18 && !f.silent_knows) lines.push("If he learns it from anyone, let it be from me. I owe him that. I've owed him that since the night he was born.");
    if (f.silent_knows) lines.push("He learned it bleeding out of Nightsong's mouth instead of gently out of mine. Whatever happens now, that part is my doing. Every moon I waited made the truth heavier, and I kept waiting.");
    return lines.length > 0 && r() < 0.8 ? pick(lines, r) : null;
  }

  if (speaker.id === "falconwind") {
    if (m >= 4)
      lines.push(
        "Brightstream took the long way past the nursery again today. Deputies don't have time for long ways. I keep a tally.",
        `${silentName} and Windpaw — you ever notice neither looks a whisker like Nightsong? Litters are strange things. Or stories are.`,
        "I remember a leafbare, moons back, when Brightstream 'patrolled' alone for half a season. My memory is a burr. It holds."
      );
    return lines.length > 0 && r() < 0.5 ? pick(lines, r) : null;
  }

  if (speaker.id === "windpaw") {
    if (m >= 8)
      lines.push(
        "Sometimes I dream of pine trees, Mistypaw. Tall black pines. We don't have pines. Isn't that funny?",
        "Nightsong loves us. I know he does. So why does he flinch when I ask about our mother?"
      );
    if (m >= 13) lines.push(`My brother is changing. Everyone smiles and says warriors grow serious. That's not what this is. You see it too — I know you do.`);
    if (f.windhawk_knows)
      lines.push(
        "Half NightClan, then. Me. The pine dreams weren't dreams, they were memory. I keep waiting to feel different and mostly I just feel... explained.",
        "Nightsong is still my father. Blood doesn't get a vote on that. But my brother took the same truth and it's eating him from the inside out, and I don't know how to reach in after him."
      );
    return lines.length > 0 && r() < 0.6 ? pick(lines, r) : null;
  }

  if (speaker.id === "blackstar") {
    lines.push(
      "You keep secrets well for one so young. Keep mine a while longer, healer.",
      "Two young cats in your Clan carry my shadow in their step. Tell no one I said so — or say it, and see what burns."
    );
    return pick(lines, r);
  }

  if (speaker.id === "snowscar" && m >= 8) {
    lines.push("These old eyes saw Brightstream heavy with more than duty one leafbare, whatever the Clan pretended. The old know when to be quiet. Mostly.");
    return r() < 0.3 ? lines[0] : null;
  }

  if (f.secret_out && speaker.role !== "kit") {
    lines.push(
      `Half-Clan. In OUR Clan. The deputy herself. I don't know what to believe anymore.`,
      `They say ${silentName} was Blackstar's son all along. And Nightsong knew. The whole camp feels like ice about to crack.`
    );
    return r() < 0.6 ? pick(lines, r) : null;
  }

  return null;
}

// ── NPC ↔ NPC ambient chatter ───────────────────────────────────────────────
export function npcChatter(state: GameState, a: Cat, b: Cat, seed: number): [string, string] {
  const r = mulberry(seed);
  const rl = a.rel[b.id];
  const warm = rl ? (rl.friendship + rl.affection) / 2 : 40;
  const opens: string[] = [];
  const replies: string[] = [];
  if (a.speech === "sleepy") opens.push(`*yawn* Wake me when it's greenleaf, ${b.name}.`);
  if (a.speech === "cheerful") opens.push(`${b.name}! Race you around the clearing!`, `Great day, isn't it, ${b.name}?!`);
  if (a.speech === "odd") opens.push(`${b.name}, assess this twig. Honestly now.`);
  if (a.speech === "wary") opens.push(`${b.name}. Notice anything odd about the border scents?`);
  if (a.speech === "blunt") opens.push(`Out of my sunning spot, ${b.name}.`);
  if (a.speech === "gruff") opens.push(`${b.name}, did I ever tell you about the fox of my sixth leafbare?`);
  if (a.speech === "gentle") opens.push(`${b.name}, dear, have you eaten today?`);
  if (a.speech === "quiet") opens.push(`...${b.name}. Have you seen Mistypaw?`);
  opens.push(`Prey's ${state.weather === "snow" ? "scarce" : "running"} today, ${b.name}.`, `${b.name}. All quiet on your side of camp?`);
  if (warm > 65) replies.push(`Always good to see you, ${a.name}.`, `Ha! You never change, ${a.name}.`);
  else if (warm < 35) replies.push(`Hm. If you say so, ${a.name}.`, `I've got duties, ${a.name}.`);
  else replies.push(`True enough, ${a.name}.`, `Mm. Long moon, this one.`);
  if (b.speech === "sleepy") replies.push("*already asleep*");
  if (b.speech === "odd") replies.push("A fine twig would solve this. A fine twig solves most things.");
  if (b.speech === "cheerful") replies.push(`HA! Tell that to the fresh-kill pile, ${a.name}!`);
  return [pick(opens, r), pick(replies, r)];
}

// ── dreams ──────────────────────────────────────────────────────────────────
export interface Dream {
  id: string;
  minMoon: number;
  text: string;
  clue?: string;
  suspicion?: number;
}
export const DREAMS: Dream[] = [
  { id: "d_mist", minMoon: 1, text: "You dream of mist over the river. A voice you almost know says: 'What is hidden is not gone, little healer. Frost preserves everything — even lies.'" },
  { id: "d_feather", minMoon: 4, text: "A black feather falls from a starless sky and lands between two sleeping kits. When you reach for it, it becomes a claw. You wake with your heart drumming.", clue: "dream_feather", suspicion: 3 },
  { id: "d_tworivers", minMoon: 7, text: "Two rivers run side by side — one bright, one dark — then merge so completely you cannot tell which water came from where. Far upstream, a huge black cat drinks alone.", clue: "dream_rivers", suspicion: 3 },
  { id: "d_shadowgrow", minMoon: 8, text: "You dream your own shadow detaches at dusk and follows another cat instead. It grows larger with every step, until the other cat walks entirely inside it. Somewhere, Silentpaw laughs — a sound you've never heard awake.", clue: "dream_shadow", suspicion: 5 },
  { id: "d_pine", minMoon: 11, text: "Pine needles carpet the HollyClan nursery in your dream. Brightstream sweeps them out every night, but every dawn there are more. Nightsong stands guard, growing thinner each time you look.", clue: "dream_pine", suspicion: 4 },
  { id: "d_web", minMoon: 16, text: "A spider's web spans the whole camp, anchored to every den. At its center sits nothing at all — but every strand trembles toward the warriors' den when you breathe your best friend's name.", clue: "dream_web", suspicion: 6 },
  { id: "d_blood", minMoon: 21, text: "Snow falls red in the dream. Three cats stand on the frozen river — one black-and-white, one gray, one black as a hole in the night. The ice cracks in the shape of a star. A voice: 'One truth. Three prices. Choose whose paws stay dry.'", clue: "dream_blood", suspicion: 6 },
];
