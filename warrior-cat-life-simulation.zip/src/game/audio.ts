// Procedural forest ambience via WebAudio — no audio files needed.
export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private windGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private waterGain: GainNode | null = null;
  private birdTimer: ReturnType<typeof setTimeout> | null = null;
  private musicTimer: ReturnType<typeof setTimeout> | null = null;
  enabled = false;
  private mood: "calm" | "tense" | "dark" = "calm";

  start() {
    if (this.ctx) {
      this.enabled = true;
      this.master!.gain.value = 0.5;
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.5;
    this.master.connect(this.ctx.destination);

    const noiseBuf = this.makeNoise();
    // wind: lowpassed noise with slow LFO
    this.windGain = this.addNoiseLayer(noiseBuf, 400, 0.12);
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 0.13;
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 0.06;
    lfo.connect(lfoGain);
    lfoGain.connect(this.windGain.gain);
    lfo.start();
    // rain: brighter noise
    this.rainGain = this.addNoiseLayer(noiseBuf, 2400, 0.0);
    // water: bandpassed babble
    this.waterGain = this.addNoiseLayer(noiseBuf, 900, 0.0, true);

    this.enabled = true;
    this.scheduleBird();
    this.scheduleMusic();
  }

  stop() {
    this.enabled = false;
    if (this.master) this.master.gain.value = 0;
    if (this.birdTimer) clearTimeout(this.birdTimer);
    if (this.musicTimer) clearTimeout(this.musicTimer);
    this.birdTimer = null;
    this.musicTimer = null;
  }

  private makeNoise(): AudioBuffer {
    const ctx = this.ctx!;
    const buf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return buf;
  }

  private addNoiseLayer(buf: AudioBuffer, cutoff: number, gain: number, bandpass = false): GainNode {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = bandpass ? "bandpass" : "lowpass";
    filter.frequency.value = cutoff;
    if (bandpass) filter.Q.value = 0.8;
    const g = ctx.createGain();
    g.gain.value = gain;
    src.connect(filter);
    filter.connect(g);
    g.connect(this.master!);
    src.start();
    return g;
  }

  setEnvironment(weather: string, nearWater: boolean, timeOfDay: string, mood: "calm" | "tense" | "dark") {
    if (!this.ctx || !this.enabled) return;
    this.mood = mood;
    const t = this.ctx.currentTime;
    const windTarget = weather === "wind" || weather === "storm" ? 0.28 : weather === "snow" ? 0.16 : 0.09;
    this.windGain?.gain.setTargetAtTime(windTarget, t, 1.5);
    const rainTarget = weather === "rain" ? 0.14 : weather === "storm" ? 0.24 : 0;
    this.rainGain?.gain.setTargetAtTime(rainTarget, t, 1.5);
    this.waterGain?.gain.setTargetAtTime(nearWater ? 0.12 : 0, t, 1);
    this.birdsActive = (weather === "clear" || weather === "wind") && timeOfDay !== "night";
  }

  private birdsActive = true;
  private scheduleBird() {
    if (!this.enabled) return;
    this.birdTimer = setTimeout(() => {
      if (this.enabled && this.birdsActive && this.ctx) {
        const t = this.ctx.currentTime;
        const chirps = 2 + Math.floor(Math.random() * 4);
        for (let i = 0; i < chirps; i++) {
          const o = this.ctx.createOscillator();
          const g = this.ctx.createGain();
          const f0 = 2200 + Math.random() * 1800;
          o.frequency.setValueAtTime(f0, t + i * 0.14);
          o.frequency.exponentialRampToValueAtTime(f0 * 1.4, t + i * 0.14 + 0.06);
          g.gain.setValueAtTime(0, t + i * 0.14);
          g.gain.linearRampToValueAtTime(0.05, t + i * 0.14 + 0.02);
          g.gain.linearRampToValueAtTime(0, t + i * 0.14 + 0.1);
          o.connect(g);
          g.connect(this.master!);
          o.start(t + i * 0.14);
          o.stop(t + i * 0.14 + 0.12);
        }
      }
      this.scheduleBird();
    }, 2500 + Math.random() * 6000);
  }

  // sparse ambient "music": soft pentatonic tones, darker in tense/dark moods
  private scheduleMusic() {
    if (!this.enabled) return;
    this.musicTimer = setTimeout(() => {
      if (this.enabled && this.ctx) {
        const scales: Record<string, number[]> = {
          calm: [262, 294, 330, 392, 440, 523],
          tense: [262, 277, 330, 370, 415, 494],
          dark: [220, 233, 262, 311, 349, 415],
        };
        const notes = scales[this.mood];
        const t = this.ctx.currentTime;
        const count = 2 + Math.floor(Math.random() * 3);
        for (let i = 0; i < count; i++) {
          const o = this.ctx.createOscillator();
          o.type = "triangle";
          o.frequency.value = notes[Math.floor(Math.random() * notes.length)] / 2;
          const g = this.ctx.createGain();
          const start = t + i * (0.8 + Math.random() * 0.6);
          g.gain.setValueAtTime(0, start);
          g.gain.linearRampToValueAtTime(0.04, start + 0.4);
          g.gain.linearRampToValueAtTime(0, start + 2.4);
          o.connect(g);
          g.connect(this.master!);
          o.start(start);
          o.stop(start + 2.5);
        }
      }
      this.scheduleMusic();
    }, 7000 + Math.random() * 9000);
  }

  footstep(onGrass: boolean) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    o.type = "square";
    o.frequency.value = onGrass ? 90 + Math.random() * 40 : 140 + Math.random() * 60;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.03, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
    o.connect(g);
    g.connect(this.master!);
    o.start(t);
    o.stop(t + 0.07);
  }

  chime(good: boolean) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime;
    const freqs = good ? [523, 659, 784] : [415, 370, 311];
    freqs.forEach((f, i) => {
      const o = this.ctx!.createOscillator();
      o.type = "sine";
      o.frequency.value = f;
      const g = this.ctx!.createGain();
      g.gain.setValueAtTime(0, t + i * 0.09);
      g.gain.linearRampToValueAtTime(0.06, t + i * 0.09 + 0.02);
      g.gain.linearRampToValueAtTime(0, t + i * 0.09 + 0.5);
      o.connect(g);
      g.connect(this.master!);
      o.start(t + i * 0.09);
      o.stop(t + i * 0.09 + 0.55);
    });
  }
}
