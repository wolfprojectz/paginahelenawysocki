import { Cat, GameState, RelStats, Season, StoryEventInstance, Tone, Weather } from "./types";
import { HERB_BY_ID, mulberry, pick, PLAYER_ID, seasonOf } from "./data";
import { DREAMS, Dream } from "./dialogue";
import { SPOTS } from "./world";

// ── small helpers ───────────────────────────────────────────────────────────
export function clamp(v: number, lo = 0, hi = 100) {
  return Math.max(lo, Math.min(hi, v));
}
export function adjRel(state: GameState, from: string, to: string, d: Partial<RelStats>) {
  const c = state.cats[from];
  if (!c || !c.rel[to]) return;
  const r = c.rel[to];
  for (const k of Object.keys(d) as (keyof RelStats)[]) r[k] = clamp(r[k] + (d[k] ?? 0));
}
export function addMemory(state: GameState, catId: string, text: string, tone: Tone, weight: number, about?: string[]) {
  const c = state.cats[catId];
  if (!c) return;
  c.memories.push({ moon: state.moon, text, tone, weight, about });
  if (c.memories.length > 40) {
    // forget the least important old memory
    let minI = 0;
    for (let i = 1; i < c.memories.length - 20; i++) if (c.memories[i].weight < c.memories[minI].weight) minI = i;
    c.memories.splice(minI, 1);
  }
}
export function log(state: GameState, text: string) {
  state.log.push(text);
}
export function aliveCats(state: GameState): Cat[] {
  return Object.values(state.cats).filter((c) => c.alive);
}

// ── leader ascension: any cat who becomes leader gains the "star" suffix ───
// (their old warrior suffix is dropped: Brightstream → BrightStar,
//  Windhawk → WindStar, Sparrowclaw → SparrowStar, …)
const LEADER_NAME_OVERRIDES: Record<string, string> = {
  mistyspark: "SparkStar", // "MistysStar" would be a mouthful even for elders
};
export function makeLeader(state: GameState, id: string, predecessorName: string) {
  const cat = state.cats[id];
  if (!cat || !cat.alive) return;
  const old = cat.name;
  const newName = LEADER_NAME_OVERRIDES[id] ?? cat.baseName + "Star";
  cat.role = "leader";
  cat.lives = 9;
  cat.name = newName;
  log(state, `⭐ ${old} traveled to the Moonpool and received nine lives. ${old} is now ${newName}, leader of HollyClan!`);
  addMemory(state, id, `I traveled to the Moonpool and received my nine lives. ${old} is a name the Clan will remember; ${newName} is the name I must now live up to. ${predecessorName} walks with StarClan.`, "neutral", 10);
  for (const other of aliveCats(state)) {
    if (other.id === id) continue;
    adjRel(state, other.id, id, { respect: 6, loyalty: 4 });
    if ((other.rel[id]?.friendship ?? 0) > 60) addMemory(state, other.id, `${old} became ${newName} beneath the Highrock. Strange, calling an old friend by a leader's name. Good-strange, mostly.`, "good", 6, [id]);
  }
  if (id === "windpaw") state.flags.windstar = true;
}

// ── mentors & training ──────────────────────────────────────────────────────
export function hasMentored(state: GameState, id: string): boolean {
  const c = state.cats[id];
  if (!c) return false;
  if ((c.apprenticesTrained ?? 0) > 0) return true;
  return aliveCats(state).some((a) => (a.role === "apprentice" || a.role === "medapprentice") && a.mentor === id);
}

// The leader chooses a mentor: an experienced, respected warrior with room to
// teach — weighted by respect, prior experience, and current load.
export function assignMentor(state: GameState, appId: string, r: () => number, reason: string): string | null {
  const app = state.cats[appId];
  if (!app || !app.alive) return null;
  const leader = aliveCats(state).find((c) => c.role === "leader");
  const candidates = aliveCats(state).filter((c) => (c.role === "warrior" || c.role === "deputy") && c.id !== appId);
  if (candidates.length === 0) return null;
  let best: Cat | null = null;
  let bestScore = -Infinity;
  for (const c of candidates) {
    const load = aliveCats(state).filter((a) => a.mentor === c.id).length;
    const score =
      (c.rel[appId]?.affection ?? 40) * 0.3 +
      (app.rel[c.id]?.respect ?? 40) * 0.3 +
      (c.apprenticesTrained ?? 0) * 8 +
      c.ageMoons * 0.05 -
      load * 40 +
      r() * 15 -
      (c.traits.includes("lazy") ? 20 : 0);
    if (score > bestScore) {
      bestScore = score;
      best = c;
    }
  }
  if (!best) return null;
  app.mentor = best.id;
  app.trainingProgress = app.trainingProgress ?? 0;
  app.lessons = app.lessons ?? [];
  log(state, `${leader?.name ?? "The leader"} assigned ${best.name} as ${app.name}'s mentor${reason ? ` — ${reason}` : ""}.`);
  addMemory(state, appId, `${best.name} became my mentor${reason ? ` ${reason}` : ""}. A mentor shapes the warrior you become. I watched ${best.gender === "tom" ? "him" : "her"} closely from the first day.`, "neutral", 7, [best.id]);
  addMemory(state, best.id, `I was given ${app.name} to train. Every mentor swears the same silent oath: this one comes back alive from everything.`, "neutral", 6, [appId]);
  adjRel(state, appId, best.id, { respect: 8, trust: 5 });
  adjRel(state, best.id, appId, { affection: 6 });
  return best.id;
}

const LESSONS = [
  "the double-back hunting crouch",
  "how to read a storm-sky before it breaks",
  "scent-marking a border with proper courtesy",
  "moving through leaf-litter without a sound",
  "the defensive roll every young cat fumbles at first",
  "tracking rabbit runs against the wind",
  "when NOT to fight — the hardest lesson",
  "carrying prey without bragging (still in progress)",
  "the Warrior Code, recited under the stars",
  "how to fall from a tree and land insulted but unhurt",
];
const MED_LESSONS = [
  "telling marigold from deathcam by scent alone",
  "packing a wound with cobweb while the patient complains",
  "reading a fever through an ear-touch",
  "the herb-store inventory chant",
  "listening to a dream twice before interpreting it once",
  "how to lose a patient and still hold the next one steady",
];

// Monthly training between each apprentice and their mentor. Relationship
// quality drives progress; sessions can bond or bruise the pair.
function trainingSim(state: GameState, r: () => number) {
  for (const app of aliveCats(state)) {
    if (app.role !== "apprentice" && app.role !== "medapprentice") continue;
    const mentor = app.mentor ? state.cats[app.mentor] : null;
    if (!mentor || !mentor.alive) {
      if (app.id !== PLAYER_ID) log(state, `${app.name} has no mentor this moon — ${app.gender === "tom" ? "his" : "her"} training stalls.`);
      continue;
    }
    const rel = mentor.rel[app.id];
    const bond = ((rel?.affection ?? 40) + (app.rel[mentor.id]?.respect ?? 40)) / 2;
    let gain = 6 + Math.floor(bond / 20) + Math.floor(r() * 4);
    const roll = r();
    const lessonPool = app.role === "medapprentice" ? MED_LESSONS : LESSONS;
    if (roll < 0.28) {
      // breakthrough session
      const lesson = pick(lessonPool, r);
      if (!app.lessons) app.lessons = [];
      if (!app.lessons.includes(lesson)) app.lessons.push(lesson);
      gain += 5;
      adjRel(state, app.id, mentor.id, { respect: 4, affection: 3, trust: 3 });
      adjRel(state, mentor.id, app.id, { affection: 4, respect: 3 });
      log(state, `${mentor.name} taught ${app.name} ${lesson}. The whole camp heard about it at dinner.`);
      if (r() < 0.5) addMemory(state, app.id, `${mentor.name} taught me ${lesson}. I did it right on the ${Math.ceil(r() * 9)}th try. ${mentor.gender === "tom" ? "He" : "She"} pretended not to be pleased. ${mentor.gender === "tom" ? "He" : "She"} was pleased.`, "good", 5, [mentor.id]);
    } else if (roll < 0.4 && (mentor.traits.includes("rude") || mentor.traits.includes("blunt") || bond < 40)) {
      // rough session
      gain = Math.max(2, gain - 4);
      adjRel(state, app.id, mentor.id, { respect: -3, trust: -3, fear: 2 });
      adjRel(state, mentor.id, app.id, { respect: -2 });
      log(state, `${mentor.name} and ${app.name} clashed during training — harsh words carried across the hollow.`);
      addMemory(state, app.id, `${mentor.name} tore into me at training over ${pick(["a sloppy crouch", "a missed catch", "daydreaming mid-drill", "answering back"], r)}. I'll show ${mentor.gender === "tom" ? "him" : "her"}. Somehow.`, "bad", 4, [mentor.id]);
    } else if (bond > 70 && r() < 0.3) {
      adjRel(state, app.id, mentor.id, { affection: 3, loyalty: 3 });
      log(state, `${mentor.name} and ${app.name} shared fresh-kill after training, talking until the stars came out.`);
    }
    app.trainingProgress = Math.min(100, (app.trainingProgress ?? 0) + gain);
  }
}

// A mentor is lost (death/retirement) — the leader must reassign, and the
// apprentice carries it with them.
function reassignOrphanedApprentices(state: GameState, lostMentorId: string, why: "died" | "retired") {
  const r = mulberry(state.moon * 5077 + lostMentorId.length);
  const lost = state.cats[lostMentorId];
  for (const app of aliveCats(state)) {
    if ((app.role !== "apprentice" && app.role !== "medapprentice") || app.mentor !== lostMentorId) continue;
    app.mentor = null;
    addMemory(state, app.id, why === "died"
      ? `My mentor ${lost.name} is gone. Half my training lives in ${lost.gender === "tom" ? "his" : "her"} voice and now I have to finish becoming a warrior without it.`
      : `${lost.name} retired to the elders' den before my training was done. ${lost.gender === "tom" ? "He" : "She"} says ${lost.gender === "tom" ? "he" : "she"}'ll watch my ceremony from the best seat.`, why === "died" ? "grief" : "neutral", 8, [lostMentorId]);
    app.mood = why === "died" ? "grieving" : app.mood;
    app.trainingProgress = Math.max(0, (app.trainingProgress ?? 0) - (why === "died" ? 8 : 3));
    const newId = assignMentor(state, app.id, r, why === "died" ? `after ${lost.name}'s death` : `after ${lost.name} retired`);
    if (newId) adjRel(state, app.id, newId, { trust: -5 }); // a new bond starts guarded
  }
}

export function killCat(state: GameState, id: string, cause: string) {
  const c = state.cats[id];
  if (!c || !c.alive) return;
  // leaders spend StarClan lives before dying for good
  if (c.lives !== undefined && c.lives > 1) {
    c.lives--;
    c.sick = null;
    c.health = 60;
    log(state, `★ ${c.name} lost a life — ${cause}. StarClan sent ${c.gender === "tom" ? "him" : "her"} back: ${c.lives} ${c.lives === 1 ? "life" : "lives"} of nine remain.`);
    addMemory(state, c.id, `I died — ${cause} — and woke at the Moonpool with StarClan's breath still in my fur. ${c.lives} ${c.lives === 1 ? "life" : "lives"} left. I must spend them well.`, "neutral", 9);
    for (const other of aliveCats(state)) {
      if (other.id !== id && (other.rel[id]?.respect ?? 0) > 40) adjRel(state, other.id, id, { respect: 4 });
    }
    return;
  }
  c.alive = false;
  c.deathMoon = state.moon;
  c.deathCause = cause;
  c.sick = null;
  log(state, `☆ ${c.name} has died: ${cause}. The Clan sits vigil beneath the stars.`);
  for (const other of aliveCats(state)) {
    if (other.id === id) continue;
    const rl = other.rel[id];
    if (rl && rl.affection > 55) {
      other.mood = "grieving";
      addMemory(state, other.id, `${c.name} died — ${cause}. I sat vigil until dawn. The camp has a hole in it now, shaped exactly like ${c.gender === "tom" ? "him" : "her"}.`, "grief", 9, [id]);
    } else {
      addMemory(state, other.id, `${c.name} died — ${cause}.`, "grief", 5, [id]);
    }
  }
  // succession — a deputy must have trained at least one apprentice
  if (c.role === "deputy") {
    const wind = state.cats.windpaw;
    const heir =
      wind && wind.alive && wind.role === "warrior" && hasMentored(state, "windpaw")
        ? wind
        : aliveCats(state).find((x) => x.role === "warrior" && x.id === "sparrowclaw" && hasMentored(state, x.id)) ??
          aliveCats(state).find((x) => x.role === "warrior" && hasMentored(state, x.id)) ??
          aliveCats(state).find((x) => x.role === "warrior");
    if (heir) {
      heir.role = "deputy";
      log(state, `${state.cats.maplestar?.alive ? "MapleStar" : "The leader"} named ${heir.name} the new deputy of HollyClan${hasMentored(state, heir.id) ? "" : " — waiving the mentorship tradition in desperate times"}.`);
      addMemory(state, heir.id, `I was named deputy after ${c.name}'s death. The weight settled on my shoulders like snow that will not melt.`, "neutral", 9);
    }
  }
  if (c.role === "leader") {
    const dep = aliveCats(state).find((x) => x.role === "deputy");
    if (dep) {
      makeLeader(state, dep.id, c.name);
      // the new leader elects a deputy — Windhawk first in line, and a deputy
      // must have trained at least one apprentice
      const wind = state.cats.windpaw;
      const newDep =
        dep.id !== "windpaw" && wind?.alive && wind.role === "warrior" && hasMentored(state, "windpaw")
          ? wind
          : aliveCats(state).find((x) => x.role === "warrior" && x.id === "sparrowclaw" && hasMentored(state, x.id)) ??
            aliveCats(state).find((x) => x.role === "warrior" && x.id !== dep.id && hasMentored(state, x.id)) ??
            aliveCats(state).find((x) => x.role === "warrior" && x.id !== dep.id);
      if (newDep) {
        newDep.role = "deputy";
        log(state, `${dep.name} elected ${newDep.name} as the new deputy of HollyClan.`);
        addMemory(state, newDep.id, `${dep.name} named me deputy before the whole Clan. I said the words steadily. My paws have not felt steady since.`, "neutral", 9, [dep.id]);
        addMemory(state, dep.id, `I chose ${newDep.name} as my deputy. Let StarClan judge whether I chose with my head or my heart.`, "neutral", 8, [newDep.id]);
      }
    }
  }
  // if the fallen cat was mentoring anyone, the leader must reassign
  reassignOrphanedApprentices(state, id, "died");
}

// ── weather ─────────────────────────────────────────────────────────────────
export function rollWeather(moon: number, r: () => number): Weather {
  const s = seasonOf(moon);
  const table: Record<Season, [Weather, number][]> = {
    Newleaf: [["clear", 0.4], ["rain", 0.3], ["wind", 0.15], ["fog", 0.1], ["storm", 0.05]],
    Greenleaf: [["clear", 0.6], ["rain", 0.15], ["storm", 0.15], ["wind", 0.1]],
    "Leaf-fall": [["wind", 0.3], ["clear", 0.25], ["rain", 0.25], ["fog", 0.2]],
    Leafbare: [["snow", 0.45], ["clear", 0.2], ["fog", 0.15], ["wind", 0.2]],
  };
  let roll = r();
  for (const [w, p] of table[s]) {
    roll -= p;
    if (roll <= 0) return w;
  }
  return "clear";
}

// ── time & routines ─────────────────────────────────────────────────────────
const TIMES = ["dawn", "day", "dusk", "night"] as const;
export function advanceTime(state: GameState) {
  state.timeTicks++;
  const idx = TIMES.indexOf(state.timeOfDay);
  state.timeOfDay = TIMES[(idx + 1) % 4];
  assignRoutines(state, Math.floor(Math.random() * 1e9));
}

// each role sleeps in its designated den
function nightDenOf(c: Cat): string {
  switch (c.role) {
    case "leader": return "leaderden";
    case "deputy": return "warriorsden";
    case "warrior": return "warriorsden";
    case "apprentice": return "apprenticeden";
    case "medicine":
    case "medapprentice": return "medden";
    case "elder": return "eldersden";
    case "queen":
    case "kit": return "nursery";
    default: return "border"; // outsiders sleep on their own side of the line
  }
}

export function assignRoutines(state: GameState, seed: number) {
  const r = mulberry(seed);
  const t = state.timeOfDay;

  // ── NIGHT CURFEW: when night falls, every cat returns to their den ──
  if (t === "night") {
    let guardAssigned = false;
    for (const c of aliveCats(state)) {
      if (c.id === PLAYER_ID) continue;
      // the badly sick sleep in the medicine den, under the healer's eye
      let spot = c.sick && c.sick.severity >= 2 ? "medden" : nightDenOf(c);
      let act = "resting";
      // one warrior keeps the night watch at the entrance
      if (!guardAssigned && (c.role === "warrior" || c.role === "deputy") && !c.sick && c.id !== "stonefur" && r() < 0.5) {
        spot = "entrance";
        act = "keeping watch";
        guardAssigned = true;
      }
      // Silentshadow, in his obsessive era, sometimes isn't in his nest at all —
      // he sits outside the medicine den, "counting stars", facing the den
      if (c.id === "silentpaw" && c.role !== "apprentice" && state.moon >= 7 && !state.flags.truth_gentled && r() < (state.moon <= 8 ? 0.35 : 0.18)) {
        const med = SPOTS.medden;
        c.map = med.map;
        c.tx = med.x + 2 + Math.floor(r() * 2);
        c.ty = med.y + 2;
        c.activity = "watching";
        continue;
      }
      const s = SPOTS[spot];
      c.map = s.map;
      // tight spread so cats are actually inside their dens
      c.tx = s.x + Math.floor(r() * 3 - 1);
      c.ty = s.y + Math.floor(r() * 2 - 1);
      c.activity = act;
    }
    return;
  }

  // ── DAYTIME ROUTINES ──
  for (const c of aliveCats(state)) {
    if (c.id === PLAYER_ID) continue;
    let spot = "clearing";
    let act = "resting";
    if (c.sick && c.sick.severity >= 2) {
      spot = "medden";
      act = "resting";
    } else if (c.id === "blackstar") {
      spot = "border";
      act = r() < 0.5 ? "patrolling" : "resting";
    } else if (c.role === "kit") {
      spot = r() < 0.6 ? "nursery" : "clearing";
      act = "playing";
    } else if (c.role === "queen") {
      spot = r() < 0.7 ? "nursery" : "freshkill";
      act = "caring for kits";
    } else if (c.role === "elder") {
      spot = r() < 0.5 ? "eldersden" : "clearing";
      act = r() < 0.5 ? "talking" : "resting";
    } else if (c.role === "medicine" || c.role === "medapprentice") {
      spot = r() < 0.6 ? "medden" : "herbstore";
      act = "sorting herbs";
    } else if (c.role === "leader") {
      spot = r() < 0.5 ? "leaderden" : "clearing";
      act = "talking";
    } else if (c.role === "apprentice") {
      const roll = r();
      if (roll < 0.35) {
        spot = "training";
        act = "training";
      } else if (roll < 0.6) {
        spot = "hunting";
        act = "hunting";
      } else {
        spot = "clearing";
        act = "talking";
      }
    } else {
      // warriors & deputy
      const roll = r();
      if (c.id === "stonefur" && roll < 0.6) {
        spot = "clearing";
        act = "resting";
      } else if (roll < 0.3) {
        spot = "hunting";
        act = "hunting";
      } else if (roll < 0.5) {
        spot = "border";
        act = "patrolling";
      } else if (roll < 0.65) {
        spot = "freshkill";
        act = "eating";
      } else if (roll < 0.8) {
        spot = "clearing";
        act = "talking";
      } else {
        spot = "river";
        act = "hunting";
      }
    }
    // Silentpaw gravitates toward the player (moons 7-8: peak obsession)
    if (c.id === "silentpaw" && state.moon >= 7 && r() < (state.moon <= 8 ? 0.75 : state.moon >= 13 ? 0.55 : 0.35)) {
      c.map = state.playerMap;
      c.tx = state.px + Math.floor(r() * 5 - 2);
      c.ty = state.py + Math.floor(r() * 5 - 2);
      c.activity = "watching";
      continue;
    }
    const s = SPOTS[spot];
    c.map = s.map;
    c.tx = s.x + Math.floor(r() * 5 - 2);
    c.ty = s.y + Math.floor(r() * 3 - 1);
    c.activity = act;
  }
}

// ── sickness generation ─────────────────────────────────────────────────────
const AILMENTS: { name: string; herb: string; severity: number; seasons: Season[] }[] = [
  { name: "whitecough", herb: "catmint", severity: 1, seasons: ["Leaf-fall", "Leafbare"] },
  { name: "greencough", herb: "catmint", severity: 3, seasons: ["Leafbare"] },
  { name: "an infected scratch", herb: "marigold", severity: 2, seasons: ["Newleaf", "Greenleaf", "Leaf-fall", "Leafbare"] },
  { name: "a torn claw wound", herb: "cobweb", severity: 1, seasons: ["Newleaf", "Greenleaf", "Leaf-fall", "Leafbare"] },
  { name: "bellyache from bad prey", herb: "juniper", severity: 1, seasons: ["Greenleaf", "Leaf-fall"] },
  { name: "a burning fever", herb: "feverfew", severity: 2, seasons: ["Newleaf", "Leafbare"] },
  { name: "an infected bite", herb: "horsetail", severity: 2, seasons: ["Newleaf", "Greenleaf", "Leaf-fall"] },
];

function makeSomeoneSick(state: GameState, r: () => number, forced?: string) {
  const candidates = aliveCats(state).filter((c) => c.id !== PLAYER_ID && c.role !== "outsider" && !c.sick);
  if (candidates.length === 0) return;
  // elders and kits more vulnerable
  const weighted = candidates.flatMap((c) => (c.role === "elder" || c.role === "kit" ? [c, c] : [c]));
  const victim = forced ? state.cats[forced] : pick(weighted, r);
  if (!victim || victim.sick || !victim.alive) return;
  const season = seasonOf(state.moon);
  const options = AILMENTS.filter((a) => a.seasons.includes(season));
  const ail = pick(options, r);
  victim.sick = { name: ail.name, herb: ail.herb, moonsLeft: ail.severity + 1, severity: ail.severity };
  victim.health = clamp(victim.health - ail.severity * 12);
  victim.mood = "unwell";
  log(state, `${victim.name} has fallen ill with ${ail.name}. ${HERB_BY_ID[ail.herb].name} is needed.`);
}

// ── NPC autonomous social simulation ───────────────────────────────────────
function socialSim(state: GameState, r: () => number) {
  const cats = aliveCats(state).filter((c) => c.id !== PLAYER_ID && c.role !== "outsider");
  const interactions = 5 + Math.floor(r() * 4);
  for (let i = 0; i < interactions; i++) {
    const a = pick(cats, r);
    let b = pick(cats, r);
    if (a.id === b.id) continue;
    const rl = a.rel[b.id];
    const harsh = a.traits.includes("rude") || a.traits.includes("occasionally cruel") || a.traits.includes("blunt");
    const kind = a.traits.includes("empathetic") || a.traits.includes("kind") || a.traits.includes("nurturing") || a.traits.includes("peacemaker");
    const roll = r();
    if (harsh && roll < 0.4) {
      adjRel(state, a.id, b.id, { friendship: -3 });
      adjRel(state, b.id, a.id, { friendship: -5, affection: -4, respect: -3 });
      const line = `${a.name} snapped at ${b.name} over ${pick(["the fresh-kill pile", "a missed patrol", "nothing anyone could name", "a clumsy pounce"], r)}.`;
      log(state, line);
      addMemory(state, b.id, `${a.name} humiliated me in front of the others. I keep score, even when I pretend not to.`, "bad", 4, [a.id]);
    } else if (kind && roll < 0.5) {
      adjRel(state, a.id, b.id, { friendship: 3, affection: 2 });
      adjRel(state, b.id, a.id, { friendship: 4, affection: 4, trust: 3 });
      const line = `${a.name} ${pick(["shared fresh-kill with", "comforted", "helped patch the nest of", "hunted alongside"], r)} ${b.name}.`;
      log(state, line);
      if (r() < 0.5) addMemory(state, b.id, `${a.name} was kind to me when ${pick(["the day ran long", "I needed it most", "no one else noticed"], r)}. Small things hold a Clan together.`, "good", 3, [a.id]);
    } else if (roll < 0.65 && rl && rl.friendship > 60) {
      adjRel(state, a.id, b.id, { friendship: 2, trust: 2 });
      adjRel(state, b.id, a.id, { friendship: 2, trust: 2 });
      if (r() < 0.3) log(state, `${a.name} and ${b.name} were seen sharing tongues at dusk, thick as thieves.`);
    } else {
      adjRel(state, a.id, b.id, { friendship: 1 });
    }
  }
  // Silentpaw's jealousy engine (after warrior name)
  const silent = state.cats.silentpaw;
  if (silent?.alive && state.moon >= 8) {
    const rivals = cats.filter((c) => {
      const pr = state.cats[PLAYER_ID].rel[c.id];
      return c.id !== "silentpaw" && pr && pr.friendship > 60;
    });
    if (rivals.length > 0 && r() < 0.75) {
      const rival = pick(rivals, r);
      adjRel(state, "silentpaw", rival.id, { jealousy: 4 + Math.floor(state.moon / 6), suspicion: 3, friendship: -3 });
      adjRel(state, rival.id, "silentpaw", { fear: 2 + Math.floor(Math.max(0, state.moon - 7) / 4), suspicion: 3 });
      if (state.moon >= 9 && r() < 0.5) {
        const incident = pick(
          [
            `${silent.name} stood outside the medicine den half the night. When asked, he said he was "counting stars." He was facing the den.`,
            `${rival.name} found claw marks on their nest moss. No one saw anything. ${silent.name} was first to offer sympathy.`,
            `${silent.name} told ${rival.name}, smiling, that medicine cats need quiet — and fewer visitors.`,
            `A vole ${rival.name} had set aside vanished. ${silent.name} suggested, softly, that some cats take more than their share of everything.`,
          ],
          r
        );
        log(state, incident);
        addMemory(state, rival.id, `Something about ${silent.name} has changed since he got his warrior name. I told myself I imagined it. I'm running out of imagination.`, "bad", 6, ["silentpaw"]);
      }
    }
  }
}

// ── random moon events ──────────────────────────────────────────────────────
function randomEvents(state: GameState, r: () => number) {
  const season = seasonOf(state.moon);
  // sickness chance
  const sickChance = season === "Leafbare" ? 0.75 : season === "Leaf-fall" ? 0.5 : 0.3;
  if (r() < sickChance) makeSomeoneSick(state, r);
  if (season === "Leafbare" && r() < 0.35) makeSomeoneSick(state, r);
  // flavor events
  const flavor: string[] = [];
  if (r() < 0.4) flavor.push(`${pick(aliveCats(state).filter((c) => c.role === "warrior"), r)?.name ?? "A warrior"} caught ${pick(["a rabbit fat as two moons", "three voles in one morning", "a magpie mid-flight"], r)}. The fresh-kill pile is generous.`);
  if (r() < 0.3) flavor.push(`A ${pick(["fox scent", "dog barking beyond the border", "monster roaring on the far Thunderpath"], r)} kept the night watch tense.`);
  if (r() < 0.25 && state.cats.twiggatherer?.alive) flavor.push(`Twiggatherer's twig collection collapsed ${pick(["onto Stonefur while he slept", "across the camp entrance", "in the night with a sound like tiny thunder"], r)}. He is rebuilding it, sorted by bendiness.`);
  if (r() < 0.25) {
    const border = pick(["NightClan scent was found a fox-length INSIDE the border.", "A NightClan patrol watched ours across the scent line without a word.", "Blackstar himself was seen at the border, staring toward camp."], r);
    flavor.push(border);
    if (border.includes("Blackstar")) state.flags.blackstar_seen = ((state.flags.blackstar_seen as number) || 0) + 1;
  }
  for (const f of flavor) log(state, f);
  // herb decay/theft in storm
  if (state.weather === "storm" && r() < 0.4) {
    const herbIds = Object.keys(state.herbs).filter((h) => state.herbs[h] > 0);
    if (herbIds.length > 0) {
      const h = pick(herbIds, r);
      state.herbs[h] = Math.max(0, state.herbs[h] - 1);
      log(state, `The storm soaked part of the herb store — some ${HERB_BY_ID[h].name.toLowerCase()} were ruined.`);
    }
  }
}

// ── age-driven lifecycle ────────────────────────────────────────────────────
// Rules: 0-6 moons = kit · 6-12 = apprentice ("paw") · 12+ = warrior (suffix)
// · too old to fulfill their role = elder. Canonical names for known cats,
// random warrior suffix for anyone else.
const CANON_WARRIOR_NAMES: Record<string, string> = {
  silentpaw: "Silentshadow",
  hollypaw: "Hollyspark",
  windpaw: "Windhawk",
  mousekit: "Mousewhisker",
  moonkit: "Moonshimmer",
  falconkit: "Falconclaw",
  firekit: "Fireblaze",
  bluekit: "Bluescar",
};
const WARRIOR_SUFFIXES = ["claw", "heart", "fur", "tail", "whisker", "pelt", "storm", "fang", "leap", "stripe", "song", "flight"];
const ELDER_AGE = 120;

function lifecycle(state: GameState, r: () => number) {
  const rename = (id: string, newName: string, newRole: Cat["role"]) => {
    const c = state.cats[id];
    if (!c || !c.alive) return;
    const old = c.name;
    c.name = newName;
    c.role = newRole;
    log(state, `⭐ ${old} is now ${newName}!`);
    addMemory(state, id, `The Clan called my new name to the sky: ${newName}! ${old} is a story now; ${newName} is the rest of my life.`, "good", 8);
  };
  for (const c of aliveCats(state)) {
    if (c.role === "outsider") continue;
    // kit → apprentice at 6 moons; the leader assigns a mentor
    if (c.role === "kit" && c.ageMoons >= 6) {
      log(state, `⭐ Ceremony! ${c.name} has reached six moons.`);
      rename(c.id, c.baseName + "paw", "apprentice");
      c.trainingProgress = 0;
      c.lessons = [];
      assignMentor(state, c.id, r, "");
      continue;
    }
    // apprentice → warrior at 12 moons — IF the leader judges training complete
    // (medicine apprentice → full medicine cat)
    if ((c.role === "apprentice" || c.role === "medapprentice") && c.ageMoons >= 12) {
      const progress = c.trainingProgress ?? 50;
      if (progress < 40) {
        if (!state.flags["delaynote_" + c.id + "_" + state.moon]) {
          log(state, `${c.name} has reached twelve moons, but the leader judges ${c.gender === "tom" ? "his" : "her"} training incomplete. The ceremony waits.`);
          state.flags["delaynote_" + c.id + "_" + state.moon] = true;
        }
        continue;
      }
      const mentorId = c.mentor;
      const graduate = (id: string, newName: string, role: Cat["role"]) => {
        rename(id, newName, role);
        if (mentorId && state.cats[mentorId]) {
          const men = state.cats[mentorId];
          men.apprenticesTrained = (men.apprenticesTrained ?? 0) + 1;
          addMemory(state, mentorId, `${newName} finished training under me. Whatever ${state.cats[id].gender === "tom" ? "he" : "she"} becomes now is ${state.cats[id].gender === "tom" ? "his" : "hers"} — but the crouch, the patience, the code? Those are mine, and I'm keeping the pride.`, "good", 7, [id]);
          adjRel(state, id, mentorId, { respect: 6, affection: 5, loyalty: 5 });
          adjRel(state, mentorId, id, { respect: 6, affection: 4 });
        }
        state.cats[id].mentor = null;
      };
      if (c.id === PLAYER_ID) {
        graduate(PLAYER_ID, "Mistyblaze", "medicine");
        addMemory(state, PLAYER_ID, "Juniperfang touched her nose to my head at the Moonpool. I am Mistyblaze, full medicine cat of HollyClan. Silentshadow watched me the entire ceremony. He didn't blink once.", "good", 10, ["juniperfang", "silentpaw"]);
        state.pendingEvents.push("warrior_names");
        continue;
      }
      let newName = CANON_WARRIOR_NAMES[c.id];
      if (!newName) {
        const taken = new Set(Object.values(state.cats).map((x) => x.name.toLowerCase()));
        let suffix = pick(WARRIOR_SUFFIXES, r);
        for (let tries = 0; tries < 12 && taken.has((c.baseName + suffix).toLowerCase()); tries++) suffix = pick(WARRIOR_SUFFIXES, r);
        newName = c.baseName + suffix;
      }
      graduate(c.id, newName, "warrior");
      // Windhawk takes her first apprentice as soon as she is named a warrior —
      // a new warrior often does, and a future deputy must have trained one.
      if (c.id === "windpaw") {
        const pool = aliveCats(state).filter((a) => a.role === "apprentice" && a.id !== c.id);
        if (pool.length > 0) {
          const chosen = pool.reduce((worst, a) => {
            const loadA = a.mentor ? aliveCats(state).filter((x) => x.mentor === a.mentor).length : 99;
            const loadW = worst.mentor ? aliveCats(state).filter((x) => x.mentor === worst.mentor).length : 99;
            return loadA > loadW ? a : worst;
          });
          const oldMentor = chosen.mentor ? state.cats[chosen.mentor]?.name : null;
          chosen.mentor = c.id;
          log(state, `${aliveCats(state).find((x) => x.role === "leader")?.name ?? "The leader"} entrusted ${chosen.name} to the new warrior ${c.name}${oldMentor ? ` (taking over from ${oldMentor})` : ""} — her first apprentice.`);
          addMemory(state, chosen.id, `${c.name} became my mentor the very day she got her warrior name. She trains like she runs: flat out, no excuses. I'm going to be so fast.`, "good", 6, [c.id]);
          addMemory(state, c.id, `My first apprentice, given to me the day I was named. Nightsong just nodded when he heard, like he'd expected nothing less.`, "good", 7, [chosen.id]);
        }
      }
      continue;
    }
    // queens return to warrior duty once no kits remain in the nursery
    if (c.role === "queen" && !aliveCats(state).some((k) => k.role === "kit")) {
      c.role = "warrior";
      log(state, `${c.name} has left the nursery and returned to warrior duties.`);
      continue;
    }
    // old warriors retire to the elders' den
    if ((c.role === "warrior" || c.role === "queen") && c.ageMoons >= ELDER_AGE) {
      c.role = "elder";
      log(state, `⭐ ${c.name} has retired to the elders' den, honored for a lifetime of service.`);
      addMemory(state, c.id, "I moved my nest to the elders' den. My legs went before my pride did. Now I trade hunting for stories — a fair exchange, most days.", "neutral", 7);
      reassignOrphanedApprentices(state, c.id, "retired");
    }
  }
}

// ── untreated sickness consequences ────────────────────────────────────────
function resolveSickness(state: GameState, r: () => number) {
  for (const c of aliveCats(state)) {
    if (!c.sick) continue;
    const haveHerb = (state.herbs[c.sick.herb] ?? 0) > 0;
    // Juniperfang auto-treats one cat per moon if herbs exist and she's alive
    if (haveHerb && state.cats.juniperfang?.alive && r() < 0.5) {
      state.herbs[c.sick.herb]--;
      log(state, `Juniperfang treated ${c.name}'s ${c.sick.name} with ${HERB_BY_ID[c.sick.herb].name.toLowerCase()}.`);
      c.sick = null;
      c.health = clamp(c.health + 20);
      c.mood = "content";
      continue;
    }
    c.sick.moonsLeft--;
    c.health = clamp(c.health - c.sick.severity * 15);
    if (c.health <= 0) {
      killCat(state, c.id, `succumbed to ${c.sick.name} — the herb store had no ${HERB_BY_ID[c.sick.herb].name.toLowerCase()} when it mattered`);
      adjRel(state, "shadowgaze", PLAYER_ID, { respect: -5 });
      continue;
    }
    if (c.sick.moonsLeft <= 0 && c.sick.severity === 1) {
      log(state, `${c.name} fought off ${c.sick.name} without help, though it cost ${c.gender === "tom" ? "him" : "her"} dearly.`);
      c.sick = null;
    } else {
      log(state, `${c.name} still suffers from ${c.sick.name}. ${haveHerb ? "Herbs sit unused in the store." : `There is no ${HERB_BY_ID[c.sick.herb].name.toLowerCase()} in the store.`}`);
      adjRel(state, c.id, PLAYER_ID, { trust: -3 });
    }
  }
}

// ── herb regrowth ───────────────────────────────────────────────────────────
function regrowHerbs(state: GameState, r: () => number) {
  const season = seasonOf(state.moon);
  for (const n of state.herbNodes) {
    const def = HERB_BY_ID[n.herb];
    if (!def.seasons.includes(season)) {
      if (n.herb !== "cobweb") n.qty = 0;
      continue;
    }
    if (n.qty < n.max && r() < 0.7) n.qty++;
  }
}

// ── who does Silentshadow circle next? Depends entirely on what happened ──
export function pickShadowTarget(state: GameState, wave: number): { id: string; why: string } | null {
  const alive = (id: string) => state.cats[id]?.alive;
  const candidates: { id: string; why: string; cond: boolean }[] = [
    { id: "falconwind", why: "you told her the secret — and he has learned who keeps tallies", cond: !!state.flags.falcon_knows },
    { id: "maplestar", why: "she summoned him to the Highrock ledge and asked one question too many", cond: !!state.flags.told_maplestar },
    { id: "hollypaw", why: "she warned you about him once, and he never forgot the shape of that conversation", cond: !!state.flags.told_brightstream_fears || !!state.flags.watching_silent },
    { id: "wolftail", why: "she is your mother — the last thread tying you to anyone but him", cond: state.suspicion >= 50 },
    { id: "sparrowclaw", why: "she has been gently gathering the frightened around her, and gatherings are threats", cond: true },
  ];
  const picked = candidates.filter((c) => c.cond && alive(c.id));
  return picked[Math.min(wave, picked.length - 1)] ?? null;
}

// ══ STORY EVENTS ════════════════════════════════════════════════════════════
export function getEventInstance(state: GameState, id: string): StoryEventInstance | null {
  const silentName = state.cats.silentpaw?.name ?? "Silentshadow";
  const playerName = state.cats[PLAYER_ID].name;
  switch (id) {
    case "intro":
      return {
        id,
        title: "Moon 1 — The Medicine Den",
        text:
          `You are ${playerName}, medicine cat apprentice of HollyClan, son of Wolftail and Shadowgaze.\n\n` +
          `You carry two things heavier than any herb bundle: your training under Juniperfang — and a memory. As a tiny kit, you saw Brightstream slip into camp on a freezing night with two newborn kits that smelled of pine and another Clan. Nightsong met her. He saw you watching, and asked for your silence. You gave it.\n\n` +
          `Those kits are Silentpaw and Windpaw now. Silentpaw is your best friend. He believes Nightsong is his father.\n\n` +
          `Live your life. Gather herbs, heal your Clanmates, talk, explore, train, dream. When you are ready, PASS THE MOON. The Clan lives on with or without your attention — and everything you do, or fail to do, will follow you.`,
        choices: [{ label: "Begin" }],
      };
    case "warrior_names":
      return {
        id,
        title: "Moon 7 — Four Names Under the Stars",
        speaker: "silentpaw",
        text:
          `The Clan chants late into the night: Silentshadow! Hollyspark! Windhawk! Mistyblaze!\n\n` +
          `Afterward, Silentshadow finds you at the edge of the firelight. His eyes are very green and very still.\n\n` +
          `"Mistyblaze," he says, tasting the name. "A blaze needs a shadow, or it means nothing. Everything is different now — except us. Promise me us stays the same. Promise me nothing gets between."`,
        choices: [
          { label: '"I promise. Nothing changes between us."' },
          { label: '"We\'re warriors now. Things change — that\'s not a bad thing."' },
          { label: "Say nothing, and watch how he reacts." },
        ],
      };
    case "clue_falcon":
      return {
        id,
        title: "Falconwind's Tally",
        speaker: "falconwind",
        text:
          `Falconwind corners you by the herb store, voice low.\n\n"You're the observant sort, healer. So am I. Riddle me this: Brightstream disappears for half a season, moons ago. Comes back thin. That same leafbare, Nightsong — a cat with no mate anyone ever saw — suddenly has two kits in the nursery. And neither of those kits has a single white hair or a single one of his."\n\nHer blue eyes pin you. "You were a kit in that nursery. Kits see things. What did you see?"`,
        choices: [
          { label: '"I saw nothing. I was asleep." (Lie to protect the secret)' },
          { label: '"Even if I saw something, it wouldn\'t be mine to tell."' },
          { label: "Tell her what you saw that night. (Break your promise)" },
        ],
      };
    case "silent_gift":
      return {
        id,
        title: "A Gift at Dawn",
        speaker: "silentpaw",
        text:
          `You find a perfect sprig of catmint laid across your nest — rare, out of season, impossible. ${silentName} sits outside the den, tail wrapped over his paws.\n\n"I went to the far ravine at night," he says. "You said the store was short. You say a lot of things quietly. I hear all of them."\n\nThe ravine is beyond NightClan's border.`,
        choices: [
          { label: "Thank him warmly — it's a kind, brave gift." },
          { label: '"You crossed the border?! You can\'t DO that for me."' },
          { label: "Accept it, but quietly note how far he went. (+Suspicion)" },
        ],
      };
    case "holly_warning":
      return {
        id,
        title: "Hollyspark's Unease",
        speaker: "hollypaw",
        text:
          `Hollyspark pulls you behind the elders' den, all her usual laughter gone.\n\n"I'm only saying this once, so listen. Yesterday I told ${silentName} you and I were going hunting at dawn. He smiled — that new smile — and this morning my nest moss was shredded. Everyone says a badger dream, claws in sleep, whatever. Misty. It was ONLY my nest."\n\nShe searches your face. "You know him best. Tell me I'm imagining it."`,
        choices: [
          { label: '"You\'re imagining it. He\'d never." (Defend Silentshadow)' },
          { label: '"...I\'ll watch him. Quietly. Stay near others for now."' },
          { label: '"Something IS wrong. Let\'s go to Brightstream together."' },
        ],
      };
    case "nightsong_request":
      return {
        id,
        title: "Nightsong's Fear",
        speaker: "nightsong",
        text:
          `Nightsong finds you gathering moss and speaks without preamble, eyes on the treeline.\n\n"All his life I've raised him as mine and loved him as mine — that part was never a lie. But lately he asks questions with edges on them. Where was he born. Why does he dream of pine. Why his paws are so big." A long breath. "${playerName}, if he ever asks YOU — what will you say?"`,
        choices: [
          { label: '"I\'ll keep the secret, like I promised that night."' },
          { label: '"He deserves the truth. It should come from you and Brightstream."' },
          { label: '"I don\'t know anymore. The secret is starting to rot."' },
        ],
      };
    case "evidence_moment":
      return {
        id,
        title: "The Weight of Knowing",
        text:
          `Alone in the medicine den, the pieces you've gathered press on you like stones: the dreams, Falconwind's tally, ${silentName}'s pilgrimages to the border, the way Brightstream's eyes follow him with grief pre-loaded.\n\nThe secret is straining at its seams. Someone is going to tear it open — the only question left is who, and how gently.\n\nWhat do you do with what you know?`,
        choices: [
          { label: "Tell MapleStar everything, in private. The Clan's safety comes first." },
          { label: "Urge Brightstream and Nightsong to tell Silentshadow themselves, soon." },
          { label: "Keep the secret sealed. It has held their whole lives; it can hold longer." },
        ],
      };
    case "blackstar_visit": {
      if (!state.cats.blackstar?.alive) return null;
      return {
        id,
        title: "Moon 3 — The Leader at the Border",
        speaker: "blackstar",
        text:
          `Juniperfang sends you alone to the far marigold patch — and he is simply THERE, the way night is there: Blackstar of NightClan, huge and still on his own side of the scent line, waiting for you specifically.\n\n` +
          `"The young healer who keeps secrets," he says. "I know what you saw, the night you were small. She told me a kit's eyes were open in the nursery dark."\n\n` +
          `His gaze doesn't waver. "I ask one thing and then I am gone: the two young cats. The black one and the white one. How do they fare? Speak to me of them — a leader cannot ask twice."`,
        choices: [
          { label: "Tell him honestly — their training, their laughter, who they're becoming." },
          { label: '"You gave up the right to ask the night you let her carry them alone."' },
          { label: 'Ask your own question instead: "Why did you stay away?"' },
          { label: "Say nothing. Gather your marigold and leave the silence to him." },
        ],
      };
    }
    case "gathering_shadow": {
      if (!state.cats.blackstar?.alive || !state.cats.silentpaw?.alive) return null;
      const sn = state.cats.silentpaw.name;
      return {
        id,
        title: "Moon 9 — The Gathering",
        speaker: "silentpaw",
        text:
          `The full-moon Gathering, all Clans under truce light. You attend as a medicine cat; ${sn} attends as a new warrior, and spends the night being watched.\n\n` +
          `Because Blackstar cannot stop looking at him. The leader of NightClan tracks ${sn} across the clearing the entire night — not hostile, not curious. Hungry, the way a cat looks at a season it missed.\n\n` +
          `${sn} notices. Of course he notices; he counts everything. On the walk home he falls in beside you, voice low:\n\n"NightClan's leader stared at me for two hundred heartbeats tonight. I counted. Cats don't look at strangers like that, Mistyblaze. So — which one of us is lying about being strangers?"`,
        choices: [
          { label: '"Leaders size up young warriors. That\'s all it is." (Deflect)' },
          { label: '"Maybe he sees something in you. You were impressive tonight."' },
          { label: "Say carefully: \"If that look meant something... would you want to know what?\"" },
          { label: "Change the subject and quietly note Blackstar's behavior. (Clue)" },
        ],
      };
    }
    case "juniper_plot": {
      const junAlive = state.cats.juniperfang?.alive;
      if (!junAlive) return null;
      return {
        id,
        title: "Moon 15 — The Bitter Leaf",
        speaker: "juniperfang",
        text:
          `Juniperfang collapses at dusk, halfway through her share of fresh-kill. Her breathing is wrong. Her pupils are wrong. You have seen bellyache and greencough and this is neither.\n\n` +
          `And small things are wrong too, in ways only her apprentice would notice: the herb store has been reorganized by paws that knew almost — ALMOST — where everything goes. Her share of prey sat apart from the pile. There is a sweetness on it that doesn't belong to any vole.\n\n` +
          `Someone wanted your mentor gone. Someone who knows you would then have no one to turn to but them.\n\nShe has until dawn, maybe less.`,
        choices: [
          { label: "Stay at her side all night and fight for her with everything in the store." },
          { label: "Treat her, then search the store and the fresh-kill pile for answers. (Investigate)" },
          { label: "Ask Silentshadow to help you watch over her — you need someone you trust." },
        ],
      };
    }
    case "nightsong_attack": {
      const ns = state.cats.nightsong;
      if (!ns?.alive) return null;
      const silentName2 = state.cats.silentpaw?.name ?? "Silentshadow";
      return {
        id,
        title: "Moon 20 — The Ravine",
        speaker: "nightsong",
        text:
          `A screech tears the night open. The patrol reaches the ravine edge to find Nightsong down, one long wound in his shoulder, claws dug into the rock to keep from going over — and ${silentName2} standing above him, very still, very calm.\n\n` +
          `"Training accident," ${silentName2} begins — and Nightsong, bleeding, laughing in a way that isn't laughter, finally breaks:\n\n` +
          `"No. NO. No more stories. You want the truth, so take it in front of witnesses: Brightstream is your mother. Blackstar of NightClan is your father. Windhawk is your litter-sister. And I am the fool who loved you both enough to lie about it every day of your lives!"\n\n` +
          `Windhawk, arrived with the patrol, has gone white to the whisker-tips.\n\n${silentName2} does not look at Nightsong. Or at Windhawk. He looks at YOU, and his voice comes out soft as snowfall: "Tell me you didn't know, Mistyblaze. Tell me the one cat who matters didn't know."`,
        choices: [
          { label: 'Tell the truth: "I knew. Since we were kits. I\'m sorry."' },
          { label: 'Lie: "I didn\'t know. I swear it."' },
          { label: '"What matters is what you do NOW, Silentshadow."' },
        ],
      };
    }
    case "ravine_averted": {
      const ns2 = state.cats.nightsong;
      const bs2 = state.cats.brightstream;
      if (!state.cats.silentpaw?.alive || (!ns2?.alive && !bs2?.alive)) return null;
      const silentName4 = state.cats.silentpaw?.name ?? "Silentshadow";
      const confronted = ns2?.alive ? "Nightsong" + (bs2?.alive ? " and Brightstream" : "") : "Brightstream";
      return {
        id,
        title: "Moon 20 — Words Instead of Claws",
        speaker: "silentpaw",
        text:
          `Because the truth reached him through you — quietly, chosen, not sprung like a trap — the night everyone feared never comes. No ravine. No blood.\n\n` +
          `Instead, ${silentName4} walks into the center of camp at dawn and asks, in a voice that carries to every den, for ${confronted} to come out and say it where the whole Clan can hear.\n\n` +
          `"No more stories told about me while I sleep," he says. "Say it in the light."\n\n` +
          `The camp holds its breath. Windhawk pushes to the front, already half-knowing. MapleStar watches from the Highrock and does not intervene — yet.\n\nWhere do you stand?`,
        choices: [
          { label: `Stand beside Silentshadow. He faces this because you armed him with the truth.` },
          { label: `Stand beside ${confronted} — they'll need a friend to survive this dawn.` },
          { label: "Step into the middle and ask MapleStar to hold it as a formal Clan matter." },
        ],
      };
    }
    case "shadow_targets":
    case "shadow_targets_2": {
      const wave = id === "shadow_targets_2" ? 1 : 0;
      // if he received the truth as a gift and aired it in the open, there is no hunt
      if (state.flags.truth_gentled) return null;
      const target = pickShadowTarget(state, wave);
      if (!target || !state.flags.silent_knows || !state.cats.silentpaw?.alive) return null;
      const t = state.cats[target.id];
      const silentName3 = state.cats.silentpaw?.name ?? "Silentshadow";
      return {
        id,
        title: "The Circling Shadow",
        text:
          `You know his patterns now — the counting, the routes, the patience. And lately every one of ${silentName3}'s routes bends, sooner or later, past ${t.name}.\n\n` +
          `Why ${t.name}? Because ${target.why}.\n\n` +
          `Yesterday ${t.name}'s nest was moved a tail-length while ${t.gender === "tom" ? "he" : "she"} slept — just to show it could be done. Nobody else reads it that way. You do.\n\nYou may not get another quiet moon to act.`,
        choices: [
          { label: `Guard ${t.name} openly — organize watchful eyes around ${t.gender === "tom" ? "him" : "her"}.` },
          { label: `Confront Silentshadow: "I know who you're circling. Stop."` },
          { label: "You're reading shadows into shadows. Stay out of it." },
        ],
      };
    }
    case "silent_learns":
      return {
        id,
        title: "The Night It Breaks",
        speaker: "silentpaw",
        text:
          `${silentName} was gone for two days. He returns at moonhigh, soaked to the bone, and comes straight to you. His voice is a flat calm worse than any scream.\n\n"I followed Brightstream to the border. She met Blackstar. I heard everything." A pause. "My mother. My FATHER. Nightsong — a whole lifetime of lying to my face and calling it love."\n\nHis eyes find yours and something in them tilts. "Tell me you didn't know, Mistyblaze. Tell me the one cat who matters didn't know."`,
        choices: [
          { label: 'Tell the truth: "I knew. Since we were kits. I\'m sorry."' },
          { label: 'Lie: "I didn\'t know. I swear it."' },
          { label: '"What matters is what you do NOW, Silentshadow."' },
        ],
      };
    case "threat_nightsong":
      return {
        id,
        title: "Shadows in the Warriors' Den",
        text:
          `Word slithers through camp: ${silentName} and Nightsong were found at dawn a whisker apart at the camp wall, Nightsong bleeding from one long, precise scratch below the ear. "Training," ${silentName} said, smiling. Nightsong said nothing at all.\n\nThat night, Nightsong plans to walk the border alone — you've heard him say so. So has ${silentName}.`,
        choices: [
          { label: "Follow Nightsong yourself, herbs packed. Don't let him walk alone." },
          { label: "Warn MapleStar and Brightstream immediately." },
          { label: "Confront Silentshadow before nightfall." },
          { label: "Stay out of it. Perhaps it truly was training." },
        ],
      };
    case "threat_brightstream":
      return {
        id,
        title: "The River Runs Cold",
        text:
          `Brightstream has taken to walking the river path at dusk, where she once carried two kits home. ${silentName} knows her routes now — he has made routes his religion.\n\nTonight fog is rolling in off the water, thick as pelt. Brightstream is already gone from camp. You may have less time than you think.`,
        choices: [
          { label: "Race to the river — go to her directly." },
          { label: "Fetch Windhawk and go together." },
          { label: "It's fog and fear, nothing more. Stay in camp." },
        ],
      };
    case "border_clash":
      return {
        id,
        title: "The Border Burns",
        text:
          `It finally happens: ${silentName} crosses into NightClan territory in open daylight and screams Blackstar's name until the pines shake.\n\nBy the time a HollyClan patrol arrives, father and son face each other on the scent line — one huge and still, one young and shaking with a lifetime of borrowed rage. NightClan warriors mass behind their leader. One wrong breath starts a war between Clans.\n\nYou are the medicine cat. Both sides will let you cross.`,
        choices: [
          { label: "Walk between them. A medicine cat's body as a border." },
          { label: "Speak to Blackstar: 'Tell him the truth he came for. All of it.'" },
          { label: "Speak to Silentshadow: 'This won't unmake a single lie. Come home.'" },
          { label: "Stay back and treat whoever falls." },
        ],
      };
    case "final_confrontation": {
      const trusted = state.suspicion < 40;
      return {
        id,
        title: "Moon of the Broken Star",
        speaker: "silentpaw",
        text: trusted
          ? `${silentName} wakes you at moonhigh, standing over your nest. How long has he been there?\n\n"Everyone lied," he says softly. "Brightstream. Nightsong. Blackstar. The whole Clan smiled while I grew up inside a story. Everyone lied except you — so you're the only thing I'm keeping."\n\n"Come with me, Mistyblaze. Tonight. No Clans, no borders, no names they gave us. Just us — the way it was always going to be."\n\nHis claws are out. You don't think he's noticed.`
          : `It ends where it began: the camp entrance, on a freezing night.\n\n${silentName} stands in the gap of the bramble wall with the whole Clan waking behind you. He looks at the cats gathering — Brightstream, the warriors, MapleStar on the Highrock — and then only at you, and the cold in his eyes is his father's.\n\n"You watched me," he says. "All these moons, I thought you were the one cat who didn't. You were just quieter about it than the rest."\n\n"Last chance, Mistyblaze. Stand with me — or stand with the liars."`,
        choices: [
          { label: '"Come back from this, Silentshadow. Let me help you. Please."' },
          { label: "Stand with the Clan. \"I won't let you hurt anyone else.\"" },
          { label: trusted ? "Go with him into the dark." : '"There was never a \'me or them\'. You built that cage yourself."' },
        ],
      };
    }
    default:
      return null;
  }
}

// ── apply story choices ─────────────────────────────────────────────────────
export function applyStoryChoice(state: GameState, id: string, choice: number): string {
  const silentName = state.cats.silentpaw?.name ?? "Silentshadow";
  switch (id) {
    case "intro":
      return "The dawn light filters into the medicine den. Juniperfang is already sorting leaves and pretending she didn't save the easy pile for you.";
    case "warrior_names":
      if (choice === 0) {
        adjRel(state, "silentpaw", PLAYER_ID, { affection: 8, trust: 8, loyalty: 6 });
        state.suspicion = clamp(state.suspicion - 5);
        addMemory(state, "silentpaw", "Under the warrior-name stars, Mistyblaze promised: nothing gets between us. I will hold him to it. I hold everything.", "good", 10, [PLAYER_ID]);
        return `${silentName}'s whole body loosens. "Good," he breathes. "Good." He repeats it a third time, quieter, like sealing something.`;
      }
      if (choice === 1) {
        adjRel(state, "silentpaw", PLAYER_ID, { affection: -4, jealousy: 10, trust: -5 });
        state.suspicion = clamp(state.suspicion + 6);
        addMemory(state, "silentpaw", "I asked Mistyblaze to promise me nothing would change. He talked about change like it was a gift. I felt the ground shift a whisker's width.", "bad", 9, [PLAYER_ID]);
        return `Something flickers across his face and is gone. "Change," he repeats, flat. "Right." He is perfectly pleasant for the rest of the night, which is somehow worse.`;
      }
      state.suspicion = clamp(state.suspicion + 8);
      state.clues.push("The way Silentshadow needed that promise — like a cat gripping prey, not a friend asking a favor.");
      addMemory(state, "silentpaw", "Mistyblaze went quiet when I asked for his promise. Quiet is my language. I don't like hearing it spoken back.", "bad", 8, [PLAYER_ID]);
      return `You hold his gaze and say nothing. For three heartbeats his stillness turns to stone — then he laughs it off. You file the moment away. (Clue gained)`;
    case "clue_falcon":
      if (choice === 0) {
        adjRel(state, "falconwind", PLAYER_ID, { suspicion: 15, trust: -10 });
        adjRel(state, "nightsong", PLAYER_ID, { trust: 5, loyalty: 5 });
        state.flags.lied_to_falcon = true;
        return `"Asleep." Falconwind tastes the word like bad prey. "Kits wake for everything." She walks away, and you know you've been added to a tally.`;
      }
      if (choice === 1) {
        adjRel(state, "falconwind", PLAYER_ID, { respect: 10, suspicion: 5 });
        state.clues.push("Falconwind independently pieced together the timeline of Brightstream's vanished half-season.");
        return `Falconwind actually smiles — a first. "An honest evasion. Rare beast." She lets you pass. "When it breaks — and secrets like this always break — remember I offered to help carry it."`;
      }
      adjRel(state, "falconwind", PLAYER_ID, { trust: 20, friendship: 10 });
      adjRel(state, "nightsong", PLAYER_ID, { trust: -25, affection: -10 });
      adjRel(state, "brightstream", PLAYER_ID, { trust: -25, affection: -10 });
      state.flags.falcon_knows = true;
      state.clues.push("You broke your kithood promise and told Falconwind what you saw.");
      addMemory(state, "falconwind", "The healer told me what he saw as a kit: Brightstream, two newborns, a night that officially never happened. My tally was right. It always is.", "secret", 10, [PLAYER_ID, "brightstream", "nightsong"]);
      return `You tell her. All of it. Falconwind listens without blinking. "Half-Clan," she murmurs. "The deputy's kits." She holds your gaze: "I'll keep it — for now. But knowledge wants out, healer. Remember who let it off its leash." Somewhere behind you, you imagine Nightsong's face.`;
    case "silent_gift":
      if (choice === 0) {
        adjRel(state, "silentpaw", PLAYER_ID, { affection: 10, loyalty: 8 });
        state.herbs.catmint = (state.herbs.catmint ?? 0) + 1;
        addMemory(state, "silentpaw", "He thanked me for the catmint. He didn't ask how far I went. Distance is nothing. I'd cross anything. That's what nobody understands about me — there is no 'too far'.", "good", 9, [PLAYER_ID]);
        return `His eyes go warm — warmer than you've seen since kithood. "Anything you're short of," he says, "ever — tell me first." (+1 catmint)`;
      }
      if (choice === 1) {
        adjRel(state, "silentpaw", PLAYER_ID, { affection: -3, jealousy: 5, fear: 2 });
        state.herbs.catmint = (state.herbs.catmint ?? 0) + 1;
        state.suspicion = clamp(state.suspicion + 4);
        addMemory(state, "silentpaw", "I brought him something impossible and he scolded me about BORDERS. Lines scratched by dead cats. There are no borders between us. I'll teach him that, gently.", "bad", 8, [PLAYER_ID]);
        return `"Can't," he echoes, as if the word is in another language. "For you, there's no such thing as can't." He leaves the catmint anyway. (+1 catmint)`;
      }
      state.herbs.catmint = (state.herbs.catmint ?? 0) + 1;
      state.suspicion = clamp(state.suspicion + 8);
      state.clues.push(`${silentName} crossed the NightClan border alone, at night, casually — and knew the far ravine like a cat who had been there before.`);
      return `You thank him and memorize everything: the pine sap on his pads, the ease of it, the way "border" means nothing to him. (Clue gained, +1 catmint)`;
    case "holly_warning":
      if (choice === 0) {
        adjRel(state, "hollypaw", PLAYER_ID, { trust: -15, friendship: -8 });
        adjRel(state, "silentpaw", PLAYER_ID, { loyalty: 5 });
        state.suspicion = clamp(state.suspicion - 6);
        state.flags.dismissed_holly = true;
        addMemory(state, "hollypaw", "I brought Mistyblaze my fear and he handed it back wrapped in 'you're imagining it'. Fine. I'll carry it alone. I'm good at alone lately.", "bad", 8, [PLAYER_ID, "silentpaw"]);
        return `Hollyspark's face closes like a door. "Right. Imagining." She doesn't bring it up again. Later you'll wonder what else she stopped bringing you.`;
      }
      if (choice === 1) {
        adjRel(state, "hollypaw", PLAYER_ID, { trust: 10 });
        state.suspicion = clamp(state.suspicion + 8);
        state.clues.push("Hollyspark's nest was shredded the morning after she mentioned a dawn hunt with you. Only hers.");
        state.flags.watching_silent = true;
        return `She exhales. "Watching quietly. Okay. That's something." She bumps your shoulder, an echo of the old lightness. "Watch fast, Misty."`;
      }
      adjRel(state, "hollypaw", PLAYER_ID, { trust: 15, friendship: 8 });
      adjRel(state, "brightstream", PLAYER_ID, { trust: 8 });
      adjRel(state, "silentpaw", PLAYER_ID, { suspicion: 15, jealousy: 8 });
      state.suspicion = clamp(state.suspicion + 10);
      state.flags.told_brightstream_fears = true;
      state.clues.push("When you and Hollyspark reported the nest incident, Brightstream went pale before you finished the second sentence.");
      return `Brightstream listens to you both, and what unsettles you most is that she is not surprised. "Thank you," she says, in a voice pressed flat. "Leave ${silentName} to me." She does not say what that means. (Clue gained)`;
    case "nightsong_request":
      if (choice === 0) {
        adjRel(state, "nightsong", PLAYER_ID, { trust: 12, loyalty: 10 });
        state.flags.promised_nightsong = true;
        return `Nightsong closes his eyes briefly. "Then we hold the wall a while longer." He touches his nose to your shoulder — the most emotion you've ever seen him spend. "You're a better cat than this secret deserves."`;
      }
      if (choice === 1) {
        adjRel(state, "nightsong", PLAYER_ID, { respect: 10, trust: 3 });
        state.flags.urged_truth = true;
        return `He is silent a long time. "You sound like my own dread at moonhigh," he finally says. "You're right. I know you're right. Getting Brightstream to agree — that's a battle with more claws than any fox." A seed is planted; whether it grows in time is another matter.`;
      }
      adjRel(state, "nightsong", PLAYER_ID, { trust: -5 });
      state.suspicion = clamp(state.suspicion + 5);
      return `"Rot," Nightsong repeats. "Yes. That's the word I keep not saying." He looks older than you've ever seen him. "Whatever you decide, ${state.cats[PLAYER_ID].name} — decide it before HE does. That's all I ask."`;
    case "evidence_moment":
      if (choice === 0) {
        state.flags.told_maplestar = true;
        adjRel(state, "maplestar", PLAYER_ID, { trust: 15, respect: 10 });
        adjRel(state, "brightstream", PLAYER_ID, { trust: -20 });
        adjRel(state, "nightsong", PLAYER_ID, { trust: -15 });
        state.clues.push("MapleStar now knows everything. She said: 'Secrets cost more than truth. We prepare for the bill.'");
        return `MapleStar listens on the Highrock ledge in absolute stillness. "I suspected pieces," she says at last. "Never the whole." She looks toward the warriors' den. "You did right to bring this to me. Now we prepare — quietly — for the night it surfaces." You feel the Clan's odds shift, and friendships strain.`;
      }
      if (choice === 1) {
        state.flags.urged_truth = true;
        adjRel(state, "brightstream", PLAYER_ID, { respect: 10 });
        adjRel(state, "nightsong", PLAYER_ID, { respect: 10 });
        return `You find them at dusk, together as they so often are, and say one sentence: "Tell him before he finds out." Brightstream's composure cracks down one fine line. Nightsong nods slowly. "Soon," she whispers. "Give me one more moon of him not hating me." One more moon. You hope the forest gives her that.`;
      }
      state.flags.kept_sealed = true;
      adjRel(state, "nightsong", PLAYER_ID, { loyalty: 8 });
      return `You bury it deeper and go back to your herbs. All their lives the wall has held. But that night you dream of frost, and frost, as the voice once told you, preserves everything — even lies — right up until the thaw.`;
    case "blackstar_visit":
      if (choice === 0) {
        adjRel(state, "blackstar", PLAYER_ID, { trust: 20, respect: 15, affection: 10 });
        state.flags.blackstar_bond = true;
        addMemory(state, "blackstar", "The young healer told me of my kits — the black one counts everything, the white one outruns everything. I asked for one report and have lived on it for a moon. A leader cannot ask twice. A father, it turns out, can listen forever.", "secret", 10, [PLAYER_ID, "silentpaw", "windpaw"]);
        addMemory(state, PLAYER_ID, "I told Blackstar about Silentpaw and Windpaw at the border — how they train, how they laugh. The biggest cat I've ever seen hung on every word like prey. Whatever he is to NightClan, at that moment he was only a father.", "secret", 8, ["blackstar"]);
        return `You tell him. The black one counts everything and loses at nothing; the white one is the fastest apprentice HollyClan has bred in living memory. You tell him about the fresh-kill sharing and the training bruises, and the huge cold leader of NightClan listens the way starving cats eat.\n\n"Thank you," he says at the end — words NightClan's enemies would not believe he owns. "When the frost thaws, healer, remember: not every cat on my side of the line is your enemy." He is gone between one blink and the next.`;
      }
      if (choice === 1) {
        adjRel(state, "blackstar", PLAYER_ID, { respect: 18, trust: 5, affection: -5 });
        state.flags.blackstar_scorned = true;
        addMemory(state, "blackstar", "The young healer threw my absence in my teeth at the border. No cat has spoken to me like that in seasons — my own Clan wouldn't dare. I should have been furious. Instead I walked home lighter. Finally: a cat who says the true thing.", "secret", 9, [PLAYER_ID]);
        return `The words leave you harder than you meant — or exactly as hard as you meant.\n\nBlackstar takes them without flinching, the way mountains take weather. "Yes," he says at last. "I did." A silence with sixteen seasons in it. "She chose their safety over my pride. It was the right choice. It is also the wound I decline to stop bleeding from."\n\nHe inclines his huge head — to YOU, a half-grown healer — and vanishes into the pines. You have made an impression you don't yet know the price of.`;
      }
      if (choice === 2) {
        state.clues.push("Blackstar, at the border, moon 3: 'A leader who crosses for love starts a war. A father who doesn't starts this instead.' He looked at his own paws when he said it.");
        adjRel(state, "blackstar", PLAYER_ID, { trust: 12, respect: 10 });
        return `"Why did you stay away?"\n\nThe question lands somewhere armor doesn't cover. For a long moment the only sound is wind in the pines behind him.\n\n"A leader who crosses the border for love starts a war," he says finally. "A father who doesn't..." He looks down at his own paws, enormous and useless. "...starts this instead. Whatever 'this' becomes."\n\nHe leaves without asking his question again. You gather your marigold with shaking paws, understanding that you have just heard NightClan's leader confess. (Clue gained)`;
      }
      adjRel(state, "blackstar", PLAYER_ID, { respect: 8, suspicion: 5 });
      return `You hold his gaze, say nothing, and pick your marigold stem by stem while the most dangerous cat in the forest watches.\n\n"Hm," Blackstar says at last, and there is something almost approving in it. "She chose her secret-keeper well." He melts into the pines.\n\nOnly on the walk home do your legs start trembling.`;
    case "gathering_shadow": {
      const silentG = state.cats.silentpaw;
      if (choice === 0) {
        adjRel(state, "silentpaw", PLAYER_ID, { trust: -4, suspicion: 6 });
        state.suspicion = clamp(state.suspicion + 3);
        if (silentG) addMemory(state, "silentpaw", "Two hundred heartbeats of a strange leader's eyes on me, and Mistyblaze said 'that's just how leaders look at warriors.' It isn't. I've catalogued how leaders look at warriors. This was a different file entirely — and my best friend reached for the nearest lie.", "bad", 9, [PLAYER_ID, "blackstar"]);
        return `"Leaders size up young warriors," you say. "That's all."\n\nHe walks six paces in silence. "You're usually better at lying," he says — mildly, which is worse than anger. "Interesting that you needed to." He doesn't raise it again. He files it. You can hear the filing.`;
      }
      if (choice === 1) {
        adjRel(state, "silentpaw", PLAYER_ID, { affection: 8, trust: 5 });
        if (silentG) addMemory(state, "silentpaw", "Mistyblaze said Blackstar maybe sees something in me. That I was impressive at the Gathering. I have repeated that sentence to myself, in his voice, upward of forty times. Being seen by a leader is nothing. Being seen by HIM is the entire point of being visible.", "good", 9, [PLAYER_ID]);
        return `"Maybe he sees something in you. You were impressive tonight."\n\nThe effect is instant and a little heartbreaking: his whole frame loosens, the counting stops, and for twenty paces he is just a young cat walking home from his first Gathering, pleased to the whisker-tips.\n\n"Impressive," he repeats once, storing it where he stores you. The question about Blackstar dissolves — tonight. Questions never dissolve in him forever.`;
      }
      if (choice === 2) {
        state.suspicion = clamp(state.suspicion + 6);
        state.flags.offered_truth_early = true;
        if (silentG) {
          adjRel(state, "silentpaw", PLAYER_ID, { trust: 8, suspicion: 8 });
          addMemory(state, "silentpaw", "On the walk home Mistyblaze asked if I'd WANT to know what Blackstar's stare meant — careful, like a cat testing ice. So there IS something to know, and he carries a piece of it. I said 'not tonight.' I need to be stronger before I open that door. I need HIM closer before I open that door.", "secret", 10, [PLAYER_ID, "blackstar"]);
        }
        return `"If that look meant something... would you want to know what?"\n\nHe stops walking entirely. The whole patrol flows past you both in the dark.\n\n"You'd tell me," he says slowly. "If I asked right now, you'd actually tell me." He studies you for ten full heartbeats, and whatever he finds decides him: "Not tonight. When I ask — and I will ask — I want to be ready for the answer to be terrible."\n\nHe knows the door exists now. You put his paw on the handle yourself. (+Suspicion)`;
      }
      state.clues.push("At the Gathering: Blackstar watched Silentshadow for the entire night — and twice began grooming his own shoulder exactly when Silentshadow did. Mirrored habits. Inherited habits.");
      state.suspicion = clamp(state.suspicion + 4);
      return `You steer the talk to Gathering gossip — and keep your eyes working. What you catalogue chills you: Blackstar doesn't just watch Silentshadow. He MIRRORS him. The same shoulder-groom at the same moment, twice. The same stillness between movements. Habits don't cross a border by coincidence; they cross it in blood.\n\n(Clue gained, +Suspicion)`;
    }
    case "juniper_plot": {
      const jun = state.cats.juniperfang;
      if (!jun) return "";
      const haveHerb = (state.herbs.juniper ?? 0) > 0 || (state.herbs.feverfew ?? 0) > 0;
      const spendHerb = () => {
        if ((state.herbs.juniper ?? 0) > 0) state.herbs.juniper--;
        else if ((state.herbs.feverfew ?? 0) > 0) state.herbs.feverfew--;
      };
      const survive = (how: string) => {
        jun.health = 45;
        jun.mood = "shaken";
        state.flags.juniper_saved = true;
        adjRel(state, "juniperfang", PLAYER_ID, { trust: 15, affection: 12, respect: 10 });
        addMemory(state, "juniperfang", `Something in my prey nearly sent me to StarClan ahead of schedule. My apprentice pulled me back — ${how}. I taught that cat everything, and apparently it took.`, "good", 10, [PLAYER_ID]);
        addMemory(state, PLAYER_ID, `Juniperfang nearly died the night her prey turned bitter. I fought until dawn for her. I keep thinking about who rearranged the herb store — almost correctly. Almost.`, "secret", 9, ["juniperfang", "silentpaw"]);
      };
      const die = () => {
        killCat(state, "juniperfang", "a sudden poisoning no cat could name — the store held nothing that could fight it");
        state.flags.juniper_dead = true;
        addMemory(state, PLAYER_ID, "The store was empty of what she needed. I held Juniperfang's paw and recited her own herb chant back to her until she stopped hearing it. HollyClan's medicine den is mine alone now — which is exactly what someone wanted.", "bad", 10, ["juniperfang", "silentpaw"]);
      };
      if (choice === 0) {
        if (haveHerb) {
          spendHerb();
          survive("all night, herb by herb");
          return `You fight for her until the birds start. Twice she stops breathing evenly; twice you drag her back with juniper and stubbornness. At dawn she opens one eye: "Well," she rasps, "I'd say your training is complete." She will live — weakened, warier, and watching the camp with new eyes.`;
        }
        die();
        return `You fight for her with everything in the store — and the store is not enough. There is no juniper, no feverfew, nothing with teeth. She goes gently, near dawn, with her paw in yours. The last thing she says is, "Check the pile. Check who ate first." You are HollyClan's only medicine cat now.`;
      }
      if (choice === 1) {
        if (haveHerb) spendHerb();
        state.suspicion = clamp(state.suspicion + 10);
        state.clues.push("The night Juniperfang fell ill: her prey set apart from the pile, a wrong sweetness on it, the herb store reorganized by paws that knew ALMOST where everything goes — and a single black hair snagged on the store's bramble.");
        state.flags.investigated_juniper = true;
        if (haveHerb) {
          survive("then went hunting for the how and the who");
          return `You stabilize her, then search. The pile: her share was set aside, deliberately. The store: reorganized — cleverly, but yarrow and juniper swapped, a mistake no trained cat makes. And on the bramble at the entrance, one black hair.\n\nHalf the Clan has black fur, you tell yourself. You write it in your memory anyway. (Clue gained, +Suspicion)`;
        }
        die();
        return `You search while she fades, because the store is empty and there is nothing else you CAN do. What you find will stay with you: her share set apart, a wrong sweetness, the store rearranged almost-correctly, one black hair on the bramble.\n\nShe dies at dawn. You bury the clue deeper than they bury her, until you know what to do with it. (Clue gained, +Suspicion)`;
      }
      // choice 2: ask Silentshadow for help
      state.suspicion = clamp(state.suspicion - 6);
      adjRel(state, "silentpaw", PLAYER_ID, { affection: 10, loyalty: 8 });
      state.flags.trusted_silent_juniper = true;
      jun.health = 45;
      jun.mood = "shaken";
      state.flags.juniper_saved = true;
      addMemory(state, "silentpaw", "He came to ME when Juniperfang fell. Me, first, before anyone. I found feverfew in the dark for him. I would find anything in the dark for him. The old cat will live, and he will remember who helped — that's fine. That's even better.", "secret", 10, [PLAYER_ID, "juniperfang"]);
      addMemory(state, PLAYER_ID, "When Juniperfang collapsed I asked Silentshadow to help me watch over her. He found feverfew in the dark in half the time it should take. He always finds things. He always knows where everything is.", "neutral", 8, ["silentpaw", "juniperfang"]);
      return `You ask him, and something crosses his face too fast to read — then he is all quiet competence. He returns before moonhigh with feverfew you'd swear wasn't growing anywhere this season, and keeps vigil beside you without blinking.\n\nJuniperfang lives. "Lucky," she rasps later, looking at Silentshadow a long, level moment. "Lucky the right herb was so easy to find."`;
    }
    case "nightsong_attack": {
      const ns = state.cats.nightsong;
      state.flags.silent_knows = true;
      state.flags.secret_out = true; // shouted in front of a patrol — the camp will whisper by dawn
      const silent2 = state.cats.silentpaw;
      if (ns?.alive) {
        ns.health = clamp(ns.health - 40);
        ns.mood = "grim";
        state.flags.saved_nightsong = true; // he survived the attempt — witnesses arrived in time
        addMemory(state, "nightsong", "He came at me at the ravine. My own son — mine in every way that was a choice. I said the truth out loud at last, bleeding, in front of witnesses. It cost less than carrying it. It cost everything else.", "secret", 10, ["silentpaw", "brightstream", "blackstar"]);
      }
      if (silent2) {
        silent2.goals = ["make every liar feel what a lifetime of lying feels like", "keep Mistyblaze — the only true thing"];
        silent2.mood = "burning";
        adjRel(state, "silentpaw", "nightsong", { affection: -40, trust: -60, suspicion: 40, loyalty: -50 });
        adjRel(state, "silentpaw", "brightstream", { affection: -30, trust: -60, suspicion: 40 });
        adjRel(state, "silentpaw", "windpaw", { suspicion: 20, trust: -15 });
      }
      // Windhawk was present — she learns her own truth here too
      state.flags.windhawk_knows = true;
      adjRel(state, "windpaw", "nightsong", { trust: -20, affection: -5, respect: 10 });
      adjRel(state, "windpaw", "brightstream", { suspicion: 25, trust: -20 });
      addMemory(state, "windpaw", "At the ravine I learned my whole life in one sentence: Brightstream. Blackstar. My brother trying to kill the only father we've known. I ran the border until my pads bled and it didn't outrun anything.", "secret", 10, ["nightsong", "brightstream", "blackstar", "silentpaw"]);
      addMemory(state, "brightstream", "The ravine. The whole patrol heard. My kits know, and they learned it from Nightsong's wounds instead of my mouth. Every moon I waited made this night worse, and I waited anyway.", "secret", 10, ["silentpaw", "windpaw", "nightsong"]);
      if (choice === 0) {
        adjRel(state, "silentpaw", PLAYER_ID, { trust: -25, affection: -10, suspicion: 20 });
        state.flags.confessed_knowledge = true;
        addMemory(state, "silentpaw", "Mistyblaze knew. Since we were KITS. Every shared piece of prey, every quiet dawn — he knew and said nothing. But he told me the truth at the ravine, to my face, when lying was easier. That has to count. It's the only thing left that can.", "secret", 10, [PLAYER_ID]);
        return `"Since we were kits," he repeats. The whole ravine is silent except for Nightsong's ragged breathing. He doesn't shout. He thanks you — THANKS you — in a voice like the frozen river, and walks into the dark alone.\n\nNightsong will live; you pack his wound with cobweb while Windhawk stares at nothing. The secret is a secret no longer — not to the ones it was built around. What the rest of the Clan learns, and when, may still be yours to shape.`;
      }
      if (choice === 1) {
        adjRel(state, "silentpaw", PLAYER_ID, { trust: 5, affection: 5 });
        state.flags.lied_to_silent = true;
        addMemory(state, "silentpaw", "Everyone lied — except Mistyblaze. At the ravine, with the truth burning the air, he swore he never knew. He is the last real thing in the world. I will keep him safe from all of them, whatever that takes.", "secret", 10, [PLAYER_ID]);
        return `The lie leaves you before you decide to tell it. Relief floods his face — total, terrifying relief, a cat putting his whole weight on one branch.\n\n"The only one," he breathes. "I knew it." He presses his forehead to yours, right there over Nightsong's blood, and is gone.\n\nYou treat Nightsong's wound in silence. He looks at you once, and says nothing at all, which is worse than anything he could have said.`;
      }
      adjRel(state, "silentpaw", PLAYER_ID, { trust: -10, suspicion: 10 });
      addMemory(state, "silentpaw", "I asked Mistyblaze if he knew. He answered a different question. Healers are clever like that. Everyone is clever. I'm done being the only one who wasn't.", "secret", 10, [PLAYER_ID]);
      return `"What I do now," he echoes. His smile is a thin crack in ice. "You didn't answer my question, Mistyblaze. You're all so good at not answering."\n\nHe leaves. Nightsong lives — you see to that with your own paws — but the camp you walk back to at dawn is a different camp, and every cat in it can feel the change without knowing its name.`;
    }
    case "ravine_averted": {
      state.flags.secret_out = true;
      state.flags.windhawk_knows = true;
      state.flags.saved_nightsong = true; // no attack ever happened
      state.flags.truth_gentled = true;
      adjRel(state, "windpaw", "brightstream", { suspicion: 20, trust: -15 });
      adjRel(state, "windpaw", "nightsong", { trust: -10, respect: 10 });
      addMemory(state, "windpaw", "I learned my whole life at dawn in the middle of camp — Brightstream, Blackstar, all of it, out loud. It hurt. But my brother asked for it in words, in the open, like a warrior. That's the version of him I'm choosing to keep.", "secret", 10, ["silentpaw", "brightstream", "nightsong", "blackstar"]);
      addMemory(state, "brightstream", "He asked me to say it in the light, and I did — every word I'd rehearsed to an empty den for a lifetime of moons. The Clan heard. My kits heard. It broke something in me that needed breaking.", "secret", 10, ["silentpaw", "windpaw"]);
      if (state.cats.maplestar?.alive) addMemory(state, "maplestar", "The half-Clan truth came out in my camp at dawn — in words, before the whole Clan, because a young healer had the courage to hand it over before it became claws. Secrets cost more than truth. Today the Clan paid the smaller bill.", "secret", 9, ["silentpaw", "brightstream", PLAYER_ID]);
      if (choice === 0) {
        adjRel(state, "silentpaw", PLAYER_ID, { affection: 10, loyalty: 10, trust: 6 });
        adjRel(state, "brightstream", PLAYER_ID, { affection: -6, trust: -5 });
        addMemory(state, "silentpaw", "When I asked for the truth in the light, Mistyblaze stood at my shoulder where anyone could see. Let the whole forest take note of where he stands. I have.", "secret", 10, [PLAYER_ID]);
        return `You take your place at his shoulder, and the Clan reads it exactly as it's meant: the medicine cat vouches for this. Brightstream tells it all — steadily, then not steadily. Nightsong doesn't defend himself once.\n\nWhen it's over, the camp is quiet the way a field is quiet after lightning has already struck. No one has died. Everyone has changed. ${state.cats.silentpaw?.name ?? "Silentshadow"} leans into you, just barely, for exactly one heartbeat.`;
      }
      if (choice === 1) {
        adjRel(state, "brightstream", PLAYER_ID, { affection: 12, trust: 10 });
        adjRel(state, "nightsong", PLAYER_ID, { affection: 10, loyalty: 8 });
        adjRel(state, "silentpaw", PLAYER_ID, { jealousy: 10, trust: -6, suspicion: 8 });
        addMemory(state, "silentpaw", "I asked for the truth in the open and Mistyblaze crossed the clearing to stand with THEM. With the liars. He gave me the truth and then chose their side of it. I'm still doing the arithmetic on what that makes him.", "secret", 10, [PLAYER_ID, "brightstream", "nightsong"]);
        return `You cross the clearing and sit with the accused — because whatever they did, they did it for love, badly, for a lifetime of moons. Brightstream's voice steadies when you settle beside her.\n\nThe truth comes out whole. The Clan survives hearing it. But across the clearing, ${state.cats.silentpaw?.name ?? "Silentshadow"} watches you sit with the liars, and files it where he files everything.`;
      }
      state.flags.told_maplestar = true;
      adjRel(state, "maplestar", PLAYER_ID, { respect: 12, trust: 10 });
      addMemory(state, PLAYER_ID, "I asked MapleStar to hold the truth-telling as a formal Clan matter. Rules held what rage could not. The elders say it was the strangest, calmest catastrophe in Clan memory.", "neutral", 8, ["maplestar", "silentpaw"]);
      return `You step into the middle and call up to the Highrock, and MapleStar descends like she was waiting to be asked.\n\nUnder her eye it becomes something almost bearable: each cat speaks in turn, no one interrupts, Windhawk asks her questions and gets answers, and the Warrior Code — which has no law for this — bends without breaking.\n\n"Secrets cost more than truth," MapleStar says at the end, to everyone and no one. "Today we paid the smaller bill." No exile. No blood. A Clan, changed but whole, goes to its dens at sunhigh.`;
    }
    case "shadow_targets":
    case "shadow_targets_2": {
      const wave = id === "shadow_targets_2" ? 1 : 0;
      if (id === "shadow_targets_2") state.flags.done_shadow_targets_2 = true;
      const target = pickShadowTarget(state, wave);
      if (!target) return "The moon passes with held breath, and nothing comes of it.";
      const t = state.cats[target.id];
      if (!t?.alive) return "The moon passes with held breath, and nothing comes of it.";
      if (choice === 0) {
        state.flags.target_saved = true;
        state.flags.clan_alerted = true;
        adjRel(state, t.id, PLAYER_ID, { trust: 15, affection: 10, loyalty: 10 });
        adjRel(state, "silentpaw", PLAYER_ID, { suspicion: 12, jealousy: 8 });
        addMemory(state, t.id, `${state.cats[PLAYER_ID].name} quietly arranged for me never to be alone this moon. I noticed on the third day. I didn't ask. Some kindnesses work better unexamined.`, "good", 9, [PLAYER_ID]);
        return `You organize it without ever saying why: ${t.name} is simply never alone. A patrol here, a shared watch there, Twiggatherer and his endless twig errands underfoot at all the right moments.\n\n${state.cats.silentpaw?.name ?? "Silentshadow"} reads the arrangement inside a day — he was always the best of you at reading. Across the clearing his eyes find yours and hold, and what passes between you is not anger. It's recalculation.`;
      }
      if (choice === 1) {
        state.flags.confronted_silent = true;
        state.suspicion = clamp(state.suspicion + 8);
        if (state.suspicion >= 50 || state.flags.clan_alerted) {
          state.flags.target_saved = true;
          adjRel(state, "silentpaw", PLAYER_ID, { fear: 5, respect: 5, affection: -5 });
          addMemory(state, "silentpaw", `Mistyblaze stood in my path and named what I was circling. No fear in his legs. He sees me — actually sees me — and he stayed anyway. File that under the short list of things that still matter.`, "secret", 9, [PLAYER_ID]);
          return `You find him at dusk by the training hollow. "I know who you're circling," you say. "Stop."\n\nA long stillness. Then, softly: "You've been paying attention. To me." It lands somewhere between threat and gratitude — with him it was always the same shelf.\n\nHe stops. This moon, at least, ${t.name} sleeps safe — and he knows exactly why.`;
        }
        t.health = clamp(t.health - 30);
        t.mood = "shaken";
        addMemory(state, t.id, `A "loose rock" nearly took me at the river path. I know what I know. I started sleeping facing the den entrance, like Hollyspark does.`, "bad", 8, ["silentpaw"]);
        return `You confront him, and he listens with his head tilted, weighing you. "You'd need the whole Clan behind that word," he says at last. "Do you have it?"\n\nYou don't, and you both know it. Days later ${t.name} limps home from the river path — a fall, everyone says. ${t.gender === "tom" ? "He" : "She"} survives it. The next one won't be a warning.`;
      }
      // stay out of it — strength decides what the night leaves behind
      if (state.flags.clan_alerted) {
        state.flags.target_saved = true;
        return `You stay out of it — but the watchfulness you set in motion moons ago keeps its own schedule. Patrols cross ${t.name}'s path all moon by "coincidence." Nothing happens. You tell yourself that proves you were imagining things. You almost believe it.`;
      }
      {
        const r2 = mulberry(state.moon * 2203 + t.id.length * 97);
        const result = attackOutcome(state, "silentpaw", t.id, r2);
        if (result === "killed") {
          killCat(state, t.id, `found at the foot of the ravine path — the Clan called it a fall; you counted the black hairs in the bramble above and called it nothing at all, out loud`);
          addMemory(state, PLAYER_ID, `I saw him circling ${t.name} and I chose to look away. They say ${t.gender === "tom" ? "he" : "she"} fell. My silence is in the tally now, and the tally has my name on it.`, "bad", 10, [t.id, "silentpaw"]);
          return `You stay out of it.\n\n${t.name} is found at the foot of the ravine path before the moon is out. A fall. Everyone agrees it was a fall, because the alternative is unlivable.\n\nYou climb to the spot alone afterward. Black hairs in the bramble. You say nothing — and understand, finally, that saying nothing is also a thing you do to people.`;
        }
        if (result === "wounded") {
          t.health = clamp(t.health - 45);
          t.mood = "shaken";
          state.flags.secret_violence = true;
          adjRel(state, t.id, "silentpaw", { fear: 25, suspicion: 25, trust: -30 });
          addMemory(state, t.id, `Something came out of the dark at the ravine path and I fought it off — barely. Black fur, green eyes, no sound at all, even when my claws found him. I know who it was. Saying it out loud is another matter.`, "bad", 10, ["silentpaw"]);
          return `You stay out of it.\n\n${t.name} comes home three nights later torn and silent, having fought something off at the ravine path. ${t.gender === "tom" ? "He" : "She"} was strong enough to survive it. ${t.gender === "tom" ? "He" : "She"} tells the Clan it was a rogue.\n\n${t.gender === "tom" ? "He" : "She"} tells you nothing at all — just looks at you for a long moment, as if deciding whether you already knew. You did.`;
        }
        adjRel(state, "silentpaw", t.id, { fear: 15, respect: 10 });
        adjRel(state, t.id, "silentpaw", { suspicion: 30, fear: 10 });
        addMemory(state, t.id, `Something stalked me at the ravine path and I turned on it before it could strike. It melted into the dark rather than face me square. Cowards' work. I sleep with one eye open now and both claws loose.`, "bad", 9, ["silentpaw"]);
        return `You stay out of it — and it turns out ${t.name} needed no one. When the shadow came, ${t.gender === "tom" ? "he" : "she"} turned on it fast and hard, and it chose retreat over a fair fight.\n\n${t.name} prowls the camp now like a struck flint. ${state.cats.silentpaw?.name ?? "Silentshadow"} carries a limp he explains to no one. The arithmetic between them has changed — and he knows you watched it change.`;
      }
    }
    case "silent_learns": {
      state.flags.silent_knows = true;
      const silent = state.cats.silentpaw;
      if (silent) {
        silent.goals = ["make every liar feel what a lifetime of lying feels like", "keep Mistyblaze — the only true thing"];
        silent.mood = "burning";
        adjRel(state, "silentpaw", "nightsong", { affection: -40, trust: -60, suspicion: 40, loyalty: -50 });
        adjRel(state, "silentpaw", "brightstream", { affection: -30, trust: -60, suspicion: 40 });
      }
      if (choice === 0) {
        adjRel(state, "silentpaw", PLAYER_ID, { trust: -25, affection: -10, suspicion: 20 });
        state.flags.confessed_knowledge = true;
        addMemory(state, "silentpaw", "Mistyblaze knew. Since we were KITS. Every shared piece of prey, every quiet dawn — he knew and said nothing. He told me the truth at the end, though. That has to count. It's the only thing left that can.", "secret", 10, [PLAYER_ID]);
        return `The truth lands on him like snow off a branch — soft, then crushing. "Since we were kits," he repeats. He doesn't shout. He thanks you — THANKS you — in a voice like the frozen river, and walks into the dark. You have never been more afraid of politeness.`;
      }
      if (choice === 1) {
        adjRel(state, "silentpaw", PLAYER_ID, { trust: 5, affection: 5 });
        state.flags.lied_to_silent = true;
        addMemory(state, "silentpaw", "Everyone lied — except Mistyblaze. He swore he never knew. He is the last real thing in the world. I will keep him safe from all of them, whatever that takes.", "secret", 10, [PLAYER_ID]);
        return `Relief floods his face — total, terrifying relief, a cat putting his whole weight on one branch. "I knew it. The only one." He presses his forehead to yours, cold and wet from the rain. "Just us now." You feel the lie settle into your fur like a burr you will never comb out.`;
      }
      adjRel(state, "silentpaw", PLAYER_ID, { trust: -10, suspicion: 10 });
      addMemory(state, "silentpaw", "I asked Mistyblaze if he knew. He answered a different question. Healers are clever like that. Everyone is clever. I'm done being the only one who wasn't.", "secret", 10, [PLAYER_ID]);
      return `"What I do now," he echoes. His smile is a thin crack in ice. "You didn't answer my question, Mistyblaze. You're all so good at not answering." He leaves a silence behind that follows you around camp for days.`;
    }
    case "threat_nightsong": {
      const nightsong = state.cats.nightsong;
      const protectedBy = state.flags.told_maplestar || state.flags.watching_silent;
      if (choice === 0) {
        state.flags.saved_nightsong = true;
        adjRel(state, "nightsong", PLAYER_ID, { trust: 20, affection: 15, loyalty: 15 });
        adjRel(state, "silentpaw", PLAYER_ID, { suspicion: 15, jealousy: 10 });
        addMemory(state, PLAYER_ID, "I walked the border at Nightsong's side while a shadow paced us in the trees. It never attacked. Two witnesses are one too many.", "secret", 9, ["nightsong", "silentpaw"]);
        return `You walk the whole border at his side. Twice, something big moves parallel in the trees, patient as winter — and twice it melts away. Nightsong looks at you when it's over. "So it's real," he says quietly. "And now he knows I know." Nightsong lives — tonight.`;
      }
      if (choice === 1) {
        state.flags.saved_nightsong = true;
        state.flags.clan_alerted = true;
        adjRel(state, "maplestar", PLAYER_ID, { trust: 10 });
        return `MapleStar doesn't argue. Within moments, "routine" double patrols shadow every path Nightsong walks. ${silentName} watches the warriors pair off and understands perfectly. His eyes find yours across the clearing and hold. Nightsong lives — and the game moves into the open.`;
      }
      if (choice === 2) {
        adjRel(state, "silentpaw", PLAYER_ID, { suspicion: 10, affection: -5, fear: 3 });
        state.suspicion = clamp(state.suspicion + 5);
        state.flags.confronted_silent = true;
        if (protectedBy) {
          state.flags.saved_nightsong = true;
          return `"Training," ${silentName} repeats when you confront him, wearing his new smile. "Cats get hurt training." But your confrontation — and the quiet watch you'd already helped arrange — costs him the darkness he needs. Nightsong's walk passes without incident. This time.`;
        }
        return `He listens to your accusation all the way through, head tilted, and answers only: "You'd take his side. Interesting." That night, Nightsong limps back into camp with a wrenched shoulder and a story about a slipped rock he clearly doesn't believe himself. It could have been so much worse. Next time it will be.`;
      }
      // stayed out of it
      if (protectedBy) {
        state.flags.saved_nightsong = true;
        return `You stay out of it — but the wheels you set turning earlier keep spinning without you: extra patrols cross Nightsong's path all night by "coincidence." He comes home safe, and never knows how close the ice came to cracking.`;
      }
      if (nightsong?.alive) {
        killCat(state, "nightsong", "found at dawn beneath the border rocks — the Clan called it a fall; the claw marks under his fur said otherwise");
        state.flags.nightsong_dead = true;
        adjRel(state, "brightstream", PLAYER_ID, { affection: -10 });
        addMemory(state, PLAYER_ID, "I told myself it was training. I stayed in my den. At dawn they carried Nightsong home, and the part of me that keeps score wrote one name: mine.", "bad", 10, ["nightsong", "silentpaw"]);
        return `You tell yourself it was training. At dawn, a patrol finds Nightsong's body beneath the border rocks. MapleStar calls it a fall. Brightstream stands over him for a very long time without making any sound at all. ${silentName} sits vigil longest of anyone, perfectly still, perfectly composed.`;
      }
      return "The night passes.";
    }
    case "threat_brightstream": {
      const bs = state.cats.brightstream;
      if (choice === 0) {
        state.flags.saved_brightstream = true;
        adjRel(state, "brightstream", PLAYER_ID, { trust: 20, affection: 15 });
        addMemory(state, "brightstream", "Mistyblaze came through the fog for me. Long ago I carried two secrets along that river; tonight a cat carried me back from it.", "good", 10, [PLAYER_ID]);
        return `You find her at the river bend, and you are not the only one who has: a black shape stands motionless on the far bank, fog pooling around him like something he ordered. When he sees you plant yourself at her side, he simply... withdraws. Brightstream doesn't speak until camp. Then: "You knew to come. What has he become, Mistyblaze — and how much of it is mine?"`;
      }
      if (choice === 1) {
        state.flags.saved_brightstream = true;
        state.flags.windhawk_involved = true;
        adjRel(state, "windpaw", PLAYER_ID, { trust: 15, friendship: 10 });
        adjRel(state, "brightstream", PLAYER_ID, { trust: 15 });
        addMemory(state, "windpaw", "In the fog by the river, my brother looked at me across the water like a stranger wearing his pelt. Mistyblaze was the one who fetched me. I won't forget which cat thought I deserved to know.", "secret", 10, [PLAYER_ID, "silentpaw", "brightstream"]);
        return `Windhawk doesn't ask why — she runs. You reach the river together, and it is Windhawk stepping out of the fog that stops everything: ${silentName} looking at his own litter-sister across the water. Whatever he sees in her face, it unmakes something in his. He vanishes into the mist. "Misty," Windhawk says slowly, "why did my brother look at me like I was part of it?" The truth is now a question she will not stop asking.`;
      }
      if (bs?.alive) {
        killCat(state, "brightstream", "drowned at the river bend in the fog — her claws full of black fur no cat dared name aloud");
        state.flags.brightstream_dead = true;
        addMemory(state, PLAYER_ID, "I stayed in camp. They found Brightstream at the river bend where her secret began. In her claws: black fur. In my chest, ever since: the sound of fog.", "bad", 10, ["brightstream", "silentpaw"]);
        return `Fog and fear, you tell yourself, and sort herbs that don't need sorting. Brightstream does not return for the dawn patrol assignments — the first time in her life. They find her at the river bend. The Clan mourns its deputy as an accident. You count the black hairs in her claws and say nothing, because saying it makes it real.`;
      }
      return "The fog lifts by dawn.";
    }
    case "border_clash": {
      const blackstar = state.cats.blackstar;
      if (choice === 0) {
        state.flags.stood_between = true;
        adjRel(state, "silentpaw", PLAYER_ID, { affection: 10, respect: 10 });
        adjRel(state, "blackstar", PLAYER_ID, { respect: 15 });
        addMemory(state, "silentpaw", "Mistyblaze stood between me and Blackstar with nothing but herbs on his breath and no fear in his legs. For one heartbeat, the burning stopped. One heartbeat. I keep it where I keep him.", "secret", 10, [PLAYER_ID, "blackstar"]);
        return `You walk into the space between father and son, and become the one thing neither is willing to strike. "Move," ${silentName} says. You don't. Behind you, Blackstar speaks for the first time: "He stands like his conviction has roots. Your Clan breeds better cats than liars." The armies uncoil, a war postponed. Nothing is fixed. But nobody bleeds today.`;
      }
      if (choice === 1) {
        state.flags.blackstar_truth = true;
        adjRel(state, "silentpaw", "blackstar", { suspicion: -10, affection: 5 });
        return `Blackstar stares at you — then, astonishingly, obeys. In front of both Clans he says it plainly: the border crossing, the two kits, the choice to stay away, all of it, in a voice that never wavers and never asks forgiveness. "Hate me for the right things, at least," he finishes. ${silentName} listens like a cat drinking after three days. It doesn't heal him. It aims him differently.`;
      }
      if (choice === 2) {
        if (state.flags.lied_to_silent) {
          adjRel(state, "silentpaw", PLAYER_ID, { trust: -10 });
          return `"Come home," you call. He laughs — at HOME, the word. "Which one? The den full of liars, or the pines full of strangers?" But your voice reaches him where no other could, and he steps back across the line. NightClan melts into the trees. You've spent influence you may want back later.`;
        }
        adjRel(state, "silentpaw", PLAYER_ID, { affection: 5 });
        return `"It won't unmake a single lie," you say, "and you know it." The truth of it hits him harder than any warrior could. He looks at Blackstar one last, long moment — cataloguing, the way he catalogues everything — then turns his back on his father and walks home beside you in total silence.`;
      }
      // stay back
      if (blackstar?.alive && !state.flags.stood_between) {
        state.flags.border_blood = true;
        const bsc = state.cats.blackstar;
        if (bsc) bsc.health = clamp(bsc.health - 40);
        adjRel(state, "blackstar", "silentpaw", { fear: 10, respect: 10 });
        return `You keep to the treeline with your herbs, and so you have a perfect view when words run out: a blur of black on black, a scream, two Clans surging and separating like water. Blackstar limps away with a wound that will scar; a NightClan warrior carries a gash you'll smell infection in by moonrise. ${silentName} walks home past you, breathing hard, eyes bright. "He bleeds," he tells you, wonderingly. "The legend bleeds."`;
      }
      return "The border falls quiet.";
    }
    case "final_confrontation":
      return resolveEnding(state, choice);
    default:
      return "";
  }
}

// ── ENDINGS ─────────────────────────────────────────────────────────────────
function fates(state: GameState): string {
  const c = state.cats;
  const lines: string[] = [];
  const dead = Object.values(c).filter((x) => !x.alive);
  if (dead.length > 0) lines.push("Lost along the way: " + dead.map((d) => `${d.name} (moon ${d.deathMoon})`).join(", ") + ".");
  else lines.push("Against all odds, not a single cat was lost. The elders will call these the Miracle Moons.");
  if (c.windpaw?.alive) {
    if (state.flags.windstar) lines.push("Windhawk — WindStar now — leads with her mother's patience and her father's iron. The Clans say no border has ever been safer, or better understood.");
    else if (c.brightstream && !c.brightstream.alive) lines.push("Seasons later, when MapleStar's last life ended, the Clan looked to the fastest, truest cat it had. Windhawk became WindStar — daughter of two Clans, leader of one.");
    else lines.push("Windhawk runs the borders still, and some cats whisper that StarClan has plans for her yet.");
  }
  if (c.nightsong?.alive) lines.push("Nightsong grows old in the elders' den, telling exactly one secret's worth fewer stories than he knows.");
  if (c.brightstream?.alive) lines.push("Brightstream serves the Clan still, lighter by one enormous stone.");
  if (c.hollypaw?.alive) lines.push("Hollyspark laughs again, though she still sleeps facing the den entrance.");
  return lines.join("\n");
}

function resolveEnding(state: GameState, choice: number): string {
  const trusted = state.suspicion < 40;
  const support = [
    state.flags.told_maplestar,
    state.flags.clan_alerted,
    state.flags.saved_brightstream,
    state.flags.windhawk_involved,
    state.flags.blackstar_truth,
    state.flags.stood_between,
    state.flags.juniper_saved && state.flags.investigated_juniper,
    state.flags.target_saved,
    state.flags.watching_silent,
    state.flags.told_him_yourself,
    state.flags.truth_gentled,
  ].filter(Boolean).length;
  const silent = state.cats.silentpaw;
  const player = state.cats[PLAYER_ID];

  if (choice === 2 && trusted) {
    // go with him
    state.ending = {
      id: "two_shadows",
      title: "ENDING — Two Shadows",
      text:
        `You go with him.\n\nThe Clan wakes to find its medicine cat's nest cold and its strangest warrior gone. Some say you were taken. Windhawk knows better, and never says.\n\nFor seasons afterward, border patrols of every Clan report the same thing: two sets of prints that never separate, a tricolor pelt and a black one, glimpsed at dusk and gone by dark. Rogues speak of a healer who mends any wound for free, and the silent cat who watches every patient with unblinking green eyes until they leave.\n\nYou saved every life you could, in the end — except the two that walked away.\n\n` +
        fates(state),
    };
    return "";
  }

  if (choice === 0) {
    // plead
    if (support >= 3 && !state.flags.lied_to_silent) {
      if (silent) {
        silent.alive = true;
        state.flags.silent_exiled = true;
      }
      state.ending = {
        id: "long_thaw",
        title: "ENDING — The Long Thaw",
        text:
          `"Let me help you," you say — and because you never lied to him, the words still have somewhere to land.\n\nThe claws sheathe, one by one, like a decision being unmade. In the end there is no battle: only a young cat sitting down in the snow in front of the whole Clan, hollowed out by a lifetime of other cats' choices.\n\nMapleStar's judgment is exile — but exile with the truth spoken aloud, all of it, every name. Blackstar waits at the border. Whatever else he failed at, he is there.\n\nSilentshadow looks back exactly once — at you — and then the pines take him. Cats say NightClan has a new warrior with green eyes who never speaks of his past, and who leaves catmint on the HollyClan border every leafbare, precisely where a medicine cat will find it.\n\n` +
          fates(state),
      };
      return "";
    }
    if (state.flags.lied_to_silent) {
      killCat(state, PLAYER_ID, "died in the medicine den defending the truth he told too late");
      state.ending = {
        id: "silence",
        title: "ENDING — The Medicine Cat's Silence",
        text:
          `"Let me help you," you say — and then, because he deserves one true thing, you finally tell him: you knew. You always knew.\n\nHe goes very still, the way he does. The lie was the last branch he had his weight on.\n\nJuniperfang finds the den at dawn. The Clan tells the story differently every season, but the elders keep one detail always: the black warrior was gone by morning, and on the medicine cat's nest lay a single sprig of catmint, out of season, impossible, from a ravine beyond the border.\n\nDeep in NightClan territory, a black cat tells no one why he digs a resting hollow big enough for two.\n\n` +
          fates(state),
      };
      return "";
    }
    // partial support
    if (silent) killCat(state, "silentpaw", "fell in the final confrontation, in the camp where he was raised on a story");
    state.ending = {
      id: "shadow_falls",
      title: "ENDING — The Shadow Falls",
      text:
        `You plead. For a heartbeat — you'll swear this at every vigil after — it almost works.\n\nThen Falconwind shifts her weight in the dark, and the spell breaks, and everything happens at once. The Clan you half-prepared is prepared just enough to survive him and not enough to save him.\n\nYou hold his head at the end, herbs useless in the snow around you. "You waited for me," he says — kithood words, fresh-kill shared at the nursery wall. "Nobody else waited." Then the green eyes go somewhere you cannot follow, not even in dreams.\n\nYou are the Clan's healer. You will spend the rest of your life learning that some wounds arrive already too old to treat.\n\n` +
        fates(state),
    };
    return "";
  }

  // choice === 1 or defiant refusal: stand with clan
  if (support >= 4) {
    if (silent) {
      silent.alive = true;
      state.flags.silent_exiled = true;
    }
    state.ending = {
      id: "wall_of_cats",
      title: "ENDING — A Wall of Cats",
      text:
        `"I won't let you hurt anyone else."\n\nAnd because of every quiet thing you did across the moons — the warnings, the watches, the truths placed with the right cats — you are not saying it alone. Windhawk steps up on your left. Hollyspark on your right. Falconwind, MapleStar, the whole living wall of a Clan that was ready because you made it ready.\n\nSilentshadow reads the arithmetic instantly; he was always the best of us at counting. There is no battle. There is just a black cat walking backward out of the only home he ever had, eyes on you the whole way, and the bramble tunnel closing behind him like water.\n\nBorder patrols find gifts sometimes, in the seasons after. Catmint. A perfect twig. Once, unbelievably, a black feather. You treat these like what they are: symptoms. The patient is alive out there. That will have to be enough.\n\n` +
        fates(state),
    };
    return "";
  }
  if (support >= 2) {
    if (silent) killCat(state, "silentpaw", "died at the camp entrance, facing the Clan that raised him inside a lie");
    state.ending = {
      id: "broken_star",
      title: "ENDING — Beneath a Broken Star",
      text:
        `The Clan stands with you — most of it, enough of it — and Silentshadow chooses the war anyway, because a lifetime of borrowed rage has to go somewhere.\n\nIt is short and it is terrible and you spend it doing what medicine cats do: dragging the bleeding out from under the fighting. When it ends, the snow at the camp entrance needs a moon to look like snow again.\n\nYou sit vigil for him alone at first. Then Windhawk joins you. Then, unbelievably, Brightstream's old friends, and Nightsong's, and one by one a Clan that is learning the whole story decides that a cat can be mourned and unforgiven at the same time.\n\nAt dawn, at the border, a huge black tom stands motionless among the pines, watching the vigil from the exact distance at which he lived his son's whole life.\n\n` +
        fates(state),
    };
    return "";
  }
  // no support: player dies
  killCat(state, PLAYER_ID, "fell at the camp entrance, standing alone between his Clan and the storm he watched gather");
  if (silent) {
    silent.alive = false;
    silent.deathMoon = state.moon;
    silent.deathCause = "vanished into the leafbare night; NightClan found the trail at the frozen river, and its end";
  }
  state.ending = {
    id: "frozen_river",
    title: "ENDING — The Frozen River",
    text:
      `You stand alone, because alone is what your choices left you.\n\n"You were just quieter about it than the rest," he said. You had no answer then. You have none now, as the camp erupts behind you and the cold arrives with a strange, specific gentleness — the snow falling red, exactly like the dream you never learned to read in time.\n\nThe Clan survives the night. Clans do. In the confusion, Silentshadow is gone; NightClan trackers follow his prints to the middle of the frozen river, where the ice has opened and closed again like a door.\n\nThe elders tell it every leafbare now — the medicine cat and the shadow, the secret that ate two Clans' worth of love. They always end it the same way: with the dream-voice's warning, spoken to every kit who will listen.\n\nFrost preserves everything. Even lies. Especially lies.\n\n` +
      fates(state),
  };
  return "";
}

// ── story scheduling per moon ───────────────────────────────────────────────
function scheduleStory(state: GameState, r: () => number) {
  const m = state.moon;
  const q = (id: string) => {
    if (!state.pendingEvents.includes(id) && !state.flags["done_" + id]) state.pendingEvents.push(id);
  };
  // a major beat roughly every 3 moons; smaller events fill the gaps naturally
  if (m === 3) q("blackstar_visit");
  if (m === 5) q("clue_falcon");
  if (m === 9) q("gathering_shadow");
  // m7: warrior_names (fires from the ceremony itself)
  if (m === 10) q("silent_gift");
  if (m === 13) q("holly_warning");
  if (m === 15) q("juniper_plot");
  if (m === 17) q("nightsong_request");
  if (m === 18 && state.clues.length >= 2) q("evidence_moment");
  if (m === 19 && !state.flags["done_evidence_moment"]) q("evidence_moment");
  if (m === 20) q(state.flags.silent_knows ? "ravine_averted" : state.cats.nightsong?.alive ? "nightsong_attack" : "silent_learns");
  if (m === 22 && !state.flags.truth_gentled) q("threat_brightstream");
  if (m === 24) q("shadow_targets");
  if (m === 26) q("border_clash");
  if (m === 28 && !state.flags["done_shadow_targets_2"]) q("shadow_targets_2");
  if (m === 30) q("final_confrontation");
  void r;
}

// ── PASS MOON ───────────────────────────────────────────────────────────────
export function passMoon(state: GameState): string[] {
  const r = mulberry(state.moon * 7919 + 13);
  state.log = [];
  // 1. consequences of neglect
  resolveSickness(state, r);
  // 2. advance
  state.moon++;
  state.weather = rollWeather(state.moon, r);
  for (const c of Object.values(state.cats)) {
    if (!c.alive) continue;
    c.ageMoons++;
    if (c.mood === "grieving" && r() < 0.4) c.mood = "content";
    if (!c.sick && c.health < 100) c.health = clamp(c.health + 10);
  }
  log(state, `— Moon ${state.moon} begins. ${seasonOf(state.moon)}, ${state.weather}. —`);
  // 3. regrowth & ceremonies & sim
  regrowHerbs(state, r);
  lifecycle(state, r);
  trainingSim(state, r);
  socialSim(state, r);
  randomEvents(state, r);
  scheduleStory(state, r);
  // elders age (only after the main arc can they pass naturally)
  for (const eid of ["rabbitclaw", "snowscar"]) {
    const e = state.cats[eid];
    if (e?.alive && e.ageMoons > 150 && state.moon > 24 && r() < 0.08) killCat(state, eid, "died peacefully in the elders' den, full of moons and stories");
  }
  // reset per-moon actions
  state.actionsThisMoon = {};
  state.energy = 100;
  state.timeOfDay = "dawn";
  // suspicion drifts up slightly in late game if ignoring everything
  if (state.moon >= 8 && state.moon <= 24 && state.moon % 2 === 0) state.suspicion = clamp(state.suspicion + 1);
  // record history
  state.history.push({ moon: state.moon, events: [...state.log] });
  if (state.history.length > 40) state.history.shift();
  assignRoutines(state, state.moon * 31 + 7);
  return state.log;
}

// ── PLAYER ACTIONS ──────────────────────────────────────────────────────────
export function gatherHerb(state: GameState, nodeId: string): string {
  const n = state.herbNodes.find((x) => x.id === nodeId);
  if (!n) return "Nothing here.";
  const def = HERB_BY_ID[n.herb];
  const season = seasonOf(state.moon);
  if (n.qty <= 0) return `The ${def.name.toLowerCase()} here ${def.seasons.includes(season) ? "has been picked clean — it needs time to regrow" : `is out of season. It grows in ${def.seasons.join(", ")}`}.`;
  n.qty--;
  state.herbs[n.herb] = (state.herbs[n.herb] ?? 0) + 1;
  const p = state.cats[PLAYER_ID];
  if (p.role === "medapprentice") p.trainingProgress = Math.min(100, (p.trainingProgress ?? 0) + 2);
  advanceTime(state);
  return `You carefully gather ${def.name.toLowerCase()}. (${def.use}) The store now holds ${state.herbs[n.herb]}.`;
}

export function treatCat(state: GameState, catId: string): string {
  const c = state.cats[catId];
  if (!c || !c.alive) return "There is no one to treat.";
  if (!c.sick) return `${c.name} is healthy. "Save your herbs," ${c.gender === "tom" ? "he" : "she"} says, half-smiling.`;
  const herb = c.sick.herb;
  if ((state.herbs[herb] ?? 0) <= 0) return `You need ${HERB_BY_ID[herb].name.toLowerCase()} to treat ${c.name}'s ${c.sick.name} — and the store is empty. Find some in the territory before the moon passes.`;
  state.herbs[herb]--;
  const sickName = c.sick.name;
  c.sick = null;
  c.health = clamp(c.health + 30);
  c.mood = "grateful";
  adjRel(state, catId, PLAYER_ID, { trust: 10, affection: 8, respect: 8 });
  addMemory(state, catId, `When ${sickName} had me down, ${state.cats[PLAYER_ID].name} treated me with ${HERB_BY_ID[herb].name.toLowerCase()} and stayed until the shaking stopped. A Clan is only as strong as its healer's patience.`, "good", 7, [PLAYER_ID]);
  addMemory(state, PLAYER_ID, `I treated ${c.name}'s ${sickName} with ${HERB_BY_ID[herb].name.toLowerCase()}. ${c.gender === "tom" ? "He" : "She"} gripped my paw until the worst passed.`, "good", 5, [catId]);
  const pl = state.cats[PLAYER_ID];
  if (pl.role === "medapprentice") pl.trainingProgress = Math.min(100, (pl.trainingProgress ?? 0) + 4);
  advanceTime(state);
  return `You treat ${c.name}'s ${sickName} with ${HERB_BY_ID[herb].name.toLowerCase()}. ${c.gender === "tom" ? "His" : "Her"} breathing eases. "Thank you, ${state.cats[PLAYER_ID].name}," ${c.gender === "tom" ? "he" : "she"} murmurs.`;
}

export function doSleep(state: GameState): { msg: string; dream: Dream | null } {
  advanceTime(state);
  state.timeOfDay = "dawn";
  state.energy = 100;
  if (state.actionsThisMoon.dreamed) return { msg: "You sleep soundly. No dreams come — only the ordinary dark, which is its own kind of mercy.", dream: null };
  state.actionsThisMoon.dreamed = true;
  const available = DREAMS.filter((d) => d.minMoon <= state.moon && !state.dreamsSeen.includes(d.id));
  const r = mulberry(state.moon * 313 + state.timeTicks);
  if (available.length === 0 || r() < 0.35) return { msg: "You dream of warm moss and the smell of catmint. Restful, and gone by dawn.", dream: null };
  const d = available[0];
  state.dreamsSeen.push(d.id);
  if (d.clue) {
    state.clues.push("Dream: " + d.text.slice(0, 90) + "...");
    state.flags[d.clue] = true;
  }
  if (d.suspicion) state.suspicion = clamp(state.suspicion + d.suspicion);
  addMemory(state, PLAYER_ID, `A dream I couldn't shake: ${d.text.slice(0, 110)}...`, "secret", 6);
  return { msg: d.text, dream: d };
}

export function doTrain(state: GameState): string {
  if (state.actionsThisMoon.trained) return "You've already trained this moon. Juniperfang would say herbs beat heroics anyway.";
  state.actionsThisMoon.trained = true;
  advanceTime(state);
  const r = mulberry(state.moon * 101 + 5);
  const partner = pick(aliveCats(state).filter((c) => (c.role === "apprentice" || c.role === "warrior") && c.id !== PLAYER_ID), r);
  adjRel(state, partner.id, PLAYER_ID, { friendship: 5, respect: 4 });
  adjRel(state, PLAYER_ID, partner.id, { friendship: 4 });
  const move = pick(["a defensive roll", "the escape-twist Juniperfang insists every healer learn", "reading an opponent's shoulders", "how to fall without breaking anything important"], r);
  addMemory(state, partner.id, `Trained with ${state.cats[PLAYER_ID].name} in the hollow. For a cat of herbs, ${state.cats[PLAYER_ID].gender === "tom" ? "he" : "she"} learns fast.`, "good", 3, [PLAYER_ID]);
  return `You practice ${move} with ${partner.name} in the training hollow. You're a healer, not a fighter — but knowing how NOT to die is medicine too. (${partner.name} +respect)`;
}

export function doPatrol(state: GameState): string {
  if (state.actionsThisMoon.patrolled) return "You've already joined a patrol this moon.";
  state.actionsThisMoon.patrolled = true;
  advanceTime(state);
  const r = mulberry(state.moon * 211 + 9);
  const warriors = aliveCats(state).filter((c) => (c.role === "warrior" || c.role === "deputy") && c.id !== PLAYER_ID);
  const a = pick(warriors, r);
  let b = pick(warriors, r);
  if (b.id === a.id && warriors.length > 1) b = warriors.find((w) => w.id !== a.id)!;
  adjRel(state, a.id, PLAYER_ID, { friendship: 4, respect: 5 });
  adjRel(state, b.id, PLAYER_ID, { friendship: 4, respect: 5 });
  const outcome = pick(
    [
      `NightClan scent lay heavy along the border. ${a.name} bristled; you noted which bushes the scent favored.`,
      `${b.name} tore a pad on a bramble. You packed it with cobwebs on the spot — patrols love a healer along.`,
      `All quiet. ${a.name} and ${b.name} argued cheerfully the whole way about the correct way to mark a scent line.`,
      `You spotted a hawk shadow before anyone else and the patrol took cover. ${a.name} won't stop telling cats about it.`,
      `Near the river, ${b.name} pointed out fresh paw prints that vanished at the waterline. Big prints. A cat's.`,
    ],
    r
  );
  if (outcome.includes("cobwebs") && (state.herbs.cobweb ?? 0) > 0) state.herbs.cobweb--;
  if (outcome.includes("vanished at the waterline")) {
    state.suspicion = clamp(state.suspicion + 3);
    if (state.moon >= 8) state.clues.push("Fresh prints by the river that vanished at the waterline — a cat who didn't want to be tracked.");
  }
  return `You join ${a.name} and ${b.name} on patrol. ${outcome} (+respect with both)`;
}

export function doPlayKits(state: GameState): string {
  const kits = aliveCats(state).filter((c) => c.role === "kit");
  if (kits.length === 0) return "The nursery is empty of kits these days — they've all grown into their bigger names.";
  advanceTime(state);
  const r = mulberry(state.moon * 401 + state.timeTicks);
  for (const k of kits) {
    adjRel(state, k.id, PLAYER_ID, { affection: 6, friendship: 6 });
  }
  const gold = state.cats.goldenfur;
  if (gold?.alive) adjRel(state, "goldenfur", PLAYER_ID, { affection: 4, trust: 3 });
  const wolf = state.cats.wolftail;
  if (wolf?.alive) adjRel(state, "wolftail", PLAYER_ID, { affection: 4 });
  const scene = pick(
    [
      `${pick(kits, r).name} ambushes your tail while ${pick(kits, r).name} narrates the battle like an elder telling war stories.`,
      `You teach them 'medicine cat says' — they only obey instructions that start with a herb name. Chaos, but educational chaos.`,
      `A moss-ball tournament erupts. ${pick(kits, r).name} cheats magnificently and denies everything.`,
      `You let them 'treat' your imaginary wounds with leaf scraps. ${pick(kits, r).name} declares you 'mostly saved'.`,
    ],
    r
  );
  return `You spend time with the kits. ${scene} (kits +affection)`;
}

export function doObserve(state: GameState, catId: string): string {
  const c = state.cats[catId];
  if (!c) return "";
  advanceTime(state);
  const r = mulberry(state.moon * 601 + catId.length * 37 + state.timeTicks);
  if (catId === "silentpaw") {
    state.suspicion = clamp(state.suspicion + (state.moon >= 8 ? 6 : 3));
    adjRel(state, "silentpaw", PLAYER_ID, { suspicion: 4 });
    const obs =
      state.moon < 8
        ? pick(["He watches the camp entrance whenever a patrol is late. Always counting cats in, cats out.", "He mouths words sometimes when others speak — memorizing conversations, you realize.", "He knows your schedule better than you do. He's at every den you're headed to, slightly early."], r)
        : state.moon < 13
        ? pick(["He tracks who you talk to. Not obviously. But his ear swivels every time you laugh at something another cat said.", "You find scratch-tallies on a root behind the apprentices' den. Groups of days? Visits? You genuinely can't tell.", "He follows Brightstream with his eyes lately, frowning slightly, like a cat rereading a trail."], r)
        : pick(["His 'casual' routes through camp pass every den you might be in, in order. It's a patrol. You are the border.", "He returns from 'night hunting' with pine sap on his pads. Pine doesn't grow on HollyClan land.", "He speaks to Windhawk less each moon. He watches her more each moon. Sorting her, you think, into some category.", "Three cats now unconsciously step back when he passes. He notes each flinch with something that isn't hurt. It's arithmetic."], r);
    state.clues.push("Observed: " + obs);
    return `You watch ${c.name} without being seen — you hope. ${obs} (+Suspicion, clue gained)`;
  }
  if (catId === "brightstream") {
    const obs = pick(["She pauses at the nursery every dawn. Never enters. Counts to something. Moves on.", "When Silentpaw's name is called she turns her head a fraction before anyone else does. A mother's reflex, your memory supplies, unhelpfully.", "She keeps a dried pine sprig tucked under the moss at the back of her nest. You un-see it as fast as you can."], r);
    state.clues.push("Observed: " + obs);
    state.suspicion = clamp(state.suspicion + 2);
    return `You quietly observe ${c.name}. ${obs} (clue gained)`;
  }
  if (catId === "nightsong") {
    const obs = pick(["He positions himself between Silentpaw and the camp entrance. Always. It looks casual. It has never once been casual.", "He and Brightstream exchange a glance whenever NightClan is mentioned — a whole conversation, one heartbeat long.", "He trains Windpaw's speed personally, joyfully. With Silentpaw he trains only defense, and watches with worry he thinks he hides."], r);
    state.clues.push("Observed: " + obs);
    return `You quietly observe ${c.name}. ${obs} (clue gained)`;
  }
  return `You watch ${c.name} for a while. ${c.name} is ${c.activity} — ${pick(["unremarkably", "peacefully", "with the usual amount of drama"], r)}. The ordinary life of a Clan, going on.`;
}

// ── strength & combat outcomes ─────────────────────────────────────────────
// Who wins a fight depends on role, age, traits, health — and in Silentshadow's
// case, the cold focus of obsession. Attacked cats can die, survive wounded,
// or drive the attacker off.
export function catStrength(state: GameState, id: string): number {
  const c = state.cats[id];
  if (!c) return 0;
  let s = 30;
  if (c.role === "warrior" || c.role === "deputy") s += 25;
  else if (c.role === "leader") s += 28;
  else if (c.role === "apprentice") s += 12;
  else if (c.role === "medicine" || c.role === "medapprentice") s += 6; // healers heal; they rarely fight
  else if (c.role === "elder") s -= 10;
  else if (c.role === "queen") s += 10;
  else if (c.role === "kit") s = 4;
  else if (c.role === "outsider") s += 30; // Blackstar
  // prime of life: 18–90 moons
  if (c.ageMoons >= 18 && c.ageMoons <= 90) s += 10;
  else if (c.ageMoons > 110) s -= 12;
  for (const t of c.traits) {
    if (["protective", "bold", "fierce if kits are threatened", "brave", "fearless", "wild"].includes(t)) s += 6;
    if (["lazy", "sleepy", "dreamy", "tiny"].includes(t)) s -= 6;
    if (["intense", "obsessive beneath the surface"].includes(t)) s += 5;
  }
  // obsession burns like a second set of muscles
  if (c.id === "silentpaw" && state.moon >= 7) s += 12;
  if (c.id === "silentpaw" && state.flags.silent_knows) s += 6;
  return Math.max(2, s * (c.health / 100));
}

export type AttackResult = "killed" | "wounded" | "repelled";
export function attackOutcome(state: GameState, attackerId: string, victimId: string, r: () => number): AttackResult {
  const sa = catStrength(state, attackerId);
  const sv = catStrength(state, victimId);
  const diff = sa - sv;
  const killChance = clamp(32 + diff * 1.4, 4, 88) / 100;
  const repelChance = clamp(18 - diff * 0.9, 4, 60) / 100;
  const roll = r();
  if (roll < killChance) return "killed";
  if (roll > 1 - repelChance) return "repelled";
  return "wounded";
}

// ── telling Silentshadow the truth yourself ────────────────────────────────
// Available from the talk menu when his trust and affection are high enough.
// Learning it from the one cat he believes in changes everything downstream:
// the moon-20 ravine attack never happens — the confrontation is words, not claws.
export function canTellSilentTruth(state: GameState): boolean {
  const silent = state.cats.silentpaw;
  if (!silent?.alive || state.flags.silent_knows) return false;
  if (state.moon < 8) return false; // still a young apprentice — the words would land on a kit
  const rl = silent.rel[PLAYER_ID];
  return rl.trust >= 70 && rl.affection >= 70;
}

export function tellSilentTruth(state: GameState): string {
  const silent = state.cats.silentpaw;
  if (!silent?.alive) return "";
  if (state.flags.silent_knows) return `${silent.name} already knows. There is nothing left to tell — only what comes after.`;
  advanceTime(state);
  state.flags.silent_knows = true;
  state.flags.told_him_yourself = true;
  state.flags.confessed_knowledge = true;
  silent.mood = "shaken";
  silent.goals = ["decide what the truth makes him", "keep Mistyblaze — the only cat who chose honesty"];
  adjRel(state, "silentpaw", "nightsong", { affection: -25, trust: -45, suspicion: 30, loyalty: -30 });
  adjRel(state, "silentpaw", "brightstream", { affection: -20, trust: -45, suspicion: 30 });
  adjRel(state, "silentpaw", PLAYER_ID, { trust: 6, affection: 4, loyalty: 8, suspicion: -5 });
  addMemory(state, "silentpaw", "Mistyblaze sat me down and told me everything. Brightstream. Blackstar. Windhawk my sister. Nightsong's whole loving lie. He knew since we were kits — and he is the only one who ever chose to stop knowing it AT me. Everyone else made me a secret. He made me the one being told.", "secret", 10, [PLAYER_ID, "brightstream", "blackstar", "nightsong", "windpaw"]);
  addMemory(state, PLAYER_ID, `I told ${silent.name} the truth myself — all of it, quietly, before it could reach him as a weapon. He went so still I counted his breaths. Then he thanked me. I don't know yet what I set in motion. I only know it was mine to set.`, "secret", 10, ["silentpaw"]);
  addMemory(state, "nightsong", "Mistyblaze told him. I felt it before I was told — the way he stopped looking at me entirely, which from him is louder than a scream. Part of me is furious. The larger part is only relieved the wall finally fell on someone strong enough to choose where it landed.", "secret", 9, [PLAYER_ID, "silentpaw"]);
  return (
    `You take him to the quiet bend of the river at dusk and you tell him everything: the freezing night, the two kits smelling of pine, Brightstream, Blackstar, Windhawk, Nightsong's promise — and your own silence, all these moons.\n\n` +
    `He does not move for a very long time. The river talks for both of you.\n\n` +
    `"You knew," he says finally. "Since we were kits." A breath. "And you're the only one who ever told me." He looks at you the way he looked at you across the nursery, a lifetime ago, over shared fresh-kill.\n\n` +
    `"Thank you, Mistyblaze." The calm in his voice has a crack in it, and something new moving behind the crack.\n\nWhat he does with the truth now is his. What you did with it is already done.`
  );
}

export type TalkKind = "kind" | "help" | "defend" | "hostile";

// every personality bites back differently
const HOSTILE_REPLIES: Record<string, string[]> = {
  stern: [`"{N} regards you with flat disappointment. "I expected pettiness from some cats. Not from my medicine cat." The words land heavier than claws.`, `"Careful," {N} says, without raising her voice even a whisker. "A Clan forgives its healer almost anything. Almost."`],
  warm: [`{N} flinches as if struck, then simply looks at you — hurt arranging itself politely. "I... see. I'll leave you to your herbs, then."`, `"Oh," {N} says softly. Nothing else. The 'oh' follows you around camp for the rest of the day.`],
  dry: [`{N} snorts. "Sharp tongue. Shame it's attached to someone who still can't tell yarrow from juniper under pressure." She wins the exchange and you both know it.`, `"Noted," {N} says, returning to her sorting. "I'll remember this conversation the next time you need me to cover for one of your mistakes."`],
  protective: [`{N} goes very still. "I've buried cats I liked better than whoever you're pretending to be right now. Come back when you're yourself."`, `{N} doesn't rise to it. "Something's eating you. When you want to tell me what, I'll be here. Until then — watch your tone."`],
  blunt: [`{N} laughs once, genuinely delighted. "There it is! There's some spine! Shame you waste it on me instead of something useful." He seems to respect you MORE.`, `"Finally," {N} sneers. "I was starting to think they'd apprenticed a mouse. Now get out of my face before I finish the lesson."`],
  sleepy: [`{N} opens one eye. "That seemed important to you." The eye closes. Somehow this is the most devastating possible response.`, `"Mm," {N} yawns. "Wake me when the apology's ready."`],
  cheerful: [`{N}'s grin dies by degrees — the worst thing you've watched all moon. "Wow. Okay. I'm... gonna go run somewhere." He runs.`, `{N} blinks, laughs uncertainly, realizes you mean it, and deflates like a pierced moss-ball. "Right. Sorry for... being around, I guess."`],
  wary: [`{N}'s eyes narrow with something like satisfaction. "Interesting. Hostility is information. What are you protecting right now, I wonder?" She leaves — a tally mark heavier.`, `"Good," {N} says flatly. "I prefer enemies who declare themselves." You are fairly sure you've just been filed somewhere permanent.`],
  odd: [`{N} clutches his current twig to his chest. "The twigs heard that. The twigs forget nothing. ...I can ask them to make an exception. ONE exception."`, `{N} considers you gravely, then sets a small bent twig at your paws. "For your anger. It helps to hold something that bends without breaking." It's weirdly touching and you feel terrible.`],
  gentle: [`{N} absorbs it the way mothers do — takes the whole blow and hands you back patience. "You'll feel better after you've eaten. Come find me when you do." Somehow that's worse than anger.`, `{N}'s ears flatten with hurt, then right themselves by force of will. "I'll pretend the cold said that, and not my son." (She will not entirely pretend.)`],
  gruff: [`{N} barks a laugh. "HA! I've been insulted by cats whose bones are dust, kit. You'll have to sharpen that considerably."`, `"Mind your whiskers," {N} growls. "I'm old, not deaf, and I outrank you in stories survived."`],
  playful: [`{N}'s tail droops to the ground. "You're MEAN today," comes the small reply, and the walking-away is performed with maximum tragic dignity.`, `{N} gasps theatrically — then genuinely. "I'm telling Goldenfur," and this is somehow a real threat.`],
  quiet: [``],
  cold: [`{N} looks at you the way winter looks at a late flower. "Bold. Remember that boldness spends like prey in leafbare — faster than you think."`],
};

export function socialAction(state: GameState, catId: string, kind: TalkKind): string {
  const c = state.cats[catId];
  if (!c) return "";
  advanceTime(state);
  const player = state.cats[PLAYER_ID];
  if (kind === "hostile") {
    const r = mulberry(state.moon * 887 + state.timeTicks * 13 + catId.length);
    // ── Silentshadow: hostility toward an obsessive cat is playing with teeth ──
    if (catId === "silentpaw") {
      const count = ((state.flags.silent_hostility as number) || 0) + 1;
      state.flags.silent_hostility = count;
      adjRel(state, "silentpaw", PLAYER_ID, { affection: -8, trust: -10, jealousy: 8, suspicion: 10 });
      state.suspicion = clamp(state.suspicion + 5);
      if (state.moon < 7) {
        addMemory(state, "silentpaw", "Mistypaw was cold to me today. I replayed the conversation forty times before moonhigh looking for the moment it went wrong. I'll fix it. I fix everything between us.", "bad", 7, [PLAYER_ID]);
        return `${c.name} takes the coldness like a physical thing, shrinking into his black fur. "Okay," he says quietly. "You're tired. That's all this is." He watches you walk away without blinking, already rewriting the conversation into something survivable.`;
      }
      if (count === 1) {
        addMemory(state, "silentpaw", "He was HOSTILE to me. To ME. I counted the words he used and none of them were ours. Someone has been talking to him. Someone has been turning him. I'll find out who.", "bad", 9, [PLAYER_ID]);
        return `Something happens behind ${c.name}'s eyes — a door you've never seen closing. "That's not you talking," he says, with terrifying certainty. "Someone's been in your ear. I'll find out who." He leaves — and you realize he has decided your hostility is someone else's fault. That should feel like a reprieve. It doesn't.`;
      }
      // second+ hostility during the obsessive era: he may snap
      const snapRoll = r();
      if (count >= 3 || (count === 2 && snapRoll < 0.55)) {
        const result = attackOutcome(state, "silentpaw", PLAYER_ID, r);
        if (result === "killed") {
          player.alive = false;
          player.deathMoon = state.moon;
          player.deathCause = "the medicine den, at moonhigh, at the claws of the cat who loved him most";
          state.ending = {
            id: "counting_stops",
            title: "ENDING — The Counting Stops",
            text:
              `You pushed him away once too often, and obsession has no setting for "let go" — only for "keep," and the terrible places keeping goes when it curdles.\n\n` +
              `He comes to the medicine den at moonhigh, the way he came a hundred gentle times before. His voice is calm. His questions are reasonable. And then they aren't questions anymore.\n\n` +
              `You are a healer. You never learned to fight — you learned to fall, and it isn't enough.\n\nThe last thing you hear is counting, soft as rain: your heartbeats, numbered backward toward zero by the only cat who ever kept the total.\n\n` +
              `By dawn Silentshadow is gone from HollyClan forever. NightClan patrols find prints at the frozen river that simply stop. The Clan buries its medicine cat beneath the catmint patch and never fully learns the shape of what happened — except Windhawk, who guesses everything, and spends the rest of her moons making sure no secret in any Clan is ever again left to rot in the dark.\n\n` +
              `☆ You died at Moon ${state.moon}. Some cats cannot be safely pushed away — only understood in time, or escaped entirely. You did neither.`,
          };
          return "";
        }
        if (result === "wounded") {
          player.health = clamp(player.health - 50);
          state.flags.silent_attacked_player = true;
          adjRel(state, PLAYER_ID, "silentpaw", { fear: 35, trust: -30, affection: -15 });
          adjRel(state, "silentpaw", PLAYER_ID, { suspicion: 10 });
          addMemory(state, PLAYER_ID, `Silentshadow attacked me. ME. It lasted four heartbeats and stopped as suddenly as it started — he looked at his own claws like they'd betrayed him, and fled. I treated my own wounds in the dark, hands shaking, inventing the story I'd tell Juniperfang.`, "bad", 10, ["silentpaw"]);
          addMemory(state, "silentpaw", "I hurt him. The one thing. The ONE thing I was never going to do, and my claws did it in four heartbeats. I ran to the river and screamed at my reflection until something scattered the image. He'll never look at me the same. Correct. He shouldn't.", "secret", 10, [PLAYER_ID]);
          return `You say it — and his stillness breaks all at once, like ice under a paw.\n\nIt lasts four heartbeats. Claws, weight, the smell of your own blood — then nothing: he is off you, staring at his own paws with naked horror, and gone into the dark.\n\nYou dress your own wounds alone. Something between you is cut now, and you both held the claw that cut it. (Health badly hurt — be careful who you push, and when.)`;
        }
        adjRel(state, "silentpaw", PLAYER_ID, { fear: 10, respect: 8 });
        addMemory(state, "silentpaw", "He stood his ground against me. Thin paws, herb-smell, no fighting blood at all — and he didn't give a whisker. I circled him and found no opening because fear makes openings and he refused to be afraid. What IS he made of?", "secret", 9, [PLAYER_ID]);
        return `His stillness cracks — he comes at you a half-step, fast, silent — and you do the one thing no cat he's cornered has done: you hold your ground and keep your eyes on his.\n\nThe half-step dies. He circles once, twice, searching you for the fear that isn't there, and then he simply leaves.\n\nYour legs give out the moment he's out of sight. But something shifted: he respects exactly one thing more than devotion, and you just showed it to him.`;
      }
      addMemory(state, "silentpaw", "Cold again. Twice now. I've started a second list — things that could be taking him from me. Lists hold the world together when cats won't.", "bad", 9, [PLAYER_ID]);
      return `${c.name} receives your coldness in total silence. Then: "Twice," he says, to himself more than you, and walks away doing arithmetic you want no part of. Every instinct you have as a healer says the same thing: this is a symptom, and it is getting worse.`;
    }
    // ── everyone else: flavored by personality ──
    adjRel(state, catId, PLAYER_ID, { affection: -7, friendship: -8, trust: -5 });
    adjRel(state, PLAYER_ID, catId, { friendship: -4 });
    const silent = state.cats.silentpaw;
    if (silent?.alive && state.moon >= 7 && (silent.rel[PLAYER_ID]?.affection ?? 0) > 60) {
      adjRel(state, "silentpaw", catId, { suspicion: 5, jealousy: -5 }); // he approves of your isolation
    }
    if (c.speech === "blunt") adjRel(state, catId, PLAYER_ID, { respect: 6 }); // Shadowgaze respects teeth
    if (c.speech === "wary") adjRel(state, catId, PLAYER_ID, { suspicion: 10 });
    addMemory(state, catId, `${player.name} was cold to me — ${pick(["out of nowhere", "over nothing", "in front of others, which is the part that stings"], r)}. Healers are supposed to be the gentle ones. I'm recalibrating.`, "bad", 5, [PLAYER_ID]);
    const pool = HOSTILE_REPLIES[c.speech]?.filter((l) => l.length > 0) ?? HOSTILE_REPLIES.warm;
    return pick(pool, r).replace(/\{N\}/g, c.name);
  }
  if (kind === "kind") {
    adjRel(state, catId, PLAYER_ID, { affection: 5, friendship: 5 });
    const silent = state.cats.silentpaw;
    if (silent?.alive && catId !== "silentpaw" && state.moon >= 8) adjRel(state, "silentpaw", catId, { jealousy: 4 });
    return `You share tongues with ${c.name}, trading warmth and small news. (${c.name} +affection)`;
  }
  if (kind === "help") {
    adjRel(state, catId, PLAYER_ID, { trust: 6, respect: 5, friendship: 3 });
    addMemory(state, catId, `${player.name} helped me with my duties today without being asked. Cats notice who shows up.`, "good", 3, [PLAYER_ID]);
    return `You spend time helping ${c.name} with ${c.activity === "resting" ? "nest repairs" : c.activity}. (${c.name} +trust, +respect)`;
  }
  // defend: stand up for this cat re: recent snaps
  adjRel(state, catId, PLAYER_ID, { trust: 8, affection: 6, loyalty: 5 });
  addMemory(state, catId, `${player.name} spoke up for me when it would have been easier to say nothing. I remember spines. They're rarer than claws.`, "good", 5, [PLAYER_ID]);
  return `You make a point of standing up for ${c.name} in front of others. Word of such things travels. (${c.name} +trust, +loyalty)`;
}
