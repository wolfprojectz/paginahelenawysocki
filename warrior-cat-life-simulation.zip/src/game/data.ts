import { Cat, CatPattern, GameState, HerbDef, HerbNode, RelStats, Role, Season, SpeechStyle } from "./types";

// ── deterministic rng ───────────────────────────────────────────────────────
export function mulberry(seed: number) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function pick<T>(arr: T[], r: () => number): T {
  return arr[Math.floor(r() * arr.length) % arr.length];
}

export const SEASONS: Season[] = ["Newleaf", "Greenleaf", "Leaf-fall", "Leafbare"];
export function seasonOf(moon: number): Season {
  return SEASONS[Math.floor(((moon - 1) % 12) / 3)];
}

// ── herbs ───────────────────────────────────────────────────────────────────
export const HERBS: HerbDef[] = [
  { id: "cobweb", name: "Cobwebs", use: "stops bleeding from wounds", color: "#e8e8e8", seasons: ["Newleaf", "Greenleaf", "Leaf-fall", "Leafbare"] },
  { id: "marigold", name: "Marigold", use: "prevents infection in wounds", color: "#f2a33c", seasons: ["Newleaf", "Greenleaf", "Leaf-fall"] },
  { id: "catmint", name: "Catmint", use: "cures greencough and whitecough", color: "#7cc47f", seasons: ["Newleaf", "Greenleaf"] },
  { id: "poppy", name: "Poppy seeds", use: "eases pain and helps cats sleep", color: "#2b2b3a", seasons: ["Greenleaf", "Leaf-fall"] },
  { id: "juniper", name: "Juniper berries", use: "soothes bellyache and gives strength", color: "#5b6ea6", seasons: ["Leaf-fall", "Leafbare"] },
  { id: "borage", name: "Borage leaves", use: "brings milk to queens, cools fevers", color: "#6f9ecf", seasons: ["Newleaf", "Greenleaf"] },
  { id: "horsetail", name: "Horsetail", use: "treats infected wounds", color: "#8fae5d", seasons: ["Newleaf", "Greenleaf", "Leaf-fall"] },
  { id: "feverfew", name: "Feverfew", use: "cools fevers and aching heads", color: "#dfe6c8", seasons: ["Newleaf", "Greenleaf", "Leaf-fall"] },
];
export const HERB_BY_ID: Record<string, HerbDef> = Object.fromEntries(HERBS.map((h) => [h.id, h]));

export const HERB_NODES: HerbNode[] = [
  { id: "n_marigold1", map: "territory", x: 12, y: 30, herb: "marigold", qty: 3, max: 3 },
  { id: "n_marigold2", map: "territory", x: 44, y: 12, herb: "marigold", qty: 2, max: 3 },
  { id: "n_catmint1", map: "territory", x: 52, y: 34, herb: "catmint", qty: 2, max: 2 },
  { id: "n_catmint2", map: "territory", x: 8, y: 10, herb: "catmint", qty: 1, max: 2 },
  { id: "n_poppy1", map: "territory", x: 30, y: 8, herb: "poppy", qty: 3, max: 3 },
  { id: "n_juniper1", map: "territory", x: 20, y: 16, herb: "juniper", qty: 3, max: 3 },
  { id: "n_borage1", map: "territory", x: 38, y: 30, herb: "borage", qty: 2, max: 3 },
  { id: "n_horsetail1", map: "territory", x: 26, y: 24, herb: "horsetail", qty: 3, max: 3 },
  { id: "n_feverfew1", map: "territory", x: 48, y: 22, herb: "feverfew", qty: 2, max: 3 },
  { id: "n_cobweb1", map: "territory", x: 16, y: 36, herb: "cobweb", qty: 4, max: 4 },
  { id: "n_cobweb2", map: "camp", x: 6, y: 6, herb: "cobweb", qty: 2, max: 2 },
];

// ── cat patterns ────────────────────────────────────────────────────────────
const P = (style: CatPattern["style"], base: string, patch1: string, patch2: string, eyes: string): CatPattern => ({
  style, base, patch1, patch2, eyes,
});

// ── relationship helpers ────────────────────────────────────────────────────
export function defaultRel(): RelStats {
  return { affection: 40, friendship: 40, trust: 45, respect: 45, fear: 5, jealousy: 5, suspicion: 5, loyalty: 50 };
}
export function rel(over: Partial<RelStats>): RelStats {
  return { ...defaultRel(), ...over };
}

interface CatSeed {
  id: string;
  baseName: string;
  name: string;
  role: Role;
  gender: "tom" | "she-cat";
  desc: string;
  pattern: CatPattern;
  archetype: string;
  traits: string[];
  speech: SpeechStyle;
  goals: string[];
  age: number;
  map: "camp" | "territory";
  x: number;
  y: number;
  knowsSecret?: boolean;
  lives?: number;
}

const SEEDS: CatSeed[] = [
  { id: "maplestar", baseName: "Maple", name: "MapleStar", role: "leader", gender: "she-cat", desc: "a spotted she-cat with steady amber eyes, leader of HollyClan", pattern: P("spotted", "#c98b4e", "#8a5a2e", "#e8c79a", "#e6b93c"), archetype: "wise leader", traits: ["fair", "burdened", "far-sighted"], speech: "stern", goals: ["keep HollyClan safe through leafbare", "choose the right cats to trust"], age: 78, map: "camp", x: 27, y: 6, lives: 3 },
  { id: "brightstream", baseName: "Bright", name: "Brightstream", role: "deputy", gender: "she-cat", desc: "a gray she-cat, deputy of HollyClan, who carries an old sorrow behind her eyes", pattern: P("solid", "#9aa3ad", "#7b8591", "#c4cbd3", "#8fd0c9"), archetype: "guarded heart", traits: ["dutiful", "secretive", "tender when unwatched"], speech: "warm", goals: ["serve MapleStar faithfully", "keep an old promise buried"], age: 60, map: "camp", x: 20, y: 8, knowsSecret: true },
  { id: "juniperfang", baseName: "Juniper", name: "Juniperfang", role: "medicine", gender: "she-cat", desc: "a tricolor medicine cat with sharp wit and gentle paws", pattern: P("patched", "#e8e3da", "#c96f32", "#3a3733", "#a9d34f"), archetype: "dry-humored healer", traits: ["patient", "sardonic", "devoted to herbs"], speech: "dry", goals: ["train Mistypaw into a true medicine cat", "stock catmint before leafbare"], age: 84, map: "camp", x: 8, y: 9 },
  { id: "mistypaw", baseName: "Misty", name: "Mistypaw", role: "medapprentice", gender: "tom", desc: "a tricolor tom, medicine cat apprentice — you", pattern: P("patched", "#efe9df", "#d08a3e", "#43403c", "#7fb2e5"), archetype: "the player", traits: ["curious", "kind"], speech: "warm", goals: ["earn the name Mistyblaze"], age: 6, map: "camp", x: 10, y: 11, knowsSecret: true },
  { id: "nightsong", baseName: "Night", name: "Nightsong", role: "warrior", gender: "tom", desc: "a black-and-white tom, responsible and protective, adoptive father of Silentpaw and Windpaw", pattern: P("tuxedo", "#2e2c31", "#f0efec", "#4a474e", "#d8c74a"), archetype: "quiet guardian", traits: ["responsible", "protective", "self-sacrificing"], speech: "protective", goals: ["protect Silentpaw and Windpaw no matter the cost", "keep the promise made on a cold night"], age: 66, map: "camp", x: 16, y: 15, knowsSecret: true },
  { id: "sparrowclaw", baseName: "Sparrow", name: "Sparrowclaw", role: "warrior", gender: "she-cat", desc: "a brown she-cat, empathetic and kind", pattern: P("solid", "#8a6444", "#6d4c31", "#a8845f", "#b7d46a"), archetype: "clan heart", traits: ["empathetic", "kind", "peacemaker"], speech: "warm", goals: ["make sure no cat grieves alone"], age: 50, map: "camp", x: 22, y: 16 },
  { id: "shadowgaze", baseName: "Shadow", name: "Shadowgaze", role: "warrior", gender: "tom", desc: "a tricolor tom with a cutting tongue — your father", pattern: P("patched", "#54504a", "#b5763a", "#e5dfd4", "#d1a13c"), archetype: "harsh father", traits: ["rude", "proud", "occasionally cruel", "secretly disappointed in himself"], speech: "blunt", goals: ["be respected", "make a warrior out of his son — somehow"], age: 62, map: "camp", x: 25, y: 17 },
  { id: "stonefur", baseName: "Stone", name: "Stonefur", role: "warrior", gender: "tom", desc: "a dark gray tom who naps through anything", pattern: P("solid", "#5d6066", "#4a4d53", "#75787f", "#c9c26a"), archetype: "lazy warrior", traits: ["sleepy", "lazy", "surprisingly calm in crisis"], speech: "sleepy", goals: ["find the sunniest stone in camp", "avoid dawn patrols"], age: 55, map: "camp", x: 18, y: 18 },
  { id: "mistyspark", baseName: "Mistys", name: "Mistyspark", role: "warrior", gender: "tom", desc: "an orange tom, a bonfire of energy and cheer", pattern: P("striped", "#e08a3a", "#b8641f", "#f0b878", "#89ce58"), archetype: "sunbeam", traits: ["energetic", "cheerful", "restless"], speech: "cheerful", goals: ["race the wind itself", "make Stonefur run one whole patrol"], age: 40, map: "camp", x: 14, y: 19 },
  { id: "falconwind", baseName: "Falcon", name: "Falconwind", role: "warrior", gender: "she-cat", desc: "a gray she-cat with blue eyes and half-striped fur, suspicious and observant", pattern: P("striped", "#8d949c", "#6b7178", "#aab1b8", "#6db3e8"), archetype: "watcher", traits: ["suspicious", "observant", "rarely wrong"], speech: "wary", goals: ["figure out what Brightstream hides", "trust no scent she cannot place"], age: 48, map: "camp", x: 29, y: 14 },
  { id: "twiggatherer", baseName: "Twig", name: "Twiggatherer", role: "warrior", gender: "tom", desc: "a brown tom with an inexplicable devotion to twigs", pattern: P("solid", "#7a5a3a", "#5f4529", "#96754e", "#c9a94f"), archetype: "twig scholar", traits: ["obsessed with twigs", "gentle", "odd"], speech: "odd", goals: ["complete the Great Twig Collection", "find the legendary Forked Twig"], age: 45, map: "camp", x: 31, y: 19 },
  { id: "silentpaw", baseName: "Silent", name: "Silentpaw", role: "apprentice", gender: "tom", desc: "a completely black apprentice with intent green eyes, your closest friend", pattern: P("solid", "#232126", "#19181c", "#312f36", "#6fdc7a"), archetype: "devoted shadow", traits: ["quiet", "intense", "devoted", "obsessive beneath the surface"], speech: "quiet", goals: ["stay close to Mistypaw", "prove himself to a father who barely looks at him"], age: 6, map: "camp", x: 12, y: 14 },
  { id: "hollypaw", baseName: "Holly", name: "Hollypaw", role: "apprentice", gender: "she-cat", desc: "a black she-cat apprentice, quick to laugh", pattern: P("solid", "#2b2a30", "#1e1d22", "#3b3a42", "#e0b445"), archetype: "bright spark", traits: ["witty", "brave", "a little reckless"], speech: "cheerful", goals: ["out-hunt every warrior in the Clan"], age: 6, map: "camp", x: 13, y: 16 },
  { id: "windpaw", baseName: "Wind", name: "Windpaw", role: "apprentice", gender: "she-cat", desc: "a white she-cat apprentice, fast and honest", pattern: P("solid", "#eff0f2", "#d8dade", "#ffffff", "#7ec4e8"), archetype: "future star", traits: ["honest", "fast", "born to lead"], speech: "playful", goals: ["run the border faster than any cat", "make Nightsong proud"], age: 6, map: "camp", x: 11, y: 17 },
  { id: "rabbitclaw", baseName: "Rabbit", name: "Rabbitclaw", role: "elder", gender: "tom", desc: "an elder with ragged ears and endless stories", pattern: P("solid", "#a08b70", "#84705a", "#bca88c", "#9a8f4f"), archetype: "storyteller", traits: ["nostalgic", "gruff", "kind underneath"], speech: "gruff", goals: ["tell every story at least twice"], age: 130, map: "camp", x: 33, y: 9 },
  { id: "snowscar", baseName: "Snow", name: "Snowscar", role: "elder", gender: "she-cat", desc: "a white elder with a long scar and a longer memory", pattern: P("solid", "#e9e6e0", "#d2cec6", "#f6f4ef", "#8bb4d6"), archetype: "keeper of memory", traits: ["sharp memory", "blunt", "sees more than she says"], speech: "gruff", goals: ["be warm", "die in her sleep many moons from now, thank you"], age: 126, map: "camp", x: 34, y: 10 },
  { id: "goldenfur", baseName: "Golden", name: "Goldenfur", role: "queen", gender: "she-cat", desc: "a golden queen, mother of three of the Clan's kits", pattern: P("solid", "#d9a842", "#b8862d", "#eec46a", "#8ec468"), archetype: "warm mother", traits: ["nurturing", "tired", "fierce if kits are threatened"], speech: "gentle", goals: ["raise her kits into good warriors"], age: 52, map: "camp", x: 24, y: 21 },
  { id: "wolftail", baseName: "Wolf", name: "Wolftail", role: "queen", gender: "she-cat", desc: "a gray-brown queen — your mother, soft-spoken and steady", pattern: P("striped", "#8c7d6b", "#6e6052", "#a99a86", "#d9c26a"), archetype: "steady mother", traits: ["gentle", "steady", "quietly perceptive"], speech: "gentle", goals: ["see Mistypaw earn his full name"], age: 58, map: "camp", x: 23, y: 22 },
  { id: "mousekit", baseName: "Mouse", name: "Mousekit", role: "kit", gender: "tom", desc: "a small brown kit who squeaks when excited", pattern: P("solid", "#9c7a52", "#7d6141", "#b8946a", "#c9b45f"), archetype: "squeaky kit", traits: ["excitable", "tiny", "fearless"], speech: "playful", goals: ["catch a REAL mouse"], age: 2, map: "camp", x: 25, y: 22 },
  { id: "moonkit", baseName: "Moon", name: "Moonkit", role: "kit", gender: "she-cat", desc: "a silver kit who stares at the sky", pattern: P("solid", "#c3c9d4", "#a8aeb9", "#dde2ea", "#9fd4e8"), archetype: "dreamer kit", traits: ["dreamy", "quiet", "asks strange questions"], speech: "playful", goals: ["touch the moon one day"], age: 2, map: "camp", x: 26, y: 21 },
  { id: "falconkit", baseName: "Falcon", name: "Falconkit", role: "kit", gender: "tom", desc: "a bold gray kit, already picking fights with leaves", pattern: P("striped", "#98a0a8", "#7b838b", "#b4bcc4", "#d8a43c"), archetype: "bold kit", traits: ["bold", "loud", "leader of the kit-pile"], speech: "playful", goals: ["be deputy before becoming a warrior (somehow)"], age: 2, map: "camp", x: 24, y: 23 },
  { id: "firekit", baseName: "Fire", name: "Firekit", role: "kit", gender: "tom", desc: "a ginger kit with singed-looking whiskers and no fear", pattern: P("solid", "#d87e35", "#b5601d", "#eda45f", "#8ecf5a"), archetype: "wild kit", traits: ["wild", "warm-hearted"], speech: "playful", goals: ["jump off the Highrock (don't tell Goldenfur)"], age: 2, map: "camp", x: 26, y: 23 },
  { id: "bluekit", baseName: "Blue", name: "Bluekit", role: "kit", gender: "she-cat", desc: "a blue-gray kit, small and stubborn", pattern: P("solid", "#7f93a8", "#647889", "#9cb0c4", "#e0c052"), archetype: "stubborn kit", traits: ["stubborn", "brave", "hates being called small"], speech: "playful", goals: ["win a play-fight against Falconkit"], age: 2, map: "camp", x: 25, y: 24 },
  { id: "blackstar", baseName: "Black", name: "Blackstar", role: "outsider", gender: "tom", desc: "the huge black leader of NightClan, whose gaze lingers too long on HollyClan's border", pattern: P("solid", "#1c1b1f", "#121115", "#2a2930", "#e8d24a"), archetype: "distant father", traits: ["cold", "calculating", "haunted by one choice"], speech: "cold", goals: ["keep NightClan strong", "watch two young cats from afar"], age: 90, map: "territory", x: 30, y: 3, knowsSecret: true },
];

// ── initial relationship overrides: seed the web of the Clan ────────────────
type RelOverride = [from: string, to: string, stats: Partial<RelStats>];
const REL_OVERRIDES: RelOverride[] = [
  // Silentpaw is deeply attached to Mistypaw
  ["silentpaw", "mistypaw", { affection: 92, friendship: 90, trust: 88, loyalty: 90, jealousy: 20 }],
  ["mistypaw", "silentpaw", { affection: 80, friendship: 85, trust: 80, loyalty: 70 }],
  // family
  ["wolftail", "mistypaw", { affection: 95, friendship: 80, trust: 90, loyalty: 95 }],
  ["mistypaw", "wolftail", { affection: 90, friendship: 75, trust: 92, loyalty: 90 }],
  ["shadowgaze", "mistypaw", { affection: 45, friendship: 35, trust: 50, respect: 30, loyalty: 70 }],
  ["mistypaw", "shadowgaze", { affection: 40, friendship: 30, trust: 40, fear: 25, respect: 40 }],
  ["shadowgaze", "wolftail", { affection: 75, friendship: 60, trust: 70 }],
  ["wolftail", "shadowgaze", { affection: 65, friendship: 55, trust: 60 }],
  // the secret circle
  ["brightstream", "nightsong", { affection: 70, friendship: 85, trust: 95, respect: 90, loyalty: 90 }],
  ["nightsong", "brightstream", { affection: 72, friendship: 85, trust: 95, respect: 88, loyalty: 92 }],
  ["brightstream", "silentpaw", { affection: 90, friendship: 55, trust: 50, loyalty: 80, fear: 15 }],
  ["brightstream", "windpaw", { affection: 90, friendship: 55, trust: 55, loyalty: 80 }],
  ["nightsong", "silentpaw", { affection: 85, friendship: 70, trust: 65, loyalty: 95, fear: 10 }],
  ["nightsong", "windpaw", { affection: 88, friendship: 72, trust: 75, loyalty: 95 }],
  ["silentpaw", "nightsong", { affection: 75, friendship: 60, trust: 80, respect: 70, loyalty: 80 }],
  ["windpaw", "nightsong", { affection: 88, friendship: 75, trust: 90, respect: 85, loyalty: 90 }],
  ["brightstream", "mistypaw", { affection: 70, trust: 85, respect: 60, loyalty: 70 }],
  ["nightsong", "mistypaw", { affection: 72, trust: 88, respect: 65, loyalty: 75 }],
  ["blackstar", "brightstream", { affection: 78, trust: 60, respect: 70, loyalty: 40 }],
  ["blackstar", "silentpaw", { affection: 70, trust: 30, respect: 40 }],
  ["blackstar", "windpaw", { affection: 70, trust: 30, respect: 45 }],
  ["blackstar", "mistypaw", { trust: 55, respect: 50 }],
  // watcher
  ["falconwind", "brightstream", { suspicion: 45, trust: 35, respect: 60 }],
  ["falconwind", "silentpaw", { suspicion: 35, trust: 35 }],
  ["falconwind", "nightsong", { suspicion: 30, respect: 70 }],
  // friendships
  ["hollypaw", "mistypaw", { affection: 70, friendship: 75, trust: 70 }],
  ["mistypaw", "hollypaw", { affection: 65, friendship: 72, trust: 68 }],
  ["windpaw", "mistypaw", { affection: 68, friendship: 72, trust: 70 }],
  ["mistypaw", "windpaw", { affection: 64, friendship: 70, trust: 70 }],
  ["hollypaw", "windpaw", { affection: 75, friendship: 82, trust: 78 }],
  ["windpaw", "hollypaw", { affection: 75, friendship: 82, trust: 78 }],
  ["silentpaw", "hollypaw", { friendship: 50, jealousy: 25, trust: 45 }],
  ["silentpaw", "windpaw", { affection: 60, friendship: 65, trust: 60 }],
  ["mistyspark", "stonefur", { friendship: 70, affection: 60 }],
  ["stonefur", "mistyspark", { friendship: 65, affection: 55 }],
  ["sparrowclaw", "mistypaw", { affection: 70, friendship: 65, trust: 72 }],
  ["juniperfang", "mistypaw", { affection: 75, trust: 80, respect: 60, loyalty: 85 }],
  ["mistypaw", "juniperfang", { affection: 72, trust: 85, respect: 88, loyalty: 85 }],
  ["maplestar", "brightstream", { trust: 88, respect: 85, friendship: 75 }],
  ["goldenfur", "wolftail", { friendship: 80, affection: 75, trust: 80 }],
  ["wolftail", "goldenfur", { friendship: 80, affection: 75, trust: 80 }],
  ["rabbitclaw", "snowscar", { friendship: 85, affection: 80, trust: 85 }],
  ["snowscar", "rabbitclaw", { friendship: 85, affection: 78, trust: 85 }],
  ["shadowgaze", "stonefur", { respect: 20, friendship: 25 }],
  ["falconwind", "shadowgaze", { suspicion: 25, respect: 40, friendship: 30 }],
];

export function buildInitialCats(): Record<string, Cat> {
  const cats: Record<string, Cat> = {};
  const r = mulberry(20260101);
  for (const s of SEEDS) {
    cats[s.id] = {
      id: s.id,
      baseName: s.baseName,
      name: s.name,
      role: s.role,
      gender: s.gender,
      desc: s.desc,
      pattern: s.pattern,
      archetype: s.archetype,
      traits: s.traits,
      speech: s.speech,
      goals: [...s.goals],
      mood: "content",
      health: 100,
      sick: null,
      lives: s.lives,
      alive: true,
      ageMoons: s.age,
      rel: {},
      memories: [],
      map: s.map,
      x: s.x,
      y: s.y,
      tx: s.x,
      ty: s.y,
      activity: "resting",
      knowsSecret: !!s.knowsSecret,
      dir: 0,
    };
  }
  // fill relationship web
  const ids = Object.keys(cats);
  for (const a of ids) {
    for (const b of ids) {
      if (a === b) continue;
      const base = defaultRel();
      // slight random personality-driven variation
      base.affection += Math.floor(r() * 16 - 8);
      base.friendship += Math.floor(r() * 16 - 8);
      base.trust += Math.floor(r() * 12 - 6);
      base.respect += Math.floor(r() * 12 - 6);
      cats[a].rel[b] = base;
    }
  }
  for (const [from, to, stats] of REL_OVERRIDES) {
    cats[from].rel[to] = { ...cats[from].rel[to], ...stats };
  }
  // ── starting mentorships ──
  // Mistypaw trains under Juniperfang (medicine path); the warrior apprentices
  // were each assigned a mentor by MapleStar before the game begins.
  const setMentor = (app: string, mentor: string, progress: number) => {
    cats[app].mentor = mentor;
    cats[app].trainingProgress = progress;
    cats[app].lessons = [];
    cats[app].rel[mentor] = { ...cats[app].rel[mentor], respect: Math.max(cats[app].rel[mentor].respect, 60), trust: Math.max(cats[app].rel[mentor].trust, 55) };
    cats[mentor].rel[app] = { ...cats[mentor].rel[app], affection: Math.max(cats[mentor].rel[app].affection, 50) };
  };
  setMentor("mistypaw", "juniperfang", 55);
  setMentor("silentpaw", "nightsong", 58); // Nightsong asked for him — to keep him close
  setMentor("hollypaw", "mistyspark", 55);
  setMentor("windpaw", "sparrowclaw", 60);
  // veteran warriors who have trained apprentices before
  cats.maplestar.apprenticesTrained = 2;
  cats.brightstream.apprenticesTrained = 1;
  cats.nightsong.apprenticesTrained = 1;
  cats.juniperfang.apprenticesTrained = 1;
  cats.shadowgaze.apprenticesTrained = 1;
  cats.falconwind.apprenticesTrained = 1;
  cats.sparrowclaw.apprenticesTrained = 1;
  // starting memories
  const mem = (id: string, text: string, tone: "good" | "bad" | "neutral" | "secret", weight: number, about?: string[]) =>
    cats[id].memories.push({ moon: 0, text, tone, weight, about });
  mem("mistypaw", "As a young kit, half-asleep, you saw Brightstream slip into camp on a freezing night carrying two newborn kits that smelled of pine and another Clan. Nightsong met her at the entrance. He saw you watching — and asked you, gently, to never speak of it.", "secret", 10, ["brightstream", "nightsong", "silentpaw", "windpaw"]);
  mem("mistypaw", "Juniperfang chose you as her apprentice when you kept sneaking into the herb store to sort leaves by smell.", "good", 7, ["juniperfang"]);
  mem("nightsong", "On the coldest night of that leafbare, Brightstream came back carrying two kits. I knew whose they were the moment I scented pine. I made my choice before dawn: they would be mine.", "secret", 10, ["brightstream", "silentpaw", "windpaw", "blackstar"]);
  mem("brightstream", "I named him Silentkit because he didn't cry once on the long walk home. Windkit squalled enough for both. StarClan forgive me for what I hid.", "secret", 10, ["silentpaw", "windpaw", "blackstar"]);
  mem("blackstar", "I watched her carry them across the border and I did not follow. A leader cannot. A father should have.", "secret", 10, ["brightstream", "silentpaw", "windpaw"]);
  mem("silentpaw", "Mistypaw shared his first fresh-kill with me when we were kits. Nobody else waited for me. He did.", "good", 9, ["mistypaw"]);
  mem("silentpaw", "Nightsong is my father, but sometimes he looks at me like he's guarding something instead of raising it.", "neutral", 6, ["nightsong"]);
  mem("windpaw", "Hollypaw and I raced to the river and I won. I always win. Someday I'll race the whole forest.", "good", 5, ["hollypaw"]);
  mem("shadowgaze", "My son chose herbs over claws. I said something cruel the day he did. I remember his face. I have never taken it back.", "bad", 8, ["mistypaw"]);
  mem("wolftail", "Mistypaw was born during a mist that didn't lift for three days. Shadowgaze wanted a warrior name. I wanted him.", "good", 8, ["mistypaw", "shadowgaze"]);
  mem("falconwind", "Moons ago Brightstream vanished on 'long patrols' for half a season. No prey brought back. No explanation. I don't forget gaps like that.", "secret", 8, ["brightstream"]);
  mem("juniperfang", "The greencough leafbare took three elders because we ran short of catmint. Never again, if I can help it.", "bad", 8),
  mem("rabbitclaw", "I once saw a fox chase Twiggatherer for a fox-length before he turned around to pick up a twig he'd dropped. Bravest fool I ever saw.", "good", 6, ["twiggatherer"]);
  mem("maplestar", "StarClan gave me nine lives and I have spent six. Three remain. Each one taught me the same lesson: secrets cost more than truth.", "neutral", 7);
  return cats;
}

export function buildInitialState(): GameState {
  const cats = buildInitialCats();
  return {
    version: 3,
    moon: 1,
    timeOfDay: "dawn",
    timeTicks: 0,
    weather: "clear",
    cats,
    herbs: { cobweb: 2, marigold: 1, poppy: 2, catmint: 0, juniper: 1, borage: 0, horsetail: 1, feverfew: 0 },
    herbNodes: JSON.parse(JSON.stringify(HERB_NODES)),
    suspicion: 0,
    flags: {},
    pendingEvents: ["intro"],
    log: [],
    history: [],
    actionsThisMoon: {},
    energy: 100,
    ending: null,
    playerMap: "camp",
    px: 10,
    py: 11,
    clues: [],
    dreamsSeen: [],
  };
}

export const PLAYER_ID = "mistypaw";
