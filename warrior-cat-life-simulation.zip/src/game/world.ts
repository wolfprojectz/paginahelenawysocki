import { MapId } from "./types";
import { mulberry } from "./data";

// Tile ids
export const T = {
  GRASS: 0,
  TALL: 1,
  TREE: 2,
  WATER: 3,
  PATH: 4,
  STONE: 5,
  WALL: 6, // bramble den wall
  FLOOR: 7, // den floor
  FLOWER: 8,
  STEP: 9, // stepping stone in water
  BORDER: 10, // scent-line marker
  DARKTREE: 11, // NightClan pines
  DIRT: 12,
  GATE: 13, // camp <-> territory transition
  ROCK: 14, // highrock
} as const;

export interface GameMap {
  id: MapId;
  w: number;
  h: number;
  tiles: number[]; // w*h
  labels: { x: number; y: number; text: string }[];
  gates: { x: number; y: number; to: MapId; dx: number; dy: number }[];
}

function fillRect(m: number[], w: number, x0: number, y0: number, x1: number, y1: number, t: number) {
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) m[y * w + x] = t;
}
function ring(m: number[], w: number, x0: number, y0: number, x1: number, y1: number, t: number) {
  for (let x = x0; x <= x1; x++) {
    m[y0 * w + x] = t;
    m[y1 * w + x] = t;
  }
  for (let y = y0; y <= y1; y++) {
    m[y * w + x0] = t;
    m[y * w + x1] = t;
  }
}

// Den: bramble ring with floor inside and a doorway
function den(m: number[], w: number, x0: number, y0: number, x1: number, y1: number, doorX: number, doorY: number) {
  fillRect(m, w, x0, y0, x1, y1, T.FLOOR);
  ring(m, w, x0, y0, x1, y1, T.WALL);
  m[doorY * w + doorX] = T.FLOOR;
}

export function buildCamp(): GameMap {
  const w = 38, h = 28;
  const tiles = new Array(w * h).fill(T.GRASS);
  const r = mulberry(777);
  // outer bramble wall
  ring(tiles, w, 0, 0, w - 1, h - 1, T.WALL);
  ring(tiles, w, 1, 1, w - 2, h - 2, T.WALL);
  // scatter texture
  for (let i = 0; i < w * h; i++) {
    if (tiles[i] === T.GRASS) {
      const v = r();
      if (v < 0.06) tiles[i] = T.TALL;
      else if (v < 0.08) tiles[i] = T.FLOWER;
    }
  }
  // central clearing (dirt)
  fillRect(tiles, w, 15, 9, 24, 15, T.DIRT);
  // Highrock + leader's den (top middle-right)
  fillRect(tiles, w, 25, 4, 28, 6, T.ROCK);
  den(tiles, w, 24, 3, 30, 8, 26, 8);
  // medicine den + herb store (left)
  den(tiles, w, 4, 6, 12, 13, 12, 10);
  fillRect(tiles, w, 5, 7, 7, 8, T.STONE); // herb storage nook
  // warriors' den (mid-left low)
  den(tiles, w, 14, 13, 21, 19, 17, 13);
  // apprentices' den (left low)
  den(tiles, w, 9, 15, 13, 20, 13, 17);
  // nursery (right low)
  den(tiles, w, 22, 19, 28, 25, 24, 19);
  // elders' den (top right)
  den(tiles, w, 31, 6, 36, 12, 31, 9);
  // fresh-kill pile spot
  fillRect(tiles, w, 19, 11, 20, 12, T.DIRT);
  // paths
  for (let y = 15; y <= 26; y++) tiles[y * w + 19] = tiles[y * w + 19] === T.GRASS || tiles[y * w + 19] === T.TALL || tiles[y * w + 19] === T.FLOWER ? T.PATH : tiles[y * w + 19];
  // entrance at bottom
  tiles[(h - 1) * w + 19] = T.GATE;
  tiles[(h - 2) * w + 19] = T.PATH;
  return {
    id: "camp",
    w,
    h,
    tiles,
    labels: [
      { x: 27, y: 3, text: "Leader's Den" },
      { x: 8, y: 6, text: "Medicine Den" },
      { x: 6, y: 8, text: "Herb Store" },
      { x: 17, y: 13, text: "Warriors' Den" },
      { x: 11, y: 15, text: "Apprentices' Den" },
      { x: 25, y: 19, text: "Nursery" },
      { x: 33, y: 6, text: "Elders' Den" },
      { x: 19, y: 11, text: "Fresh-kill" },
      { x: 19, y: 26, text: "Camp Entrance" },
      { x: 19, y: 12, text: "" },
    ],
    gates: [{ x: 19, y: h - 1, to: "territory", dx: 31, dy: 40 }],
  };
}

export function buildTerritory(): GameMap {
  const w = 60, h = 44;
  const tiles = new Array(w * h).fill(T.GRASS);
  const r = mulberry(4242);
  // forest scatter
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const v = r();
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) {
        tiles[i] = T.TREE;
        continue;
      }
      if (v < 0.14) tiles[i] = T.TREE;
      else if (v < 0.24) tiles[i] = T.TALL;
      else if (v < 0.27) tiles[i] = T.FLOWER;
      else if (v < 0.29) tiles[i] = T.STONE;
    }
  }
  // river across, flows diagonally-ish
  for (let x = 1; x < w - 1; x++) {
    const yC = Math.round(18 + Math.sin(x * 0.18) * 3);
    for (let dy = -1; dy <= 1; dy++) fillRect(tiles, w, x, yC + dy, x, yC + dy, T.WATER);
  }
  // stepping stones at two crossings
  for (const sx of [14, 36]) {
    const yC = Math.round(18 + Math.sin(sx * 0.18) * 3);
    for (let dy = -1; dy <= 1; dy++) tiles[(yC + dy) * w + sx] = T.STEP;
  }
  // NightClan pines (north strip) + border markers
  for (let y = 1; y <= 5; y++)
    for (let x = 1; x < w - 1; x++) {
      if (r() < 0.6) tiles[y * w + x] = T.DARKTREE;
    }
  for (let x = 1; x < w - 1; x += 2) tiles[6 * w + x] = T.BORDER;
  // training hollow (sandy)
  fillRect(tiles, w, 44, 36, 52, 41, T.DIRT);
  ring(tiles, w, 43, 35, 53, 42, T.TALL);
  fillRect(tiles, w, 47, 35, 49, 35, T.DIRT);
  // hunting grounds clearing
  fillRect(tiles, w, 8, 24, 18, 30, T.GRASS);
  // path from camp gate north
  for (let y = 24; y <= 42; y++) tiles[y * w + 31] = T.PATH;
  // clear around herb spots & gate
  const clears: [number, number][] = [
    [12, 30], [44, 12], [52, 34], [8, 10], [30, 8], [20, 16], [38, 30], [26, 24], [48, 22], [16, 36], [31, 41],
  ];
  for (const [cx, cy] of clears)
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++) {
        const x = cx + dx, y = cy + dy;
        if (x > 0 && y > 0 && x < w - 1 && y < h - 1) {
          const t = tiles[y * w + x];
          if (t === T.TREE || t === T.DARKTREE || t === T.WATER) tiles[y * w + x] = T.GRASS;
        }
      }
  // camp gate at bottom
  tiles[41 * w + 31] = T.PATH;
  tiles[42 * w + 31] = T.GATE;
  return {
    id: "territory",
    w,
    h,
    tiles,
    labels: [
      { x: 30, y: 2, text: "NightClan Territory" },
      { x: 30, y: 6, text: "Border" },
      { x: 13, y: 27, text: "Hunting Grounds" },
      { x: 48, y: 38, text: "Training Hollow" },
      { x: 30, y: 18, text: "The River" },
      { x: 31, y: 42, text: "To Camp" },
    ],
    gates: [{ x: 31, y: 42, to: "camp", dx: 19, dy: 25 }],
  };
}

export const MAPS: Record<MapId, GameMap> = {
  camp: buildCamp(),
  territory: buildTerritory(),
};

export function tileAt(map: GameMap, x: number, y: number): number {
  if (x < 0 || y < 0 || x >= map.w || y >= map.h) return T.WALL;
  return map.tiles[y * map.w + x];
}

export function isSolid(map: GameMap, x: number, y: number): boolean {
  const t = tileAt(map, x, y);
  return t === T.TREE || t === T.WALL || t === T.WATER || t === T.DARKTREE || t === T.ROCK;
}

// Named locations for routines
export const SPOTS: Record<string, { map: MapId; x: number; y: number }> = {
  clearing: { map: "camp", x: 19, y: 12 },
  freshkill: { map: "camp", x: 19, y: 11 },
  leaderden: { map: "camp", x: 27, y: 5 },
  medden: { map: "camp", x: 8, y: 10 },
  herbstore: { map: "camp", x: 6, y: 8 },
  warriorsden: { map: "camp", x: 17, y: 16 },
  apprenticeden: { map: "camp", x: 11, y: 17 },
  nursery: { map: "camp", x: 25, y: 22 },
  eldersden: { map: "camp", x: 33, y: 9 },
  entrance: { map: "camp", x: 19, y: 25 },
  hunting: { map: "territory", x: 13, y: 27 },
  training: { map: "territory", x: 48, y: 38 },
  river: { map: "territory", x: 36, y: 15 },
  border: { map: "territory", x: 30, y: 7 },
  gathering: { map: "territory", x: 48, y: 22 },
};
