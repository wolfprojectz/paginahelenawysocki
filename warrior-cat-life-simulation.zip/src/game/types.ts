// ── Core type definitions for the HollyClan simulation ──────────────────────

export type MapId = "camp" | "territory";
export type Season = "Newleaf" | "Greenleaf" | "Leaf-fall" | "Leafbare";
export type Weather = "clear" | "rain" | "storm" | "wind" | "fog" | "snow";
export type TimeOfDay = "dawn" | "day" | "dusk" | "night";

export type Role =
  | "leader"
  | "deputy"
  | "medicine"
  | "medapprentice"
  | "warrior"
  | "apprentice"
  | "elder"
  | "queen"
  | "kit"
  | "outsider";

export type SpeechStyle =
  | "stern"       // MapleStar
  | "warm"        // Brightstream, Sparrowclaw
  | "dry"         // Juniperfang
  | "protective"  // Nightsong
  | "blunt"       // Shadowgaze
  | "sleepy"      // Stonefur
  | "cheerful"    // Mistyspark, Hollypaw
  | "wary"        // Falconwind
  | "odd"         // Twiggatherer
  | "quiet"       // Silentpaw (obsessive undertone)
  | "gentle"      // Wolftail, Goldenfur
  | "gruff"       // Rabbitclaw, Snowscar
  | "playful"     // kits, Windpaw
  | "cold";       // Blackstar

export interface RelStats {
  affection: number;
  friendship: number;
  trust: number;
  respect: number;
  fear: number;
  jealousy: number;
  suspicion: number;
  loyalty: number;
}

export type Tone = "good" | "bad" | "neutral" | "secret" | "grief";

export interface Memory {
  moon: number;
  text: string;
  tone: Tone;
  weight: number; // 1-10, higher = recalled more often
  about?: string[]; // cat ids involved
}

export interface Sickness {
  name: string;
  herb: string; // herb id needed
  moonsLeft: number;
  severity: number; // 1-3
}

export interface CatPattern {
  style: "solid" | "patched" | "spotted" | "striped" | "tuxedo";
  base: string;
  patch1: string;
  patch2: string;
  eyes: string;
}

export interface Cat {
  id: string;
  baseName: string; // "Misty"
  name: string; // current full name e.g. "Mistypaw"
  role: Role;
  gender: "tom" | "she-cat";
  desc: string;
  pattern: CatPattern;
  archetype: string;
  traits: string[];
  speech: SpeechStyle;
  goals: string[];
  mood: string;
  health: number; // 0-100
  sick: Sickness | null;
  lives?: number; // leaders only — remaining StarClan lives
  mentor?: string | null; // apprentices: id of their mentor
  trainingProgress?: number; // apprentices: 0-100
  lessons?: string[]; // notable lessons learned during training
  apprenticesTrained?: number; // count of apprentices this cat has fully trained
  alive: boolean;
  deathMoon?: number;
  deathCause?: string;
  ageMoons: number;
  rel: Record<string, RelStats>;
  memories: Memory[];
  map: MapId;
  x: number;
  y: number;
  tx: number; // walk target
  ty: number;
  activity: string;
  knowsSecret: boolean;
  // runtime-only smooth movement (persisted harmlessly)
  fx?: number;
  fy?: number;
  dir?: number; // 0 down 1 left 2 right 3 up
}

export interface HerbDef {
  id: string;
  name: string;
  use: string;
  color: string;
  seasons: Season[]; // when it can be gathered
}

export interface HerbNode {
  id: string;
  map: MapId;
  x: number;
  y: number;
  herb: string;
  qty: number;
  max: number;
}

export interface StoryChoice {
  label: string;
}

export interface StoryEventInstance {
  id: string; // definition id
  title: string;
  speaker?: string; // cat id portrait
  text: string;
  choices: StoryChoice[];
}

export interface EndingInfo {
  id: string;
  title: string;
  text: string;
}

export interface MoonRecord {
  moon: number;
  events: string[];
}

export interface GameState {
  version: number;
  moon: number;
  timeOfDay: TimeOfDay;
  timeTicks: number; // actions advance time
  weather: Weather;
  cats: Record<string, Cat>;
  herbs: Record<string, number>;
  herbNodes: HerbNode[];
  suspicion: number; // 0-100 toward Silentshadow
  flags: Record<string, boolean | number>;
  pendingEvents: string[]; // story event ids waiting to be shown
  log: string[]; // events of current moon
  history: MoonRecord[];
  actionsThisMoon: Record<string, boolean>;
  energy: number;
  ending: EndingInfo | null;
  playerMap: MapId;
  px: number;
  py: number;
  clues: string[];
  dreamsSeen: string[];
}

export interface DialogueContext {
  state: GameState;
  speaker: Cat;
  listener: Cat; // usually the player
  seed: number;
}
