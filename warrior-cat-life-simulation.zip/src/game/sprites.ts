import { Cat, Season, Weather } from "./types";
import { T } from "./world";

// tiny deterministic hash for pixel-noise
export function h2(x: number, y: number): number {
  let n = x * 374761393 + y * 668265263;
  n = (n ^ (n >> 13)) * 1274126177;
  return ((n ^ (n >> 16)) >>> 0) / 4294967296;
}

// ── TILES ───────────────────────────────────────────────────────────────────
interface Palette {
  grass: string[];
  tall: string;
  dirt: string[];
  leaf: string[];
  trunk: string;
  water: string[];
  flower: string[];
}
const PALETTES: Record<Season, Palette> = {
  Newleaf: { grass: ["#6aa84f", "#5f9c46", "#74b258"], tall: "#4e8a3c", dirt: ["#a58a5f", "#997e54"], leaf: ["#4c8a3e", "#5c9c4a", "#3f7a33"], trunk: "#6b4a2c", water: ["#3f6fb0", "#4a7cc0", "#5a8cd0"], flower: ["#e8c8e0", "#f0e6a0"] },
  Greenleaf: { grass: ["#5d9c42", "#529238", "#68aa4c"], tall: "#417a2e", dirt: ["#a08655", "#94794a"], leaf: ["#3d7c30", "#4c8c3c", "#336a28"], trunk: "#66452a", water: ["#3a6aaa", "#4678ba", "#5688ca"], flower: ["#e89a4a", "#e0607a"] },
  "Leaf-fall": { grass: ["#9c9448", "#8f873f", "#a8a054"], tall: "#7c7434", dirt: ["#9a7e50", "#8e7245"], leaf: ["#b5742c", "#c08838", "#985c22"], trunk: "#5f4126", water: ["#4a6a94", "#5678a4", "#6284b0"], flower: ["#c88a3a", "#b0703a"] },
  Leafbare: { grass: ["#cdd4da", "#c2cbd2", "#d8dee4"], tall: "#adb8c0", dirt: ["#a8a29a", "#9a948c"], leaf: ["#8a959e", "#79858e", "#67737c"], trunk: "#4f3c28", water: ["#7a9ab8", "#88a8c4", "#98b4cc"], flower: ["#c8ced4", "#d4dae0"] },
};

export function drawTile(ctx: CanvasRenderingContext2D, tile: number, tx: number, ty: number, px: number, py: number, sz: number, season: Season, time: number) {
  const P = PALETTES[season];
  const q = sz / 4;
  const noise = h2(tx, ty);
  const g = P.grass[Math.floor(noise * 3)];
  // base
  switch (tile) {
    case T.GRASS:
    case T.FLOWER:
    case T.TALL:
    case T.TREE:
    case T.DARKTREE:
    case T.BORDER:
      ctx.fillStyle = g;
      break;
    case T.PATH:
    case T.DIRT:
    case T.GATE:
      ctx.fillStyle = P.dirt[Math.floor(noise * 2)];
      break;
    case T.WATER:
    case T.STEP:
      ctx.fillStyle = P.water[Math.floor((noise * 3 + time * 2) % 3)];
      break;
    case T.STONE:
    case T.ROCK:
      ctx.fillStyle = noise > 0.5 ? "#8f8f96" : "#84848c";
      break;
    case T.WALL:
      ctx.fillStyle = "#4a3826";
      break;
    case T.FLOOR:
      ctx.fillStyle = "#b09468";
      break;
    default:
      ctx.fillStyle = g;
  }
  ctx.fillRect(px, py, sz, sz);
  // pixel details
  if (tile === T.GRASS && noise < 0.5) {
    ctx.fillStyle = P.grass[(Math.floor(noise * 10) + 1) % 3];
    ctx.fillRect(px + Math.floor(noise * 3) * q, py + Math.floor(noise * 7 % 3) * q, q, q);
  }
  if (tile === T.TALL) {
    ctx.fillStyle = P.tall;
    for (let i = 0; i < 3; i++) {
      const gx = px + q * (i + 0.5) + (h2(tx + i, ty) * q) / 2;
      ctx.fillRect(gx, py + q, q / 2, sz - q);
    }
  }
  if (tile === T.FLOWER) {
    ctx.fillStyle = P.flower[noise > 0.5 ? 0 : 1];
    ctx.fillRect(px + q, py + q, q, q);
    ctx.fillRect(px + 2.5 * q, py + 2.2 * q, q * 0.8, q * 0.8);
  }
  if (tile === T.WATER || tile === T.STEP) {
    // ripple
    const ph = Math.floor((time * 3 + noise * 4) % 4);
    ctx.fillStyle = "rgba(255,255,255,0.25)";
    ctx.fillRect(px + ph * q, py + Math.floor(noise * 4) * q, q, q / 2);
    if (tile === T.STEP) {
      ctx.fillStyle = "#9a9aa2";
      ctx.fillRect(px + q * 0.7, py + q * 0.7, sz - 1.4 * q, sz - 1.4 * q);
      ctx.fillStyle = "#b4b4bc";
      ctx.fillRect(px + q, py + q, sz - 2.4 * q, q);
    }
  }
  if (tile === T.TREE || tile === T.DARKTREE) {
    const dark = tile === T.DARKTREE;
    // trunk
    ctx.fillStyle = dark ? "#2e2620" : P.trunk;
    ctx.fillRect(px + 1.5 * q, py + 2.4 * q, q, 1.6 * q);
    // canopy
    const leaves = dark ? ["#20301f", "#28402a", "#1a281a"] : P.leaf;
    ctx.fillStyle = leaves[Math.floor(noise * 3)];
    ctx.fillRect(px + q * 0.3, py, sz - 0.6 * q, 2.6 * q);
    ctx.fillStyle = leaves[(Math.floor(noise * 3) + 1) % 3];
    ctx.fillRect(px + q * 0.9, py - q * 0.6, sz - 1.8 * q, q);
    ctx.fillRect(px + q * 0.6, py + q * 0.6, q, q);
    if (season === "Leafbare" && !dark) {
      ctx.fillStyle = "#e8edf2";
      ctx.fillRect(px + q * 0.3, py, sz - 0.6 * q, q * 0.6);
    }
  }
  if (tile === T.WALL) {
    ctx.fillStyle = noise > 0.5 ? "#5a4630" : "#3c2c1c";
    ctx.fillRect(px + q * (noise > 0.5 ? 0.5 : 2), py + q, q * 1.4, q);
    ctx.fillStyle = "#6a5238";
    ctx.fillRect(px + q * 2.2, py + q * 2.4, q, q * 0.8);
    ctx.fillStyle = "#2e2214";
    ctx.fillRect(px + q * 1, py + q * 2.8, q * 0.8, q * 0.8);
  }
  if (tile === T.FLOOR && noise < 0.3) {
    ctx.fillStyle = "#a08557";
    ctx.fillRect(px + q, py + 2 * q, 2 * q, q);
  }
  if (tile === T.ROCK) {
    ctx.fillStyle = "#a0a0a8";
    ctx.fillRect(px + q * 0.5, py + q * 0.5, sz - q, q);
    ctx.fillStyle = "#6e6e76";
    ctx.fillRect(px + q, py + 2.5 * q, sz - 2 * q, q);
  }
  if (tile === T.BORDER) {
    ctx.fillStyle = "#c8b060";
    ctx.fillRect(px + 1.4 * q, py + q, q * 1.2, 2.4 * q);
    ctx.fillStyle = "#7c6430";
    ctx.fillRect(px + 1.4 * q, py + 2.6 * q, q * 1.2, q * 0.6);
  }
  if (tile === T.GATE) {
    ctx.fillStyle = "#4a3826";
    ctx.fillRect(px, py, q, sz);
    ctx.fillRect(px + sz - q, py, q, sz);
    ctx.fillStyle = "#d8c890";
    ctx.fillRect(px + 1.5 * q, py + 1.5 * q, q, q);
  }
}

// ── CAT SPRITE ──────────────────────────────────────────────────────────────
// 16x12 grid, side view facing right; flip for left.
// legend: . empty, B base, H head-region base, E eye, N nose, T tail, L legs, O outline shading
const CAT_FRAME_A = [
  "...........DD.DD",
  "...........DBBBD",
  "T..........BBBBB",
  "TT.........BEBEB",
  ".TT........BBBBB",
  "..T..BBBBBBBBBN.",
  "..BBBBBBBBBBBB..",
  "..BBBBBBBBBBB...",
  "..BBBBBBBBBB....",
  "..LL..LL..LL....",
];
const CAT_FRAME_B = [
  "...........DD.DD",
  "...........DBBBD",
  "T..........BBBBB",
  ".T.........BEBEB",
  ".TT........BBBBB",
  "..T..BBBBBBBBBN.",
  "..BBBBBBBBBBBB..",
  "..BBBBBBBBBBB...",
  "..BBBBBBBBBB....",
  ".LL..LL....LL...",
];
const SLEEP_FRAME = [
  "................",
  "................",
  "................",
  "......DD.DD.....",
  "..BBBBDBBBD.....",
  ".BBBBBBBBBB.....",
  ".BBBBBBBBBBB....",
  ".BBBBBBBBBB.....",
  "..TTBBBBBB......",
  "................",
];

function shade(hex: string, f: number): string {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.max(0, Math.floor(((n >> 16) & 255) * f)));
  const g = Math.min(255, Math.max(0, Math.floor(((n >> 8) & 255) * f)));
  const b = Math.min(255, Math.max(0, Math.floor((n & 255) * f)));
  return `rgb(${r},${g},${b})`;
}

// which color for a body pixel, based on pattern
function patternColor(cat: Cat, gx: number, gy: number): string {
  const p = cat.pattern;
  const seed = cat.id.length * 31 + cat.id.charCodeAt(0);
  const n = h2(gx + seed, gy + seed * 7);
  switch (p.style) {
    case "solid":
      return n < 0.12 ? p.patch2 : n > 0.88 ? p.patch1 : p.base;
    case "spotted":
      return n < 0.22 ? p.patch1 : n > 0.9 ? p.patch2 : p.base;
    case "striped":
      return gx % 3 === (seed % 3) ? p.patch1 : n > 0.85 ? p.patch2 : p.base;
    case "tuxedo":
      return gy >= 6 || (gx >= 12 && gy === 5) ? p.patch1 : p.base;
    case "patched": {
      // large blobs of patch1 / patch2 (tricolor look)
      const blob = h2(Math.floor((gx + seed) / 3), Math.floor((gy + seed) / 2));
      if (blob < 0.33) return p.patch1;
      if (blob < 0.55) return p.patch2;
      return p.base;
    }
  }
}

export function drawCat(
  ctx: CanvasRenderingContext2D,
  cat: Cat,
  px: number,
  py: number,
  sz: number, // tile size; cat drawn ~ 1 tile wide
  frame: number,
  moving: boolean,
  sleeping: boolean,
  facingLeft: boolean,
  scale = 1
) {
  const grid = sleeping ? SLEEP_FRAME : moving && frame % 2 === 1 ? CAT_FRAME_B : CAT_FRAME_A;
  const kit = cat.role === "kit";
  const cw = (sz / 16) * (kit ? 0.7 : 1) * scale;
  const ox = px + (kit ? sz * 0.15 : 0);
  const oy = py + sz - 10 * cw - 1;
  ctx.save();
  if (facingLeft) {
    ctx.translate(ox + 16 * cw, 0);
    ctx.scale(-1, 1);
  } else {
    ctx.translate(ox, 0);
  }
  for (let gy = 0; gy < grid.length; gy++) {
    const row = grid[gy];
    for (let gx = 0; gx < row.length; gx++) {
      const ch = row[gx];
      if (ch === ".") continue;
      let color: string;
      if (ch === "E") color = sleeping ? shade(cat.pattern.base, 0.6) : cat.pattern.eyes;
      else if (ch === "N") color = "#d88";
      else if (ch === "D") color = shade(cat.pattern.base, 0.75);
      else if (ch === "T") color = shade(patternColor(cat, gx, gy), 0.9);
      else if (ch === "L") color = shade(patternColor(cat, gx, gy), 0.85);
      else color = patternColor(cat, gx, gy);
      ctx.fillStyle = color;
      ctx.fillRect(Math.floor(gx * cw), Math.floor(oy + gy * cw), Math.ceil(cw), Math.ceil(cw));
    }
  }
  ctx.restore();
}

// ── PORTRAIT (dialogue box face) ────────────────────────────────────────────
const FACE = [
  ".DD..........DD.",
  ".DBD........DBD.",
  ".DBBD......DBBD.",
  ".DBBBBBBBBBBBBD.",
  ".DBBBBBBBBBBBBD.",
  ".DBBBBBBBBBBBBD.",
  ".DBEEBBBBBBEEBD.",
  ".DBEEBBBBBBEEBD.",
  ".DBBBBBBBBBBBBD.",
  ".DBBBBBNNBBBBBD.",
  ".DBBBBNBBNBBBBD.",
  "..DBBBBBBBBBBD..",
  "...DBBBBBBBBD...",
  ".....DDDDDD.....",
];
export function drawPortrait(ctx: CanvasRenderingContext2D, cat: Cat, size: number) {
  const cw = size / 16;
  ctx.clearRect(0, 0, size, size);
  for (let gy = 0; gy < FACE.length; gy++) {
    for (let gx = 0; gx < 16; gx++) {
      const ch = FACE[gy][gx];
      if (ch === ".") continue;
      let color: string;
      if (ch === "E") color = gy === 6 ? cat.pattern.eyes : shade(cat.pattern.eyes, 0.6);
      else if (ch === "N") color = "#c07878";
      else if (ch === "D") color = shade(cat.pattern.base, 0.6);
      else color = patternColor(cat, gx + 3, gy + 1);
      ctx.fillStyle = color;
      ctx.fillRect(Math.floor(gx * cw), Math.floor(gy * cw + cw), Math.ceil(cw), Math.ceil(cw));
    }
  }
  // whiskers
  ctx.fillStyle = "rgba(255,255,255,0.7)";
  ctx.fillRect(0, 10.5 * cw, 2 * cw, cw / 2);
  ctx.fillRect(14 * cw, 10.5 * cw, 2 * cw, cw / 2);
}

// ── emote bubbles ───────────────────────────────────────────────────────────
export function drawEmote(ctx: CanvasRenderingContext2D, kind: string, px: number, py: number, sz: number) {
  const q = sz / 8;
  ctx.fillStyle = "#fffef0";
  ctx.fillRect(px + q, py - 6 * q, 6 * q, 5 * q);
  ctx.fillStyle = "#333";
  ctx.fillRect(px + 3 * q, py - q, q, q);
  if (kind === "talk") {
    ctx.fillStyle = "#333";
    ctx.fillRect(px + 2 * q, py - 4 * q, q, q);
    ctx.fillRect(px + 3.7 * q, py - 4 * q, q, q);
    ctx.fillRect(px + 5.4 * q, py - 4 * q, q, q);
  } else if (kind === "heart") {
    ctx.fillStyle = "#d84a6a";
    ctx.fillRect(px + 2.4 * q, py - 5 * q, 1.2 * q, 1.2 * q);
    ctx.fillRect(px + 4.4 * q, py - 5 * q, 1.2 * q, 1.2 * q);
    ctx.fillRect(px + 2.4 * q, py - 4 * q, 3.2 * q, 1.2 * q);
    ctx.fillRect(px + 3.4 * q, py - 3 * q, 1.2 * q, 1.2 * q);
  } else if (kind === "sleep") {
    ctx.fillStyle = "#5a7ab8";
    ctx.fillRect(px + 2 * q, py - 5.2 * q, 2 * q, 0.8 * q);
    ctx.fillRect(px + 3 * q, py - 4.4 * q, 1 * q, 0.8 * q);
    ctx.fillRect(px + 2 * q, py - 3.6 * q, 2 * q, 0.8 * q);
    ctx.fillRect(px + 4.6 * q, py - 4 * q, 1.4 * q, 0.6 * q);
  } else if (kind === "alert") {
    ctx.fillStyle = "#c83c3c";
    ctx.fillRect(px + 3.4 * q, py - 5.4 * q, 1.2 * q, 2.6 * q);
    ctx.fillRect(px + 3.4 * q, py - 2.2 * q, 1.2 * q, 1 * q);
  } else if (kind === "sick") {
    ctx.fillStyle = "#4a9c4a";
    ctx.fillRect(px + 2.4 * q, py - 4.6 * q, 3.2 * q, 1 * q);
    ctx.fillRect(px + 3.4 * q, py - 5.4 * q, 1.2 * q, 2.8 * q);
  }
}

// ── weather overlay ─────────────────────────────────────────────────────────
export function drawWeather(ctx: CanvasRenderingContext2D, weather: Weather, w: number, hgt: number, time: number) {
  if (weather === "rain" || weather === "storm") {
    ctx.fillStyle = weather === "storm" ? "rgba(120,140,190,0.7)" : "rgba(150,170,210,0.5)";
    for (let i = 0; i < (weather === "storm" ? 90 : 50); i++) {
      const x = (h2(i, 1) * w + time * 220 * (0.6 + h2(i, 2))) % w;
      const y = (h2(i, 3) * hgt + time * 480 * (0.7 + h2(i, 4))) % hgt;
      ctx.fillRect(x, y, 2, 8);
    }
    if (weather === "storm" && Math.floor(time * 2) % 11 === 0 && time % 1 < 0.15) {
      ctx.fillStyle = "rgba(255,255,230,0.25)";
      ctx.fillRect(0, 0, w, hgt);
    }
  }
  if (weather === "snow") {
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    for (let i = 0; i < 60; i++) {
      const x = (h2(i, 5) * w + Math.sin(time + i) * 20 + time * 25) % w;
      const y = (h2(i, 6) * hgt + time * 60 * (0.5 + h2(i, 7))) % hgt;
      ctx.fillRect(x, y, 3, 3);
    }
  }
  if (weather === "fog") {
    for (let i = 0; i < 7; i++) {
      const y = ((h2(i, 8) * hgt + time * 8) % (hgt + 80)) - 40;
      const grad = ctx.createLinearGradient(0, y, 0, y + 60);
      grad.addColorStop(0, "rgba(220,228,235,0)");
      grad.addColorStop(0.5, "rgba(220,228,235,0.28)");
      grad.addColorStop(1, "rgba(220,228,235,0)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, y, w, 60);
    }
  }
  if (weather === "wind") {
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = 2;
    for (let i = 0; i < 6; i++) {
      const y = h2(i, 9) * hgt;
      const x = ((time * 320 * (0.7 + h2(i, 10))) % (w + 120)) - 60;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + 25, y - 6, x + 50, y);
      ctx.stroke();
    }
  }
}

export function nightTint(timeOfDay: string): string | null {
  if (timeOfDay === "night") return "rgba(20,25,60,0.45)";
  if (timeOfDay === "dusk") return "rgba(80,40,60,0.22)";
  if (timeOfDay === "dawn") return "rgba(255,180,120,0.12)";
  return null;
}
