"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Cat, GameState, StoryEventInstance } from "@/game/types";
import { buildInitialState, HERBS, HERB_BY_ID, PLAYER_ID, seasonOf } from "@/game/data";
import { MAPS, T, isSolid, tileAt } from "@/game/world";
import { drawCat, drawEmote, drawPortrait, drawTile, drawWeather, nightTint } from "@/game/sprites";
import { generateDialogue, npcChatter, opinionLine, relTier } from "@/game/dialogue";
import {
  advanceTime, aliveCats, applyStoryChoice, assignRoutines, canTellSilentTruth, doObserve, doPatrol, doPlayKits, doSleep, doTrain,
  gatherHerb, getEventInstance, passMoon, socialAction, tellSilentTruth, treatCat,
} from "@/game/sim";
import { GameAudio } from "@/game/audio";

const TILE = 30;
const VIEW_W = 26;
const VIEW_H = 17;

type DlgState =
  | null
  | { mode: "talk"; catId: string; text: string; sub: "main" | "askwho" }
  | { mode: "info"; title: string; text: string }
  | { mode: "event"; ev: StoryEventInstance; result?: string };

function Portrait({ cat, size = 96 }: { cat: Cat; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;
    drawPortrait(ctx, cat, size);
  }, [cat, size]);
  return <canvas ref={ref} width={size} height={size} style={{ imageRendering: "pixelated" }} className="border-2 border-[#5a4630] bg-[#1a2418] rounded" />;
}

function DPad({ onMove, size = 150 }: { onMove: (dx: number, dy: number) => void; size?: number }) {
  const [pressed, setPressed] = useState<string | null>(null);
  const btn = size / 3;

  const press = (dir: string, dx: number, dy: number) => (e: React.PointerEvent) => {
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    setPressed(dir);
    onMove(dx, dy);
  };
  const release = () => {
    setPressed(null);
    onMove(0, 0);
  };

  const arrows: { dir: string; label: string; dx: number; dy: number; x: number; y: number }[] = [
    { dir: "up", label: "▲", dx: 0, dy: -1, x: 1, y: 0 },
    { dir: "left", label: "◀", dx: -1, dy: 0, x: 0, y: 1 },
    { dir: "right", label: "▶", dx: 1, dy: 0, x: 2, y: 1 },
    { dir: "down", label: "▼", dx: 0, dy: 1, x: 1, y: 2 },
  ];

  return (
    <div className="relative" style={{ width: size, height: size, touchAction: "none" }}>
      {/* center hub */}
      <div
        className="absolute bg-[#1c2818cc] border-2 border-[#3a4a34] pointer-events-none"
        style={{ left: btn, top: btn, width: btn, height: btn }}
      />
      {arrows.map((a) => (
        <button
          key={a.dir}
          className={`absolute flex items-center justify-center text-xl border-4 select-none ${
            pressed === a.dir
              ? "bg-[#4a6a3c] border-[#8aba6c] text-[#ffe08a]"
              : "bg-[#1c2818dd] border-[#5a7a4c] text-[#a8c890] active:bg-[#3a5a2c]"
          }`}
          style={{
            left: a.x * btn,
            top: a.y * btn,
            width: btn,
            height: btn,
            touchAction: "none",
            boxShadow: pressed === a.dir ? "inset 0 3px 0 #2a4a1c" : "0 3px 0 #141c12",
          }}
          onPointerDown={press(a.dir, a.dx, a.dy)}
          onPointerUp={release}
          onPointerCancel={release}
          onPointerLeave={release}
          onContextMenu={(e) => e.preventDefault()}
        >
          {a.label}
        </button>
      ))}
    </div>
  );
}

function Bar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-1 text-[10px]">
      <span className="w-16 text-right opacity-80">{label}</span>
      <div className="h-2 w-24 bg-[#1a2418] border border-[#3a4a34]">
        <div className="h-full" style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: color }} />
      </div>
      <span className="w-6">{Math.round(value)}</span>
    </div>
  );
}

export default function Game() {
  const stateRef = useRef<GameState | null>(null);
  const [screen, setScreen] = useState<"title" | "game" | "ending">("title");
  const [hasSave, setHasSave] = useState<boolean | null>(null);
  const [, setTick] = useState(0);
  const rerender = useCallback(() => setTick((t) => t + 1), []);
  const [dlg, setDlg] = useState<DlgState>(null);
  const [panel, setPanel] = useState<"none" | "clan" | "journal" | "herbs" | "log">("log");
  const [clanCat, setClanCat] = useState<string | null>(null);
  const [moonReport, setMoonReport] = useState<string[] | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [soundOn, setSoundOn] = useState(false);
  const [saveStatus, setSaveStatus] = useState("");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const keysRef = useRef<Record<string, boolean>>({});
  const joyRef = useRef({ dx: 0, dy: 0 });
  const [controlMode, setControlMode] = useState<"pc" | "mobile">("pc");
  const audioRef = useRef<GameAudio | null>(null);
  const bubblesRef = useRef<{ catId: string; text: string; until: number }[]>([]);
  const dlgRef = useRef<DlgState>(null);
  dlgRef.current = dlg;
  const controlModeRef = useRef<"pc" | "mobile">("pc");
  controlModeRef.current = controlMode;
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 5200);
  }, []);

  // ── load save check ──
  useEffect(() => {
    fetch("/api/saves")
      .then((r) => r.json())
      .then((d) => setHasSave(!!d.save))
      .catch(() => setHasSave(false));
  }, []);

  // ── control mode: load saved preference or auto-detect touch devices ──
  useEffect(() => {
    try {
      const saved = localStorage.getItem("hollyclan_controls");
      if (saved === "pc" || saved === "mobile") {
        setControlMode(saved);
        return;
      }
    } catch {}
    if (typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches) {
      setControlMode("mobile");
    }
  }, []);

  const pickControlMode = useCallback((mode: "pc" | "mobile") => {
    setControlMode(mode);
    try {
      localStorage.setItem("hollyclan_controls", mode);
    } catch {}
  }, []);

  const saveGame = useCallback(async () => {
    const s = stateRef.current;
    if (!s) return;
    setSaveStatus("saving…");
    try {
      await fetch("/api/saves", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ moon: s.moon, summary: `Moon ${s.moon} — ${s.cats[PLAYER_ID].name}`, state: s }),
      });
      setSaveStatus("saved ✓");
      setTimeout(() => setSaveStatus(""), 2000);
    } catch {
      setSaveStatus("save failed");
    }
  }, []);

  const startNew = useCallback(() => {
    const s = buildInitialState();
    assignRoutines(s, 12345);
    stateRef.current = s;
    setScreen("game");
    setPanel("log");
    // show intro event
    const ev = getEventInstance(s, "intro");
    if (ev) setDlg({ mode: "event", ev });
    s.pendingEvents = s.pendingEvents.filter((e) => e !== "intro");
    rerender();
  }, [rerender]);

  const continueGame = useCallback(async () => {
    try {
      const d = await (await fetch("/api/saves")).json();
      if (d.save?.state) {
        stateRef.current = d.save.state as GameState;
        if (stateRef.current.ending) setScreen("ending");
        else setScreen("game");
        rerender();
        return;
      }
    } catch {}
    startNew();
  }, [rerender, startNew]);

  // ── input ──
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = true;
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) e.preventDefault();
      if ((e.key === "e" || e.key === "E" || e.key === " ") && screen === "game" && !dlgRef.current) tryInteract();
      if (e.key === "Escape") setDlg(null);
    };
    const up = (e: KeyboardEvent) => (keysRef.current[e.key.toLowerCase()] = false);
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen]);

  // ── interaction ──
  const nearestCat = useCallback((): Cat | null => {
    const s = stateRef.current;
    if (!s) return null;
    let best: Cat | null = null;
    let bd = 2.2;
    for (const c of aliveCats(s)) {
      if (c.id === PLAYER_ID || c.map !== s.playerMap) continue;
      const d = Math.hypot((c.fx ?? c.x) - s.px, (c.fy ?? c.y) - s.py);
      if (d < bd) {
        bd = d;
        best = c;
      }
    }
    return best;
  }, []);

  const nearestNode = useCallback(() => {
    const s = stateRef.current;
    if (!s) return null;
    for (const n of s.herbNodes) {
      if (n.map !== s.playerMap) continue;
      if (Math.hypot(n.x - s.px, n.y - s.py) < 1.8) return n;
    }
    return null;
  }, []);

  const inMedDen = useCallback(() => {
    const s = stateRef.current;
    if (!s) return false;
    return s.playerMap === "camp" && s.px >= 4 && s.px <= 12 && s.py >= 6 && s.py <= 13;
  }, []);

  const tryInteract = useCallback(() => {
    const s = stateRef.current;
    if (!s || s.ending) return;
    const cat = nearestCat();
    if (cat) {
      const seed = Math.floor(Math.random() * 1e9);
      const text = generateDialogue(s, cat, seed);
      setDlg({ mode: "talk", catId: cat.id, text, sub: "main" });
      audioRef.current?.chime(true);
      rerender();
      return;
    }
    const node = nearestNode();
    if (node) {
      const msg = gatherHerb(s, node.id);
      showToast(msg);
      audioRef.current?.chime(true);
      rerender();
      return;
    }
    showToast("Nothing to interact with here. Walk up to a cat, an herb patch, or a den.");
  }, [nearestCat, nearestNode, rerender, showToast]);

  // ── game actions ──
  const act = useCallback(
    (kind: string) => {
      const s = stateRef.current;
      if (!s || s.ending) return;
      let msg = "";
      if (kind === "sleep") {
        const res = doSleep(s);
        setDlg({ mode: "info", title: "🌙 Sleep", text: res.msg });
      } else if (kind === "train") {
        msg = doTrain(s);
        showToast(msg);
      } else if (kind === "patrol") {
        msg = doPatrol(s);
        setDlg({ mode: "info", title: "🐾 Patrol", text: msg });
      } else if (kind === "play") {
        msg = doPlayKits(s);
        showToast(msg);
      }
      rerender();
    },
    [rerender, showToast]
  );

  const handlePassMoon = useCallback(() => {
    const s = stateRef.current;
    if (!s || s.ending) return;
    const report = passMoon(s);
    setMoonReport(report);
    saveGame();
    rerender();
  }, [rerender, saveGame]);

  const closeMoonReport = useCallback(() => {
    setMoonReport(null);
    const s = stateRef.current;
    if (!s) return;
    if (s.ending) {
      setScreen("ending");
      return;
    }
    // pop next story event
    if (s.pendingEvents.length > 0) {
      const id = s.pendingEvents.shift()!;
      const ev = getEventInstance(s, id);
      if (ev) setDlg({ mode: "event", ev });
    }
    rerender();
  }, [rerender]);

  const chooseEvent = useCallback(
    (ev: StoryEventInstance, idx: number) => {
      const s = stateRef.current;
      if (!s) return;
      s.flags["done_" + ev.id] = true;
      const result = applyStoryChoice(s, ev.id, idx);
      if (s.ending) {
        setDlg(null);
        setScreen("ending");
        saveGame();
        return;
      }
      if (result) {
        setDlg({ mode: "event", ev: { ...ev, choices: [] }, result });
      } else {
        // next queued event
        if (s.pendingEvents.length > 0) {
          const id = s.pendingEvents.shift()!;
          const next = getEventInstance(s, id);
          if (next) {
            setDlg({ mode: "event", ev: next });
            return;
          }
        }
        setDlg(null);
      }
      saveGame();
      rerender();
    },
    [rerender, saveGame]
  );

  const closeEventResult = useCallback(() => {
    const s = stateRef.current;
    if (!s) return;
    if (s.pendingEvents.length > 0) {
      const id = s.pendingEvents.shift()!;
      const next = getEventInstance(s, id);
      if (next) {
        setDlg({ mode: "event", ev: next });
        return;
      }
    }
    setDlg(null);
    rerender();
  }, [rerender]);

  // ── main loop ──
  useEffect(() => {
    if (screen !== "game") return;
    let raf = 0;
    let last = performance.now();
    let stepAcc = 0;
    let chatterAcc = 0;
    let moveCooldown = 0;

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = stateRef.current;
      const canvas = canvasRef.current;
      if (!s || !canvas) {
        raf = requestAnimationFrame(loop);
        return;
      }
      const ctx = canvas.getContext("2d")!;
      ctx.imageSmoothingEnabled = false;
      const time = now / 1000;
      const map = MAPS[s.playerMap];

      // player movement
      moveCooldown -= dt;
      if (!dlgRef.current && moveCooldown <= 0 && !s.ending) {
        const k = keysRef.current;
        let dx = 0, dy = 0;
        if (k["arrowup"] || k["w"]) dy = -1;
        else if (k["arrowdown"] || k["s"]) dy = 1;
        else if (k["arrowleft"] || k["a"]) dx = -1;
        else if (k["arrowright"] || k["d"]) dx = 1;
        // virtual joystick (dominant axis → grid step)
        if (dx === 0 && dy === 0) {
          const j = joyRef.current;
          const mag = Math.hypot(j.dx, j.dy);
          if (mag > 0.35) {
            if (Math.abs(j.dx) > Math.abs(j.dy)) dx = Math.sign(j.dx);
            else dy = Math.sign(j.dy);
          }
        }
        if (dx !== 0 || dy !== 0) {
          const nx = s.px + dx, ny = s.py + dy;
          const player = s.cats[PLAYER_ID];
          player.dir = dx < 0 ? 1 : dx > 0 ? 2 : player.dir;
          if (!isSolid(map, nx, ny)) {
            s.px = nx;
            s.py = ny;
            player.x = nx;
            player.y = ny;
            const tile = tileAt(map, nx, ny);
            audioRef.current?.footstep(tile === T.GRASS || tile === T.TALL);
            // gate transition
            if (tile === T.GATE) {
              const gate = map.gates.find((g) => g.x === nx && g.y === ny);
              if (gate) {
                s.playerMap = gate.to;
                s.px = gate.dx;
                s.py = gate.dy;
                player.map = gate.to;
                player.x = gate.dx;
                player.y = gate.dy;
                showToast(gate.to === "territory" ? "You pad out into HollyClan territory. (Rivers, herbs, borders — and NightClan to the north.)" : "You return to the HollyClan camp.");
              }
            }
          }
          moveCooldown = 0.13;
        }
      }

      // NPC steps
      stepAcc += dt;
      if (stepAcc > 0.42) {
        stepAcc = 0;
        for (const c of aliveCats(s)) {
          if (c.id === PLAYER_ID) continue;
          if (c.map !== s.playerMap) {
            c.x = c.tx;
            c.y = c.ty;
            continue;
          }
          const m = MAPS[c.map];
          if (c.x !== c.tx || c.y !== c.ty) {
            const dx = Math.sign(c.tx - c.x);
            const dy = Math.sign(c.ty - c.y);
            const tryOrder = Math.abs(c.tx - c.x) > Math.abs(c.ty - c.y) ? [[dx, 0], [0, dy]] : [[0, dy], [dx, 0]];
            for (const [mx, my] of tryOrder) {
              if ((mx !== 0 || my !== 0) && !isSolid(m, c.x + mx, c.y + my)) {
                c.x += mx;
                c.y += my;
                if (mx !== 0) c.dir = mx < 0 ? 1 : 2;
                break;
              }
            }
            if (c.x === c.tx && c.y === c.ty && Math.random() < 0.3) {
              // idle wander next time
            }
          } else if (s.timeOfDay !== "night" && Math.random() < 0.12) {
            // cats settle in their dens at night — no idle wandering
            const m2 = MAPS[c.map];
            const wx = c.x + Math.floor(Math.random() * 3 - 1);
            const wy = c.y + Math.floor(Math.random() * 3 - 1);
            if (!isSolid(m2, wx, wy)) {
              c.tx = wx;
              c.ty = wy;
            }
          }
        }
      }

      // smooth positions
      for (const c of aliveCats(s)) {
        const targX = c.id === PLAYER_ID ? s.px : c.x;
        const targY = c.id === PLAYER_ID ? s.py : c.y;
        c.fx = c.fx === undefined ? targX : c.fx + (targX - c.fx) * Math.min(1, dt * 10);
        c.fy = c.fy === undefined ? targY : c.fy + (targY - c.fy) * Math.min(1, dt * 10);
      }

      // ambient npc chatter
      chatterAcc += dt;
      if (chatterAcc > 2.2) {
        chatterAcc = 0;
        const nearby = aliveCats(s).filter(
          (c) =>
            c.id !== PLAYER_ID &&
            c.map === s.playerMap &&
            Math.hypot(c.x - s.px, c.y - s.py) < 11 &&
            (s.timeOfDay !== "night" || c.activity !== "resting") // sleeping cats don't gossip
        );
        for (let i = 0; i < nearby.length && bubblesRef.current.length < 3; i++) {
          const a = nearby[i];
          const partner = nearby.find((b) => b.id !== a.id && Math.hypot(a.x - b.x, a.y - b.y) < 2.5);
          if (partner && Math.random() < 0.35) {
            const [l1, l2] = npcChatter(s, a, partner, Math.floor(Math.random() * 1e9));
            bubblesRef.current.push({ catId: a.id, text: l1, until: time + 4 });
            bubblesRef.current.push({ catId: partner.id, text: l2, until: time + 6.5 });
            break;
          }
        }
      }
      bubblesRef.current = bubblesRef.current.filter((b) => b.until > time);

      // audio environment
      if (audioRef.current?.enabled) {
        let nearWater = false;
        if (s.playerMap === "territory") {
          for (let dy = -3; dy <= 3 && !nearWater; dy++)
            for (let dx = -3; dx <= 3; dx++)
              if (tileAt(map, s.px + dx, s.py + dy) === T.WATER) {
                nearWater = true;
                break;
              }
        }
        const mood = s.moon >= 25 || (s.flags.silent_knows as boolean) ? "dark" : s.moon >= 8 || s.suspicion > 50 ? "tense" : "calm";
        audioRef.current.setEnvironment(s.weather, nearWater, s.timeOfDay, mood);
      }

      // ── RENDER ──
      const camX = Math.max(0, Math.min(map.w - VIEW_W, s.px - VIEW_W / 2));
      const camY = Math.max(0, Math.min(map.h - VIEW_H, s.py - VIEW_H / 2));
      const season = seasonOf(s.moon);
      ctx.fillStyle = "#101810";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      for (let vy = 0; vy <= VIEW_H; vy++) {
        for (let vx = 0; vx <= VIEW_W; vx++) {
          const txl = Math.floor(camX) + vx;
          const tyl = Math.floor(camY) + vy;
          if (txl >= map.w || tyl >= map.h) continue;
          drawTile(ctx, tileAt(map, txl, tyl), txl, tyl, (txl - camX) * TILE, (tyl - camY) * TILE, TILE, season, time);
        }
      }
      // herb nodes
      for (const n of s.herbNodes) {
        if (n.map !== s.playerMap || n.qty <= 0) continue;
        const def = HERB_BY_ID[n.herb];
        const hx = (n.x - camX) * TILE, hy = (n.y - camY) * TILE;
        if (hx < -TILE || hy < -TILE || hx > canvas.width || hy > canvas.height) continue;
        ctx.fillStyle = def.color;
        for (let i = 0; i < Math.min(n.qty, 3); i++) {
          ctx.fillRect(hx + 6 + i * 7, hy + 14 + (i % 2) * 5, 5, 5);
          ctx.fillStyle = def.color;
        }
        ctx.fillStyle = "#2c4424";
        ctx.fillRect(hx + 8, hy + 22, 3, 6);
        ctx.fillRect(hx + 16, hy + 24, 3, 5);
      }
      // labels
      ctx.font = "9px monospace";
      for (const l of map.labels) {
        if (!l.text) continue;
        const lx = (l.x - camX) * TILE, ly = (l.y - camY) * TILE;
        if (lx < -80 || ly < 0 || lx > canvas.width + 40 || ly > canvas.height) continue;
        ctx.fillStyle = "rgba(0,0,0,0.5)";
        const tw = ctx.measureText(l.text).width;
        ctx.fillRect(lx - tw / 2 - 2 + TILE / 2, ly - 4, tw + 4, 11);
        ctx.fillStyle = "#e8dfc0";
        ctx.textAlign = "center";
        ctx.fillText(l.text, lx + TILE / 2, ly + 4);
        ctx.textAlign = "left";
      }
      // cats (draw sorted by y)
      const visible = aliveCats(s)
        .filter((c) => c.map === s.playerMap)
        .sort((a, b) => (a.fy ?? a.y) - (b.fy ?? b.y));
      const frame = Math.floor(time * 6);
      for (const c of visible) {
        const cx = ((c.fx ?? c.x) - camX) * TILE;
        const cy = ((c.fy ?? c.y) - camY) * TILE;
        if (cx < -TILE * 2 || cy < -TILE * 2 || cx > canvas.width + TILE || cy > canvas.height + TILE) continue;
        const moving = Math.hypot((c.fx ?? c.x) - c.x, (c.fy ?? c.y) - c.y) > 0.05 || (c.id === PLAYER_ID && Math.hypot((c.fx ?? 0) - s.px, (c.fy ?? 0) - s.py) > 0.05);
        const sleeping = c.activity === "resting" && s.timeOfDay === "night" && c.id !== PLAYER_ID;
        drawCat(ctx, c, cx, cy, TILE, frame, moving, sleeping, c.dir === 1);
        // name tag
        ctx.font = "8px monospace";
        ctx.textAlign = "center";
        ctx.fillStyle = "rgba(0,0,0,0.45)";
        const nw = ctx.measureText(c.name).width;
        ctx.fillRect(cx + TILE / 2 - nw / 2 - 2, cy - 8, nw + 4, 9);
        ctx.fillStyle = c.id === PLAYER_ID ? "#ffe08a" : c.id === "silentpaw" && s.moon >= 8 ? "#b8a8e8" : "#d8e8d0";
        ctx.fillText(c.name, cx + TILE / 2, cy - 1);
        ctx.textAlign = "left";
        // emotes
        if (c.sick) drawEmote(ctx, "sick", cx + TILE * 0.6, cy - 8, TILE * 0.8);
        else if (sleeping) drawEmote(ctx, "sleep", cx + TILE * 0.6, cy - 8, TILE * 0.8);
        else if (c.mood === "grieving") drawEmote(ctx, "alert", cx + TILE * 0.6, cy - 8, TILE * 0.7);
        else if (c.id === "silentpaw" && c.activity === "watching") drawEmote(ctx, "heart", cx + TILE * 0.6, cy - 8, TILE * 0.7);
      }
      // chatter bubbles
      ctx.font = "9px monospace";
      for (const b of bubblesRef.current) {
        const c = s.cats[b.catId];
        if (!c || !c.alive || c.map !== s.playerMap) continue;
        const cx = ((c.fx ?? c.x) - camX) * TILE + TILE / 2;
        const cy = ((c.fy ?? c.y) - camY) * TILE - 14;
        const txt = b.text.length > 46 ? b.text.slice(0, 44) + "…" : b.text;
        const tw = ctx.measureText(txt).width;
        ctx.fillStyle = "rgba(252,250,235,0.92)";
        ctx.fillRect(cx - tw / 2 - 4, cy - 11, tw + 8, 14);
        ctx.fillStyle = "#2a2418";
        ctx.textAlign = "center";
        ctx.fillText(txt, cx, cy);
        ctx.textAlign = "left";
      }
      // weather + tint
      drawWeather(ctx, s.weather, canvas.width, canvas.height, time);
      const tint = nightTint(s.timeOfDay);
      if (tint) {
        ctx.fillStyle = tint;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      // interact hint
      if (!dlgRef.current) {
        const near = nearestCat();
        const node = nearestNode();
        const key = controlModeRef.current === "mobile" ? "[🐾]" : "[E]";
        let hint = "";
        if (near) hint = `${key} Talk to ${near.name}`;
        else if (node) hint = `${key} Gather ${HERB_BY_ID[node.herb].name}`;
        else if (inMedDen()) hint = "You are in the medicine den — Sleep / Treat from the action bar";
        if (hint) {
          ctx.font = "11px monospace";
          const tw = ctx.measureText(hint).width;
          ctx.fillStyle = "rgba(0,0,0,0.6)";
          ctx.fillRect(canvas.width / 2 - tw / 2 - 8, canvas.height - 26, tw + 16, 18);
          ctx.fillStyle = "#ffe08a";
          ctx.textAlign = "center";
          ctx.fillText(hint, canvas.width / 2, canvas.height - 13);
          ctx.textAlign = "left";
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [screen, nearestCat, nearestNode, inMedDen, showToast]);

  const toggleSound = useCallback(() => {
    if (!audioRef.current) audioRef.current = new GameAudio();
    if (soundOn) {
      audioRef.current.stop();
      setSoundOn(false);
    } else {
      audioRef.current.start();
      setSoundOn(true);
    }
  }, [soundOn]);

  // ─────────────────────── RENDER UI ───────────────────────
  const s = stateRef.current;

  if (screen === "title") {
    return (
      <div className="min-h-screen bg-[#141c12] text-[#e8dfc0] flex items-center justify-center font-mono">
        <div className="text-center max-w-2xl px-6">
          <div className="text-5xl mb-2 tracking-widest" style={{ textShadow: "3px 3px 0 #3a5a2c" }}>🌿 HOLLYCLAN 🌿</div>
          <div className="text-xl mb-1 text-[#a8c890]">The Shadow and the Blaze</div>
          <div className="text-xs mb-8 opacity-70">a living warrior-cats clan simulation · 30+ moons · pixel art</div>
          <div className="text-left text-xs bg-[#1c2818] border-2 border-[#3a5a2c] p-4 mb-6 leading-relaxed">
            <p className="mb-2">You are <span className="text-[#ffe08a]">Mistypaw</span>, medicine cat apprentice of HollyClan — son of Wolftail and Shadowgaze, keeper of a secret you witnessed as a kit, and best friend of a quiet black apprentice named Silentpaw.</p>
            <p className="mb-2">Explore. Heal. Gather herbs. Talk to every cat — each has their own mind, memories, grudges and loves that grow with or without you. Pass moons at your own pace.</p>
            <p className="opacity-70">
              {controlMode === "pc"
                ? "WASD / arrows to move · E or Space to interact · everything else is up to you."
                : "On-screen arrow keys to move · tap the paw button to interact · everything else is up to you."}
            </p>
          </div>
          <div className="mb-6">
            <div className="text-xs mb-2 opacity-70">— CONTROLS —</div>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => pickControlMode("pc")}
                className={`px-5 py-2 border-2 text-xs ${controlMode === "pc" ? "bg-[#3a5a2c] border-[#8aba6c] text-[#ffe08a]" : "bg-[#1c2818] border-[#3a4a34] opacity-60 hover:opacity-100"}`}
              >
                ⌨ PC
                <div className="text-[10px] opacity-70 mt-0.5">keyboard + mouse</div>
              </button>
              <button
                onClick={() => pickControlMode("mobile")}
                className={`px-5 py-2 border-2 text-xs ${controlMode === "mobile" ? "bg-[#3a5a2c] border-[#8aba6c] text-[#ffe08a]" : "bg-[#1c2818] border-[#3a4a34] opacity-60 hover:opacity-100"}`}
              >
                📱 MOBILE
                <div className="text-[10px] opacity-70 mt-0.5">arrow keys + touch</div>
              </button>
            </div>
            <div className="text-[10px] mt-2 opacity-50">auto-detected for your device — you can switch anytime in-game</div>
          </div>
          <div className="flex gap-4 justify-center">
            <button onClick={startNew} className="px-6 py-3 bg-[#3a5a2c] border-2 border-[#5a7a4c] hover:bg-[#4a6a3c] text-sm">▶ NEW GAME</button>
            {hasSave && (
              <button onClick={continueGame} className="px-6 py-3 bg-[#2c3a5a] border-2 border-[#4c5a7a] hover:bg-[#3c4a6a] text-sm">⟳ CONTINUE (saved)</button>
            )}
          </div>
          {hasSave === null && <div className="mt-3 text-xs opacity-50">checking for saved game…</div>}
        </div>
      </div>
    );
  }

  if (screen === "ending" && s?.ending) {
    return (
      <div className="min-h-screen bg-[#0c1210] text-[#e8dfc0] flex items-center justify-center font-mono p-6">
        <div className="max-w-3xl bg-[#141c18] border-2 border-[#3a5a4c] p-8">
          <div className="text-3xl mb-4 text-[#b8a8e8]" style={{ textShadow: "2px 2px 0 #2a2440" }}>{s.ending.title}</div>
          <div className="text-sm whitespace-pre-wrap leading-relaxed mb-6 opacity-90">{s.ending.text}</div>
          <div className="text-xs opacity-60 mb-6">Reached at Moon {s.moon} · Suspicion {Math.round(s.suspicion)} · Clues found: {s.clues.length}</div>
          <button
            onClick={async () => {
              await fetch("/api/saves", { method: "DELETE" });
              setHasSave(false);
              setScreen("title");
              stateRef.current = null;
            }}
            className="px-6 py-3 bg-[#3a5a2c] border-2 border-[#5a7a4c] hover:bg-[#4a6a3c] text-sm"
          >
            ⟲ Begin a new story
          </button>
        </div>
      </div>
    );
  }

  if (!s) return <div className="min-h-screen bg-[#141c12] text-[#e8dfc0] flex items-center justify-center font-mono">loading…</div>;

  const player = s.cats[PLAYER_ID];
  const sickCats = aliveCats(s).filter((c) => c.sick);
  const talkCat = dlg?.mode === "talk" ? s.cats[dlg.catId] : null;

  return (
    <div className="min-h-screen bg-[#141c12] text-[#e8dfc0] font-mono flex flex-col items-center py-3 select-none">
      {/* HUD */}
      <div className="flex items-center gap-3 mb-2 text-xs flex-wrap justify-center max-w-[1200px]">
        <span className="px-2 py-1 bg-[#1c2818] border border-[#3a5a2c]">🌙 Moon {s.moon}</span>
        <span className="px-2 py-1 bg-[#1c2818] border border-[#3a5a2c]">{seasonOf(s.moon)}</span>
        <span className="px-2 py-1 bg-[#1c2818] border border-[#3a5a2c]">
          {{ clear: "☀ clear", rain: "🌧 rain", storm: "⛈ storm", wind: "🍃 wind", fog: "🌫 fog", snow: "❄ snow" }[s.weather]}
        </span>
        <span className="px-2 py-1 bg-[#1c2818] border border-[#3a5a2c]">{{ dawn: "🌅 dawn", day: "🌞 day", dusk: "🌆 dusk", night: "🌌 night" }[s.timeOfDay]}</span>
        <span className="px-2 py-1 bg-[#1c2818] border border-[#3a5a2c] text-[#ffe08a]">{player.name}</span>
        {s.moon >= 8 && (
          <span className="px-2 py-1 bg-[#241c28] border border-[#5a3a6a] flex items-center gap-1">
            <span className="opacity-80">suspicion:</span>
            <span className="inline-block h-2 w-20 bg-[#181020] border border-[#4a3a5a] align-middle">
              <span className="block h-full bg-gradient-to-r from-[#7a5aa8] to-[#c84a6a]" style={{ width: `${s.suspicion}%` }} />
            </span>
          </span>
        )}
        {sickCats.length > 0 && <span className="px-2 py-1 bg-[#2a1c18] border border-[#6a3a2c] text-[#f0a080]">🤒 {sickCats.map((c) => c.name).join(", ")}</span>}
        <span className="opacity-50">{saveStatus}</span>
      </div>

      <div className="flex gap-2 items-start flex-wrap justify-center">
        {/* CANVAS */}
        <div className={`relative ${controlMode === "mobile" ? "w-full max-w-[780px]" : ""}`}>
          <canvas
            ref={canvasRef}
            width={VIEW_W * TILE}
            height={VIEW_H * TILE}
            style={controlMode === "mobile" ? { imageRendering: "pixelated", width: "100%", height: "auto", touchAction: "none" } : { imageRendering: "pixelated" }}
            className="border-4 border-[#3a2c1c] bg-black"
            onClick={() => tryInteract()}
          />
          {toast && (
            <div className={`absolute left-1/2 -translate-x-1/2 max-w-[90%] bg-[#1c2818ee] border-2 border-[#5a7a4c] px-3 py-2 text-xs leading-snug ${controlMode === "mobile" ? "top-2" : "bottom-8"}`}>{toast}</div>
          )}
          {controlMode === "mobile" && !dlg && !moonReport && (
            <>
              <div className="absolute bottom-3 left-3 z-10">
                <DPad onMove={(dx: number, dy: number) => (joyRef.current = { dx, dy })} />
              </div>
              <button
                className="absolute bottom-6 right-4 z-10 w-20 h-20 rounded-full bg-[#2c3a5add] border-4 border-[#6c7aa0] active:bg-[#4c5a8a] flex flex-col items-center justify-center shadow-[0_0_0_3px_#141c12]"
                style={{ touchAction: "manipulation" }}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  tryInteract();
                }}
              >
                <span className="text-2xl leading-none">🐾</span>
                <span className="text-[9px] text-[#c8d8f0] mt-0.5">INTERACT</span>
              </button>
            </>
          )}
        </div>

        {/* SIDE PANEL */}
        <div className={`bg-[#18221a] border-2 border-[#3a5a2c] p-2 text-xs overflow-hidden flex flex-col ${controlMode === "mobile" ? "w-full max-w-[780px] h-[320px]" : "w-[300px] h-[510px]"}`}>
          <div className="flex gap-1 mb-2 flex-wrap">
            {(["log", "clan", "herbs", "journal"] as const).map((p) => (
              <button key={p} onClick={() => setPanel(p)} className={`px-2 py-1 border ${panel === p ? "bg-[#3a5a2c] border-[#6a8a5c]" : "bg-[#1c2818] border-[#3a4a34] opacity-70"}`}>
                {p === "log" ? "📜 Events" : p === "clan" ? "🐱 Clan" : p === "herbs" ? "🌿 Herbs" : "📖 Journal"}
              </button>
            ))}
          </div>
          <div className="flex-1 overflow-y-auto pr-1">
            {panel === "log" && (
              <div className="space-y-1">
                <div className="text-[#a8c890] mb-1">This moon &amp; last:</div>
                {[...(s.history.slice(-1)[0]?.events ?? []), ...s.log].slice(-30).map((e, i) => (
                  <div key={i} className="leading-snug opacity-90 border-b border-[#243024] pb-1">{e}</div>
                ))}
                {s.log.length === 0 && s.history.length === 0 && <div className="opacity-60">The moon is young. Go live it.</div>}
              </div>
            )}
            {panel === "herbs" && (
              <div className="space-y-1">
                <div className="text-[#a8c890] mb-1">Herb store ({inMedDen() ? "you are here" : "in the medicine den"}):</div>
                {HERBS.map((h) => (
                  <div key={h.id} className="flex justify-between border-b border-[#243024] pb-1">
                    <span><span style={{ color: h.color }}>■</span> {h.name} <span className="opacity-50">— {h.use}</span></span>
                    <span className={(s.herbs[h.id] ?? 0) === 0 ? "text-[#e08a7a]" : "text-[#a8e890]"}>{s.herbs[h.id] ?? 0}</span>
                  </div>
                ))}
                <div className="opacity-60 mt-2">Herbs grow at marked patches in the territory. Seasons matter — catmint vanishes in Leafbare, and greencough loves Leafbare.</div>
              </div>
            )}
            {panel === "journal" && (
              <div className="space-y-2">
                <div className="text-[#a8c890]">Clues &amp; observations ({s.clues.length}):</div>
                {s.clues.length === 0 && <div className="opacity-60">Nothing yet. Observe cats, dream, investigate.</div>}
                {s.clues.map((c, i) => (
                  <div key={i} className="border-l-2 border-[#7a5aa8] pl-2 leading-snug opacity-90">{c}</div>
                ))}
                <div className="text-[#a8c890] mt-2">Your memories:</div>
                {player.memories.slice(-8).reverse().map((m, i) => (
                  <div key={i} className="border-l-2 border-[#5a7a4c] pl-2 leading-snug opacity-80">
                    <span className="opacity-60">[moon {m.moon}]</span> {m.text}
                  </div>
                ))}
              </div>
            )}
            {panel === "clan" && !clanCat && (
              <div className="space-y-1">
                {aliveCats(s).filter((c) => c.role !== "outsider").map((c) => (
                  <button key={c.id} onClick={() => setClanCat(c.id)} className="w-full text-left border-b border-[#243024] pb-1 hover:bg-[#243024] px-1">
                    <span className={c.id === PLAYER_ID ? "text-[#ffe08a]" : ""}>{c.name}</span>
                    <span className="opacity-60"> · {c.role}</span>
                    {c.sick && <span className="text-[#f0a080]"> · {c.sick.name}</span>}
                    {c.mood === "grieving" && <span className="text-[#8aa8d8]"> · grieving</span>}
                  </button>
                ))}
                <div className="text-[#a8c890] mt-2">In StarClan:</div>
                {Object.values(s.cats).filter((c) => !c.alive).map((c) => (
                  <div key={c.id} className="opacity-60 px-1">☆ {c.name} — {c.deathCause} (moon {c.deathMoon})</div>
                ))}
              </div>
            )}
            {panel === "clan" && clanCat && s.cats[clanCat] && (
              <div>
                <button onClick={() => setClanCat(null)} className="mb-2 opacity-70">← back</button>
                <div className="flex gap-2 items-start mb-2">
                  <Portrait cat={s.cats[clanCat]} size={64} />
                  <div>
                    <div className="text-[#ffe08a]">{s.cats[clanCat].name}</div>
                    <div className="opacity-70">{s.cats[clanCat].role} · {s.cats[clanCat].ageMoons} moons</div>
                    <div className="opacity-70">mood: {s.cats[clanCat].mood}</div>
                    <div className="opacity-70">health: {Math.round(s.cats[clanCat].health)}</div>
                    {s.cats[clanCat].lives !== undefined && (
                      <div className="text-[#ffe08a]">★ {s.cats[clanCat].lives} of 9 lives</div>
                    )}
                    {(s.cats[clanCat].role === "apprentice" || s.cats[clanCat].role === "medapprentice") && (
                      <div className="opacity-70">
                        mentor: {s.cats[clanCat].mentor ? s.cats[s.cats[clanCat].mentor!]?.name ?? "—" : "none!"}
                      </div>
                    )}
                    {(() => {
                      const apps = aliveCats(s).filter((a) => (a.role === "apprentice" || a.role === "medapprentice") && a.mentor === clanCat);
                      return apps.length > 0 ? <div className="opacity-70">mentoring: {apps.map((a) => a.name).join(", ")}</div> : null;
                    })()}
                    {(s.cats[clanCat].apprenticesTrained ?? 0) > 0 && (
                      <div className="opacity-70">apprentices trained: {s.cats[clanCat].apprenticesTrained}</div>
                    )}
                  </div>
                </div>
                <div className="opacity-80 mb-2 leading-snug">{s.cats[clanCat].desc}. {s.cats[clanCat].traits.join(", ")}.</div>
                {(s.cats[clanCat].role === "apprentice" || s.cats[clanCat].role === "medapprentice") && (
                  <div className="mb-2">
                    <Bar label="training" value={s.cats[clanCat].trainingProgress ?? 0} color="#8ac860" />
                    {(s.cats[clanCat].lessons ?? []).length > 0 && (
                      <div className="opacity-70 mt-1 leading-snug">learned: {(s.cats[clanCat].lessons ?? []).slice(-3).join("; ")}</div>
                    )}
                  </div>
                )}
                {clanCat !== PLAYER_ID && (
                  <>
                    <div className="text-[#a8c890] mb-1">How {s.cats[clanCat].name} feels about you:</div>
                    <div className="space-y-0.5">
                      <Bar label="affection" value={s.cats[clanCat].rel[PLAYER_ID].affection} color="#d87a9a" />
                      <Bar label="friendship" value={s.cats[clanCat].rel[PLAYER_ID].friendship} color="#7ab87a" />
                      <Bar label="trust" value={s.cats[clanCat].rel[PLAYER_ID].trust} color="#7a9ad8" />
                      <Bar label="respect" value={s.cats[clanCat].rel[PLAYER_ID].respect} color="#d8c87a" />
                      <Bar label="fear" value={s.cats[clanCat].rel[PLAYER_ID].fear} color="#a87ad8" />
                      <Bar label="jealousy" value={s.cats[clanCat].rel[PLAYER_ID].jealousy} color="#d8a05a" />
                      <Bar label="suspicion" value={s.cats[clanCat].rel[PLAYER_ID].suspicion} color="#c85a5a" />
                      <Bar label="loyalty" value={s.cats[clanCat].rel[PLAYER_ID].loyalty} color="#5ac8b8" />
                    </div>
                  </>
                )}
                <div className="text-[#a8c890] mt-2 mb-1">Recent memories:</div>
                {s.cats[clanCat].memories.slice(-3).reverse().map((m, i) => (
                  <div key={i} className="border-l-2 border-[#5a7a4c] pl-2 leading-snug opacity-75 mb-1">
                    <span className="opacity-60">[m{m.moon}]</span> {m.text.length > 140 ? m.text.slice(0, 140) + "…" : m.text}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ACTION BAR */}
      <div className="flex gap-2 mt-2 text-xs flex-wrap justify-center max-w-[1100px]">
        <button onClick={() => tryInteract()} className="px-3 py-2 bg-[#2c3a5a] border-2 border-[#4c5a7a] hover:bg-[#3c4a6a]">💬 Interact [E]</button>
        <button onClick={() => act("sleep")} disabled={!inMedDen()} className={`px-3 py-2 border-2 ${inMedDen() ? "bg-[#2c2c4a] border-[#4c4c7a] hover:bg-[#3c3c5a]" : "bg-[#20241e] border-[#33372f] opacity-40"}`}>
          🌙 Sleep &amp; Dream {!inMedDen() && "(go to med den)"}
        </button>
        <button onClick={() => act("train")} disabled={!!s.actionsThisMoon.trained} className={`px-3 py-2 border-2 ${s.actionsThisMoon.trained ? "bg-[#20241e] border-[#33372f] opacity-40" : "bg-[#3a4a2c] border-[#5a6a4c] hover:bg-[#4a5a3c]"}`}>🎯 Train</button>
        <button onClick={() => act("patrol")} disabled={!!s.actionsThisMoon.patrolled} className={`px-3 py-2 border-2 ${s.actionsThisMoon.patrolled ? "bg-[#20241e] border-[#33372f] opacity-40" : "bg-[#3a4a2c] border-[#5a6a4c] hover:bg-[#4a5a3c]"}`}>🐾 Join Patrol</button>
        <button onClick={() => act("play")} className="px-3 py-2 bg-[#4a3a2c] border-2 border-[#6a5a4c] hover:bg-[#5a4a3c]">🧶 Play with Kits</button>
        <button onClick={toggleSound} className="px-3 py-2 bg-[#1c2818] border-2 border-[#3a4a34] hover:bg-[#2c3828]">{soundOn ? "🔊 Sound ON" : "🔇 Sound OFF"}</button>
        <button onClick={() => pickControlMode(controlMode === "pc" ? "mobile" : "pc")} className="px-3 py-2 bg-[#1c2818] border-2 border-[#3a4a34] hover:bg-[#2c3828]">
          {controlMode === "pc" ? "⌨ PC controls" : "📱 Mobile controls"}
        </button>
        <button onClick={saveGame} className="px-3 py-2 bg-[#1c2818] border-2 border-[#3a4a34] hover:bg-[#2c3828]">💾 Save</button>
        <button onClick={handlePassMoon} className="px-4 py-2 bg-[#5a3a6a] border-2 border-[#8a5a9a] hover:bg-[#6a4a7a] text-[#f0d8ff]">🌕 PASS MOON →</button>
      </div>

      {/* TALK MODAL */}
      {dlg?.mode === "talk" && talkCat && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setDlg(null)}>
          <div className="bg-[#18221a] border-4 border-[#3a5a2c] max-w-2xl w-[92%] p-4 text-sm" onClick={(e) => e.stopPropagation()}>
            <div className="flex gap-3">
              <div className="shrink-0">
                <Portrait cat={talkCat} />
                <div className="text-center text-xs mt-1 text-[#ffe08a]">{talkCat.name}</div>
                <div className="text-center text-[10px] opacity-60">{talkCat.role} · {talkCat.mood}</div>
                <div className="text-center text-[10px] opacity-60">{relTier(talkCat.rel[PLAYER_ID])} to you</div>
              </div>
              <div className="flex-1">
                <div className="bg-[#10180f] border border-[#2a3a24] p-3 min-h-[100px] leading-relaxed text-xs whitespace-pre-wrap">{dlg.text}</div>
                {dlg.sub === "main" && (
                  <div className="flex flex-wrap gap-1 mt-2 text-[11px]">
                    <button className="px-2 py-1 bg-[#2c3a5a] border border-[#4c5a7a] hover:bg-[#3c4a6a]" onClick={() => setDlg({ ...dlg, text: generateDialogue(s, talkCat, Math.floor(Math.random() * 1e9)) })}>💬 Keep talking</button>
                    <button className="px-2 py-1 bg-[#2c3a5a] border border-[#4c5a7a] hover:bg-[#3c4a6a]" onClick={() => setDlg({ ...dlg, sub: "askwho" })}>❓ Ask about a cat…</button>
                    <button className="px-2 py-1 bg-[#3a4a2c] border border-[#5a6a4c] hover:bg-[#4a5a3c]" onClick={() => { const m = socialAction(s, talkCat.id, "kind"); setDlg({ ...dlg, text: m }); rerender(); }}>🤝 Share tongues</button>
                    <button className="px-2 py-1 bg-[#3a4a2c] border border-[#5a6a4c] hover:bg-[#4a5a3c]" onClick={() => { const m = socialAction(s, talkCat.id, "help"); setDlg({ ...dlg, text: m }); rerender(); }}>🛠 Help with duties</button>
                    <button className="px-2 py-1 bg-[#3a4a2c] border border-[#5a6a4c] hover:bg-[#4a5a3c]" onClick={() => { const m = socialAction(s, talkCat.id, "defend"); setDlg({ ...dlg, text: m }); rerender(); }}>🛡 Stand up for them</button>
                    <button className="px-2 py-1 bg-[#4a2c3a] border border-[#6a4c5a] hover:bg-[#5a3c4a]" onClick={() => { const m = doObserve(s, talkCat.id); setDlg({ ...dlg, text: m }); rerender(); }}>👁 Observe quietly</button>
                    <button
                      className="px-2 py-1 bg-[#4a1c1c] border border-[#7a3c3c] hover:bg-[#5a2c2c] text-[#f0a0a0]"
                      onClick={() => {
                        const m = socialAction(s, talkCat.id, "hostile");
                        if (s.ending) { setDlg(null); setScreen("ending"); saveGame(); return; }
                        setDlg({ ...dlg, text: m });
                        audioRef.current?.chime(false);
                        saveGame();
                        rerender();
                      }}
                    >
                      😾 Be hostile
                    </button>
                    {talkCat.sick && (
                      <button className="px-2 py-1 bg-[#2c4a3a] border border-[#4c6a5a] hover:bg-[#3c5a4a] text-[#a8e8c0]" onClick={() => { const m = treatCat(s, talkCat.id); setDlg({ ...dlg, text: m }); audioRef.current?.chime(true); rerender(); }}>
                        ⚕ Treat {talkCat.sick.name}
                      </button>
                    )}
                    {talkCat.id === "silentpaw" && canTellSilentTruth(s) && (
                      <button
                        className="px-2 py-1 bg-[#3a2440] border border-[#7a5aa8] hover:bg-[#4a3450] text-[#d8c0f0]"
                        onClick={() => { const m = tellSilentTruth(s); setDlg({ ...dlg, text: m }); audioRef.current?.chime(false); saveGame(); rerender(); }}
                      >
                        💔 Tell him the truth about his birth…
                      </button>
                    )}
                    <button className="px-2 py-1 bg-[#1c2818] border border-[#3a4a34] hover:bg-[#2c3828]" onClick={() => setDlg(null)}>✕ Leave</button>
                  </div>
                )}
                {dlg.sub === "askwho" && (
                  <div className="flex flex-wrap gap-1 mt-2 text-[10px] max-h-40 overflow-y-auto">
                    {Object.values(s.cats).filter((c) => c.id !== talkCat.id && c.id !== PLAYER_ID && c.role !== "outsider").map((c) => (
                      <button key={c.id} className="px-2 py-1 bg-[#1c2818] border border-[#3a4a34] hover:bg-[#2c3828]" onClick={() => { advanceTime(s); setDlg({ mode: "talk", catId: talkCat.id, text: opinionLine(s, talkCat, c.id, Math.floor(Math.random() * 1e9)), sub: "main" }); rerender(); }}>
                        {c.name}{!c.alive ? " ☆" : ""}
                      </button>
                    ))}
                    <button className="px-2 py-1 bg-[#2c1c18] border border-[#4a3a34]" onClick={() => setDlg({ ...dlg, sub: "main" })}>← back</button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* INFO MODAL */}
      {dlg?.mode === "info" && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={() => setDlg(null)}>
          <div className="bg-[#18221a] border-4 border-[#3a5a2c] max-w-xl w-[92%] p-5 text-sm" onClick={(e) => e.stopPropagation()}>
            <div className="text-[#a8c890] mb-2">{dlg.title}</div>
            <div className="text-xs leading-relaxed whitespace-pre-wrap mb-3">{dlg.text}</div>
            <button className="px-3 py-1 bg-[#3a5a2c] border border-[#5a7a4c]" onClick={() => setDlg(null)}>Continue</button>
          </div>
        </div>
      )}

      {/* STORY EVENT MODAL */}
      {dlg?.mode === "event" && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50">
          <div className="bg-[#161c20] border-4 border-[#4a5a7a] max-w-2xl w-[94%] p-5 text-sm max-h-[85vh] overflow-y-auto">
            <div className="text-[#b8c8e8] text-base mb-3" style={{ textShadow: "1px 1px 0 #1a2030" }}>{dlg.ev.title}</div>
            <div className="flex gap-3">
              {dlg.ev.speaker && s.cats[dlg.ev.speaker] && (
                <div className="shrink-0">
                  <Portrait cat={s.cats[dlg.ev.speaker]} />
                  <div className="text-center text-xs mt-1">{s.cats[dlg.ev.speaker].name}</div>
                </div>
              )}
              <div className="text-xs leading-relaxed whitespace-pre-wrap flex-1">{dlg.result ?? dlg.ev.text}</div>
            </div>
            <div className="mt-4 flex flex-col gap-2">
              {!dlg.result &&
                dlg.ev.choices.map((c, i) => (
                  <button key={i} className="text-left px-3 py-2 bg-[#20283a] border-2 border-[#3a4a6a] hover:bg-[#2a3a5a] text-xs" onClick={() => chooseEvent(dlg.ev, i)}>
                    ▸ {c.label}
                  </button>
                ))}
              {dlg.result && (
                <button className="px-3 py-2 bg-[#3a5a2c] border-2 border-[#5a7a4c] text-xs self-start" onClick={closeEventResult}>Continue</button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MOON REPORT */}
      {moonReport && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50">
          <div className="bg-[#1a1a24] border-4 border-[#5a3a6a] max-w-2xl w-[94%] p-5 max-h-[85vh] overflow-y-auto">
            <div className="text-[#d8b8f0] text-base mb-3">🌕 The moon turns… Moon {s.moon}</div>
            <div className="space-y-1 text-xs">
              {moonReport.map((e, i) => (
                <div key={i} className={`leading-snug pb-1 border-b border-[#2a2a34] ${e.startsWith("☆") ? "text-[#e8a0a0]" : e.startsWith("⭐") ? "text-[#ffe08a]" : "opacity-90"}`}>{e}</div>
              ))}
            </div>
            <button className="mt-4 px-4 py-2 bg-[#5a3a6a] border-2 border-[#8a5a9a] text-xs" onClick={closeMoonReport}>Continue →</button>
          </div>
        </div>
      )}

      <div className="mt-2 text-[10px] opacity-50 max-w-[900px] text-center px-2">
        {controlMode === "pc"
          ? "WASD/arrows move · E interacts · pass through the camp entrance (south) to reach the territory · the Clan keeps living whether you watch or not"
          : "arrow keys move · 🐾 button (or tap the map) interacts · pass through the camp entrance (south) to reach the territory · the Clan keeps living whether you watch or not"}
      </div>
    </div>
  );
}
