import { pgTable, serial, integer, jsonb, timestamp, text } from "drizzle-orm/pg-core";

export const saves = pgTable("saves", {
  id: serial("id").primaryKey(),
  slot: integer("slot").notNull().default(1),
  moon: integer("moon").notNull().default(1),
  summary: text("summary").notNull().default(""),
  state: jsonb("state").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
